insert into board_category (CID,CNAME) 
values(BOARD_BNUM_SEQ.nextval,'�׽�Ʈ');

insert into board_category (CID,CNAME) 
values(BOARD_BNUM_SEQ.nextval,'�׽�Ʈ2');

insert into board_category (CID,CNAME) 
values(BOARD_BNUM_SEQ.nextval,'�׽�Ʈ3');


commit;

