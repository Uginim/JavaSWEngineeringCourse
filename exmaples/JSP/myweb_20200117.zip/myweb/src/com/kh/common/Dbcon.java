package com.kh.common;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

public class Dbcon {
	private static Connection conn;
	private static Context initCtx;
	private static Context envCtx;
	private static DataSource ds;
	
	// db커넥션 가져오기
	public static Connection getConnection() {
		try {
			initCtx = new InitialContext();
			envCtx  = (Context)initCtx.lookup("java:comp/env");
			ds   		= (DataSource)envCtx.lookup("jdbc/java");
			conn 		= ds.getConnection();		
		} catch (Exception e) {
			e.printStackTrace();
		}
		return conn;
	}
	
	// db커넥션 반납
	public static void close() {
		try {
			if(conn!=null) {
				conn.close();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
