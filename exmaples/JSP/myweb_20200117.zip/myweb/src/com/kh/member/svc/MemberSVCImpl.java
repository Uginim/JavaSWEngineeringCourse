package com.kh.member.svc;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.json.JSONObject;

import com.kh.dto.MemberDTO;
import com.kh.member.dao.MemberDAO;
import com.kh.member.dao.MemberDAOImp;

public class MemberSVCImpl implements MemberSVC {

	private static MemberSVCImpl memberSVCImpl = new MemberSVCImpl();
	private MemberDAO	memberDAO;
	
	private MemberSVCImpl() {	
		memberDAO = MemberDAOImp.getMemberDAO();
	}
	
	public static MemberSVCImpl getMemberSVC() {
		return memberSVCImpl;
	}
	
	//회원가입
	@Override
	public void memberJoin(HttpServletRequest req, HttpServletResponse res) {
		System.out.println("MemberSVCImp.memberJoin()호출됨!!");
		//파라미터 정보 읽기
		MemberDTO memberDTO = new MemberDTO();
		memberDTO.setId(req.getParameter("id"));
		memberDTO.setPw(req.getParameter("pw"));
		memberDTO.setTel(req.getParameter("tel"));
		memberDTO.setNickname(req.getParameter("nickname"));
		memberDTO.setRegion(req.getParameter("region"));
		memberDTO.setGender(req.getParameter("gender"));
		
		// String => Date변환
		SimpleDateFormat transFormat = new SimpleDateFormat("yyyy-MM-dd");
		try {
			memberDTO.setBirth(transFormat.parse(req.getParameter("birth")));
		} catch (ParseException e1) {	e1.printStackTrace();}		
		
		//DAO에 전달
		int cnt = memberDAO.memberJoin(memberDTO);
		//결과처리
		
	}
	
	//회원조회(1명)
	@Override
	public void memberSelect(HttpServletRequest req, HttpServletResponse res) {
		HttpSession session = req.getSession(false);
		//세션이 존재하면 세션객체에 저장된 id값을 읽어옮		
		if(session != null) {
			MemberDTO memberDTO = (MemberDTO)session.getAttribute("member");
			
			req.setAttribute("memberModi", memberDAO.memberSelect(memberDTO.getId()));;
		};
		
	}
	//회원목록조회(전체)
	@Override
	public void memberList(HttpServletRequest req, HttpServletResponse res) {
		// TODO Auto-generated method stub
		
	}
	//회원수정
	@Override
	public void memberModify(HttpServletRequest req, HttpServletResponse res) {
		//req로부터 파라미터정보 읽어오기	
		MemberDTO memberDTO = new MemberDTO();
		memberDTO.setTel(req.getParameter("tel"));
		memberDTO.setNickname(req.getParameter("nickname"));
		memberDTO.setGender(req.getParameter("gender"));
		memberDTO.setRegion(req.getParameter("region"));
		
		// String => Date변환
		SimpleDateFormat transFormat = new SimpleDateFormat("yyyy-MM-dd");
		try {
			memberDTO.setBirth(transFormat.parse(req.getParameter("birth")));
		} catch (ParseException e1) {	e1.printStackTrace();}		
		memberDTO.setId(req.getParameter("id"));
			
		memberDAO = MemberDAOImp.getMemberDAO();
		int cnt = memberDAO.memberModify(memberDTO);
		if(cnt == 1) {
//			req.getSession(false).setAttribute("member", memberDTO);
			//수정전  세션 정보를 제거 
			req.getSession(false).invalidate();
			// 후정후 정보로 세션 갱신
			req.getSession(true).setAttribute("member", memberDTO);
		}
		
	}
	//회원탈퇴
	@Override
	public boolean memberOut(HttpServletRequest req, HttpServletResponse res) {
		boolean result = false;
		//파라미터 읽어오기
		String id = req.getParameter("id");
		String pw = req.getParameter("pw");
		//DAO에 전달.
		int cnt = memberDAO.memberOut(id, pw);
		if(cnt == 1) {
		// 세션 제거
			HttpSession session = req.getSession(false);
			if(session != null) {
				session.invalidate();
				result = true;
			}else {
				req.setAttribute("error", "현재 접속중이 아닙니다!");
			}
		}else {
		// 오류메세지 => outForm.jsp 
			req.setAttribute("error", "비밀번호가 잘못되었습니다.!");
		}
		return result;
	}
	
	//로그인
	@Override
	public void memberLogin(HttpServletRequest req, HttpServletResponse res) {
		//파라미터 읽어오기
		String id = req.getParameter("id");
		String pw = req.getParameter("pw");
		//DAO에 전달.
		MemberDTO memberDTO = memberDAO.memberLogin(id, pw);
		
		//회원정보를  req객체에 저장
		if(memberDTO != null) {
			HttpSession session = req.getSession(true);
			session.setAttribute("member", memberDTO);
		}else {
			req.setAttribute("error", "가입된 회원정보가 없습니다!");
		}
	}

	//로그아웃
	@Override
	public void memberLogout(HttpServletRequest req, HttpServletResponse res) {
		
		//req.getSession(false) :  세션정보가 있으면 얻어오고 없으면 null값을 리턴한다.
		//req.getSession()	: 세션정보가 있으면 얻어오고 없으면 새로운 세션객체를 생성하여 리턴한다.
		//                  : req.getSession(true)와 같다.
		HttpSession session = req.getSession(false);
		
		//세션정보가 있으면 제거
		if(session != null) {
			session.invalidate();
		}else {
		//접속상태가 아님	
			System.out.println("접속상태가 아님!!");
		}
		
	}

	//아이디 찾기
	@Override
	public boolean findID(HttpServletRequest req, HttpServletResponse res) throws IOException {
		boolean result = false;
		
//		String tel = req.getParameter("tel");
//		String birth = req.getParameter("birth");
		// json포멧문자열 => json객체로 변환
		JSONObject jobj = new JSONObject(req.getParameter("result"));
		
		String tel   = (String)jobj.get("tel");
		String birth = (String)jobj.get("birth");
		
		String id = memberDAO.findID(tel,birth );
		System.out.println("찾은ID=" + id);
		
		if(id != null) {
			req.setAttribute("foundID", id);
			result = true;
			
			String str = "{ id : " + id + "}";
			//문자열 => json포맷으로 변경
			JSONObject idTojson = new JSONObject(str);
			
			res.getWriter().append(idTojson.toString());
			
		}else {
			String str = "{ error : 찾고자하는 아이디가 없습니다!}";
			//문자열 => json포맷으로 변경
			JSONObject emsgToJson = new JSONObject(str);
			
			res.getWriter().append(emsgToJson.toString());
		}
		return result;
	}

	//비밀번호찾기
	@Override
	public boolean findPW(HttpServletRequest req, HttpServletResponse res) throws IOException{
		boolean status = false;
		// req에서 요청정보 추출		
		// json포멧문자열 => json객체로 변환
		System.out.println("result="+ req.getParameter("result"));
		JSONObject jobj = new JSONObject(req.getParameter("result"));		
		String id   = (String)jobj.get("id");
		String tel   = (String)jobj.get("tel");
		String birth = (String)jobj.get("birth");
		
		// dao.findPW()에 id,tel,birth전달.
		boolean result = memberDAO.findPW(id, tel, birth);
		// 회원정보 성공유무를 json포맷의 문자열로 전달.	
		String str = "{ success : " + result + "}";
		
		//문자열 => json포맷 문자열로 변경
		JSONObject jobj2 = new JSONObject(str);			
		res.getWriter().append(jobj2.toString());
		
		if(result) {
			status = true;
		}			
		return status;
	}

	//비밀번호변경
	@Override
	public boolean changePW(HttpServletRequest req, HttpServletResponse res) throws IOException {
		boolean status = false;
		// req에서 요청정보 추출		
		// json포멧문자열 => json객체로 변환
		
		JSONObject jobj = new JSONObject(req.getParameter("result"));		
		String id   = (String)jobj.get("id");
		String pw   = (String)jobj.get("pw");
		
		// dao.changePW()에 id,pw전달.
		boolean result = memberDAO.changePW(id, pw);
		// 비밀번호변경 성공유무를 json포맷의 문자열로 전달.	
		String str = "{ success : " + result + "}";
		
		//문자열 => json포맷 문자열로 변경
		JSONObject jobj2 = new JSONObject(str);			
		res.getWriter().append(jobj2.toString());
		
		if(result) {
			status = true;
		}			
		return status;
	}
}













