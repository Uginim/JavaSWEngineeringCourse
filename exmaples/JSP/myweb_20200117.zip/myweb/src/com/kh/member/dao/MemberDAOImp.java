package com.kh.member.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import com.kh.common.Dbcon;
import com.kh.dto.MemberDTO;

public class MemberDAOImp implements MemberDAO {
	
	private static MemberDAOImp memberDAOImpl = new MemberDAOImp();
	Connection conn;
	
	private MemberDAOImp() { }
	
	public static MemberDAOImp getMemberDAO() {
		return memberDAOImpl;
	}
	
	@Override
	public int memberJoin(MemberDTO memberDTO) {
		System.out.println("MemberDAOImpl.memberJoin()호출됨!!");
		int cnt = 0;
		
		StringBuffer sql = new StringBuffer();
		sql.append("INSERT INTO member ( id, pw, tel, nickname, gender, region, birth, cdate) ");
		sql.append("VALUES (?,?,?,?,?,?,?,sysdate) ");
		try {
			conn = Dbcon.getConnection();
			PreparedStatement pstmt = conn.prepareStatement(sql.toString());
			pstmt.setString(1, memberDTO.getId());
			pstmt.setString(2, memberDTO.getPw());
			pstmt.setString(3, memberDTO.getTel());
			pstmt.setString(4, memberDTO.getNickname());
			pstmt.setString(5, memberDTO.getGender());
			pstmt.setString(6, memberDTO.getRegion());
			pstmt.setDate(7, new java.sql.Date(memberDTO.getBirth().getTime()));
			
			cnt = pstmt.executeUpdate();
			System.out.println("cnt=" + cnt);
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			Dbcon.close();
		}
		return cnt;
	}

	@Override
	public MemberDTO memberSelect(String id) {
		MemberDTO memberDTO = null;
		
		StringBuffer sql = new StringBuffer();
		sql.append("select id,tel,nickname,gender,region,birth ");
		sql.append("  from member ");
		sql.append(" where id = ? ");
		
		try {
			conn = Dbcon.getConnection();
			PreparedStatement pstmt = conn.prepareStatement(sql.toString());
			pstmt.setString(1, id);
			ResultSet rs = pstmt.executeQuery();
			if(rs.next()) {
				memberDTO = new MemberDTO();
				memberDTO.setId(rs.getString("id"));
				memberDTO.setTel(rs.getString("tel"));
				memberDTO.setNickname(rs.getString("nickname"));
				memberDTO.setGender(rs.getString("gender"));
				memberDTO.setRegion(rs.getString("region"));
				memberDTO.setBirth(rs.getDate("birth"));		
			}			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			Dbcon.close();
		}
		return memberDTO;
	}

	@Override
	public List<MemberDTO> memberList() {
		// TODO Auto-generated method stub
		return null;
	}

	//회원정보수정
	@Override
	public int memberModify(MemberDTO memberDTO) {
		int cnt = 0;
		//sql작성
		StringBuffer sql = new StringBuffer();
		sql.append("update member ");
		sql.append("   set tel = ?, ");
		sql.append("       nickname = ?, ");
		sql.append("			 gender = ?, ");
		sql.append("			 region = ?, ");
		sql.append("			 birth = ?, ");
		sql.append("			 udate = sysdate ");
		sql.append(" where id = ? ");
		
		//커넥션 획득
		conn = Dbcon.getConnection();
		try {
			PreparedStatement pstmt = conn.prepareStatement(sql.toString());
			pstmt.setString(1, memberDTO.getTel());
			pstmt.setString(2, memberDTO.getNickname());
			pstmt.setString(3, memberDTO.getGender());
			pstmt.setString(4, memberDTO.getRegion());
			pstmt.setDate(5, new java.sql.Date(memberDTO.getBirth().getTime()));
			pstmt.setString(6, memberDTO.getId());
			//sql실행 후 변경된 레코드 수 반환
			cnt = pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			//커넥션 반환
			Dbcon.close();
		}		
		return cnt;
	}

	//회원 탈퇴
	@Override
	public int memberOut(String id, String pw) {
		int cnt = 0; // 삭제건수

		StringBuffer sql = new StringBuffer();
		sql.append("delete from member where id=? and pw=?");
		
		conn = Dbcon.getConnection();
		try {
			PreparedStatement pstmt = conn.prepareStatement(sql.toString());
			pstmt.setString(1, id);
			pstmt.setString(2, pw);
			cnt = pstmt.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			Dbcon.close();
		}
		
		return cnt;
	}

	//로그인
	@Override
	public MemberDTO memberLogin(String id, String pw) {
		MemberDTO memberDTO = null;
		//sql작성
		StringBuffer sql = new StringBuffer();
				
		sql.append("SELECT id, pw, tel, nickname, gender, region, birth, cdate, udate ");
		sql.append("  FROM member ");		
		sql.append(" where id = ? ");		
		sql.append("   and pw = ? ");		
		
		//db커넥션 획득
		conn = Dbcon.getConnection();
		try {
			PreparedStatement pstmt = conn.prepareStatement(sql.toString());
			pstmt.setString(1, id);
			pstmt.setString(2, pw);
			//sql실행
			ResultSet rs = pstmt.executeQuery();
			if(rs.next()) {
				memberDTO = new MemberDTO();
				memberDTO.setId(rs.getString("id"));
				memberDTO.setPw(rs.getString("pw"));
				memberDTO.setTel(rs.getString("tel"));
				memberDTO.setNickname(rs.getString("nickname"));
				memberDTO.setGender(rs.getString("gender"));
				memberDTO.setRegion(rs.getString("region"));
				memberDTO.setBirth(rs.getDate("birth"));
				memberDTO.setCdate(rs.getDate("cdate"));
				memberDTO.setUdate(rs.getDate("udate"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			//자원반납
			Dbcon.close();
		}
		
		return memberDTO;
	}

	//아이디 찾기
	@Override
	public String findID(String tel, String birth) {
		String id = null;
		
		StringBuffer sql = new StringBuffer();
		sql.append("select id from member where tel=? and birth=? ");
		
		conn = Dbcon.getConnection();
		try {
			PreparedStatement pstmt = conn.prepareStatement(sql.toString());
			pstmt.setString(1, tel);
			pstmt.setString(2, birth);
			
			ResultSet rs = pstmt.executeQuery();
			if(rs.next()) {
				id = rs.getString("id");
			}		
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return id;
	}

	// 비밀번호 찾기
	@Override
	public boolean findPW(String id, String tel, String birth) {
		boolean result = false;
		// sql문
		StringBuffer sql = new StringBuffer();
		sql.append("select id from member ");
		sql.append(" where id=? and tel=? and birth=? ");
		// 커넥션 획득
		conn = Dbcon.getConnection();
		try {
			PreparedStatement pstmt = conn.prepareStatement(sql.toString());
			pstmt.setString(1, id);
			pstmt.setString(2, tel);
			pstmt.setString(3, birth);
			// sql실행
			ResultSet rs = pstmt.executeQuery();
			if(rs.next()) {
				if(rs.getString("id").equals(id)) {
					// sql실행 결과
					result = true;
				}	
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			// 커넥션 반납
			Dbcon.close();
		}
		return result;
	}

	// 비밀번호변경
	@Override
	public boolean changePW(String id, String pw) {
		boolean result = false;
		
		StringBuffer sql = new StringBuffer();
		sql.append("update member ");
		sql.append("   set pw = ? ");
		sql.append(" where id=? ");
		
		conn = Dbcon.getConnection();
		try {
			PreparedStatement pstmt = conn.prepareStatement(sql.toString());
			pstmt.setString(1, pw);
			pstmt.setString(2, id);
			int cnt = pstmt.executeUpdate();
			if(cnt == 1) {
				result = true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			Dbcon.close();
		}		
		return result;
	}

}














