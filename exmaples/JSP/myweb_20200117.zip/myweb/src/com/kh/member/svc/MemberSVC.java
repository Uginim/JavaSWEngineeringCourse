package com.kh.member.svc;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.kh.dto.MemberDTO;

public interface MemberSVC {
	
	//회원가입
	void memberJoin(HttpServletRequest req, HttpServletResponse res);
	//회원조회(1명)
	void memberSelect(HttpServletRequest req, HttpServletResponse res);
	//회원목록조회(전체)
	void memberList(HttpServletRequest req, HttpServletResponse res);
	//회원수정
	void memberModify(HttpServletRequest req, HttpServletResponse res);
	//회원탈퇴
	boolean memberOut(HttpServletRequest req, HttpServletResponse res);
	//로그인
	void memberLogin(HttpServletRequest req, HttpServletResponse res);
	//로그아웃
	void memberLogout(HttpServletRequest req, HttpServletResponse res);
	//아이디찾기
	boolean findID(HttpServletRequest req, HttpServletResponse res) throws IOException;
	//비밀번호찾기
	boolean findPW(HttpServletRequest req, HttpServletResponse res) throws IOException;
	//비밀번호변경
	boolean changePW(HttpServletRequest req, HttpServletResponse res) throws IOException;
	
}








