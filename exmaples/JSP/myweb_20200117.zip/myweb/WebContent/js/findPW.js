window.addEventListener("load",init,false);
function init(){
  findBtn.addEventListener("click",function(e){
    console.log('클릭됨');  
    var status = false;
    //1) 유효성 체크(아이디,전화번호,생일)
//    status = valChk();
//    if(!status) return;
    
    //2) 사용자인증 AJAX call
    status = authCkh();
    console.log("status="+status);
    //if(!status) return;
    
    //3) UI업데이트(비밀번호변경되게!!)
    updateUI();
    
    //4) 유효성체크(비밀번호)
    status = pwChk();
    if(!status) return;
    
    //5) 비밀번호변경 AJAX call
    chagePW();
    

  },false);
}

//1) 유효성 체크(아이디,전화번호,생일)
function valChk(){
	
}

//2) 사용자인증 AJAX call
function authCkh(){
	var flag = false;
  //AJAX 사용
  //1) XMLHttpRequest객체 생성	
  var xhttp = new XMLHttpRequest();
  
  //2) 서버응답처리
  xhttp.addEventListener("readystatechange",ajaxCall,false);
  function ajaxCall(){
	  if (this.readyState == 4 && this.status == 200) {
		  console.log(this.responseText);
		  //json포맷 문자열  => 자바스크립트 obj
		  var jsonObj = JSON.parse(this.responseText)
		  if(jsonObj.success){
		  	flag = true;
		  	console.log('회원인증!!');
		  }
	  }
  }
 	  
  //3) 서비스 요청
  var sendData = {};
  sendData.id   = document.getElementById("id").value;
  sendData.tel   = document.getElementById("tel").value;
  sendData.birth = document.getElementById("birth").value;
  //자바스크립트 obj => json포맷 문자열 변환
  var result = JSON.stringify(sendData);
  console.log(result);
  
  //post방식
  xhttp.open("POST","http://localhost:9080/myweb/member/findPW.do",true);
  xhttp.setRequestHeader("Content-Type","application/x-www-form-urlencoded"); 
  xhttp.send("result="+result);
  
  return flag;
}

//3) UI업데이트(비밀번호변경되게!!)
function updateUI(){
	console.log('ui호출됨!');
  var hideTags = document.querySelectorAll(".hide");
  for(let hideTag of hideTags){
    if(hideTag.classList.contains("hide")){
      hideTag.classList.remove("hide");
      console.log(hideTag);
    }
  }
  findBtn.textContent = "비밀번호변경";	
}

//4) 유효성체크(비밀번호)
function pwChk() {
	
}

//5) 비밀번호변경 AJAX call
function chagePW() {
	
}





