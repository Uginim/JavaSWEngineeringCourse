package com.kh.member.svc;

import java.text.ParseException;
import java.text.SimpleDateFormat;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.kh.common.PasswordDigest;
import com.kh.dto.MemberDTO;
import com.kh.member.dao.MemberDAO;
import com.kh.member.dao.MemberDAOImpl;

public class MemberSVCImpl implements MemberSVC {
	private static MemberSVCImpl memberSVCimpl = new MemberSVCImpl();
	private MemberDAO memberDAO;

	private MemberSVCImpl() {
		memberDAO = MemberDAOImpl.getMemberDAO();
	}

	public static MemberSVCImpl getMemberSVC() {
		return memberSVCimpl;
	}



	// 회원가입
	@Override
	public void memberJoin(HttpServletRequest req, HttpServletResponse res) {
		// 파라미터 정보 읽기
		MemberDTO memberDTO = new MemberDTO();
		memberDTO.setId(req.getParameter("id"));
		String pwDigest = PasswordDigest.getSha512(req.getParameter("pw"));
		memberDTO.setPw(pwDigest);
		memberDTO.setTel(req.getParameter("tel"));
		memberDTO.setNickname(req.getParameter("nickname"));
		memberDTO.setGender(req.getParameter("gender"));
		memberDTO.setRegion(req.getParameter("region"));
		SimpleDateFormat transFormat = new SimpleDateFormat("yyyy-MM-dd");
		try {
			memberDTO.setBirth(transFormat.parse(req.getParameter("birth")));
		} catch (ParseException e1) {
			e1.printStackTrace();
		}

		// DAO에 전달
		memberDAO = MemberDAOImpl.getMemberDAO();
		int cnt = memberDAO.memberJoin(memberDTO);

		// 6) 화면전환(로그인 화면으로 이동)
		if (cnt == 0)
			req.setAttribute("error", "회원가입 실패");

	}

	// 회원 조회(1명)
	@Override
	public void memberSelect(HttpServletRequest req, HttpServletResponse res) {
		HttpSession session = req.getSession(false);

		if (session != null) {
			MemberDTO memberDTO = (MemberDTO) session.getAttribute("member");
			memberDAO = MemberDAOImpl.getMemberDAO();
			if (memberDTO != null) {
//				System.out.println("memberDAO.memberSelect(memberDTO.getId()):" + memberDAO.memberSelect(memberDTO.getId()));
				req.setAttribute("memberModi", memberDAO.memberSelect(memberDTO.getId()));

			}
		}
	}

//회원목록조회(전체)
	@Override
	public void memberList(HttpServletRequest req, HttpServletResponse res) {
		// TODO Auto-generated method stub

	}

	// 회원수정

	@Override
	public void memberModify(HttpServletRequest req, HttpServletResponse res) {
		// TODO Auto-generated method stub
		MemberDTO memberDTO = new MemberDTO();
		memberDTO.setId(req.getParameter("id"));
		memberDTO.setTel(req.getParameter("tel"));
		memberDTO.setNickname(req.getParameter("nickname"));
		memberDTO.setGender(req.getParameter("gender"));
		memberDTO.setRegion(req.getParameter("region"));
		SimpleDateFormat transFormat = new SimpleDateFormat("yyyy-MM-dd");
		try {
			memberDTO.setBirth(transFormat.parse(req.getParameter("birth")));
		} catch (ParseException e1) {
			e1.printStackTrace();
		}
		memberDAO = MemberDAOImpl.getMemberDAO();
		int cnt = memberDAO.memberModify(memberDTO);
		if (cnt == 1) {
//			req.getSession(false).setAttribute("member",memberDTO);
			req.getSession(false).invalidate();
			req.getSession().setAttribute("member", memberDTO);
		}

	}

	// 회원탈퇴
	@Override
	public void memberOut(HttpServletRequest req, HttpServletResponse res) {
		HttpSession session = req.getSession(false);
		if (session != null) {
			MemberDTO logedInMemberDTO = (MemberDTO) session.getAttribute("member");
			String id = logedInMemberDTO.getId();
			String pw = req.getParameter("pw");
			pw = PasswordDigest.getSha512(pw);
			memberDAO = MemberDAOImpl.getMemberDAO();
			int cnt = memberDAO.memberOut(id, pw);
			if (cnt == 1) {
//			HttpSession session = req.getSession(false);

				session.invalidate();
			} else {
				req.setAttribute("error", "입력정보가 다릅니다.");
			}
		}
	}

	// 로그인
	@Override
	public void memberLogin(HttpServletRequest req, HttpServletResponse res) {
		String id = req.getParameter("id");
		String pw = req.getParameter("pw");
		pw = PasswordDigest.getSha512(pw); // 다이제스트
		MemberDTO logedInUser = memberDAO.memberLogin(id, pw);

		if (logedInUser != null) {
//			req.setAttribute("member", logedInUser);
			HttpSession session = req.getSession();
			session.setAttribute("member", logedInUser);
			System.out.println("session: " + logedInUser);
			/*
			 * session.setAttribute("id", id); session.setAttribute("nickname", "관리자");
			 * 
			 * //메인화면으로 이동 RequestDispatcher dispatcher = req.getRequestDispatcher("/note");
			 * try { dispatcher .forward(req, res); } catch (ServletException e) { // TODO
			 * Auto-generated catch block e.printStackTrace(); } catch (IOException e) { //
			 * TODO Auto-generated catch block e.printStackTrace(); }
			 */

		} else {
			req.setAttribute("error", "로그인 정보가 없습니다.");

			/*
			 * res.setContentType("text/html;charset=utf-8"); // 아래 response.getWriter()보다
			 * 위에 와야함 PrintWriter out; try { out = res.getWriter(); out.println("<script>");
			 * out.println("alert('아이디 또는 비밀번호가 잘못되었습니다.')"); out.println("history.go(-1)");
			 * out.println("</script>"); } catch (IOException e) { // TODO Auto-generated
			 * catch block e.printStackTrace(); }
			 */
		}
//		return null;
	}

	@Override
	public void memberlogout(HttpServletRequest req, HttpServletResponse res) {
		HttpSession session = req.getSession(false);
		if (session != null) {
			session.invalidate(); // 세션 제거
		} else {
			// 접속 상태 아님
			System.out.println("접속상태 아님");
		}
	}

}
