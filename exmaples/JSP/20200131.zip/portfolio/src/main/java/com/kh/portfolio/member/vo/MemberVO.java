package com.kh.portfolio.member.vo;

import java.sql.Date;
import java.sql.Timestamp;

import lombok.Data;

@Data
public class MemberVO {
	private String id; // 아이디(이메일
	private String pw; // 비밀번호
	private String tel; // 전화번호
	private String nickname; // 별명
	private String gender; // 성별('남','여')
	private String region; // 지역
	private Date birth; // 생년월일
	private Timestamp cDate; // 생성일시
	private Timestamp uDate; // 변경일시
}
