package com.kh.portfolio.exception;

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.ModelAndView;

@ControllerAdvice
public class GlobalExceptionHandler {
//	@ExceptionHandler(value = DuplicateKeyException.class)
	@ExceptionHandler(value = Exception.class)
	public ModelAndView handleSQLException(Exception ex) {
		System.out.println("ex:"+ex);
		ModelAndView mav = new ModelAndView("exception");
		mav.addObject("name",ex.getClass().getSimpleName());
		mav.addObject("message",ex.getMessage());
		mav.setViewName("exception/exception");
		return mav;
	}
}
