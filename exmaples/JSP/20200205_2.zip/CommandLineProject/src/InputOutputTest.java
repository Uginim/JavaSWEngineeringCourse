import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;

public class InputOutputTest {
	public static void main(String[] args) {
		Process process =null;
		try {
//			process = Runtime.getRuntime().exec("cmd.exe /c echo \"hello\"");
			process = Runtime.getRuntime().exec("cmd.exe");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
		InputStreamThread  inputThread = new InputStreamThread(process.getInputStream(),process.getErrorStream());
//		InputStreamThread  inputThread = new InputStreamThread(process.getInputStream());
		
		OutputStreamThread outputThread = new OutputStreamThread(process.getOutputStream());
		inputThread.start();
		outputThread.start();
		for(int i =0;i<100;i++) {
			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}
}

class InputStreamThread extends Thread{
	InputStream is;
	InputStream es;
	public InputStreamThread (InputStream is){
		this.is=is;
	}
	public InputStreamThread (InputStream is, InputStream es){
		this.is=is;
		this.es=es;
	}
	@Override
	public void run() {
		InputStreamReader isr = new InputStreamReader(is);
		BufferedReader br = new BufferedReader(isr);
		BufferedReader ber = new BufferedReader(new InputStreamReader(es));
		while(true) {
			try {
				Thread.sleep(50);
			} catch (InterruptedException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			
			try {
				while(br.ready())
					System.out.println(br.readLine());
				while(ber.ready())
					System.out.println(ber.readLine());
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}
}

class OutputStreamThread extends Thread{
	OutputStream os;
	public OutputStreamThread (OutputStream os) {
			this.os=os;
	}
	@Override
	public void run() {
		OutputStreamWriter osw = new OutputStreamWriter(os);
		BufferedWriter bw = new BufferedWriter(osw);
		try {
			bw.append("cd /");
			bw.newLine();
			bw.append("javac");
			bw.newLine();
			bw.flush();
		} catch (IOException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
		int cnt = 0;
		/*
		while(true) {
			try {
				Thread.sleep(50);
			} catch (InterruptedException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			try {
//				osw.write("echo \"hi"+cnt+"\"\n");
				bw.append("echo \"hi"+ cnt++ +"\"");
				bw.newLine();
				bw.flush();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
//		*/
		/*
		try {
			bw.append("echo \"hi"+ cnt++ +"\"");
			bw.newLine();
			bw.flush();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		*/
	}

}