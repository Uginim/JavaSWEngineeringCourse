package com.kh.portfolio.member.dao;

import com.kh.portfolio.member.vo.MemberVO;

public interface MemberDAO {
	// 회원 등록
	int insert(MemberVO memberVO);
}
