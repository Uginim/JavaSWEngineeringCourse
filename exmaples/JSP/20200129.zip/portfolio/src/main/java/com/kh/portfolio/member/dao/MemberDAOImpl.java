package com.kh.portfolio.member.dao;

import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.kh.portfolio.member.vo.MemberVO;
@Repository
public class MemberDAOImpl implements MemberDAO {
	
	private static final Logger logger = LoggerFactory.getLogger(MemberDAOImpl.class);
	
	@Inject
	JdbcTemplate jdbcTemplate; // 참조로 얻어옴 이후 이것으로 CRUD를 함
	
	// 회원등록
	@Override
	public int insert(MemberVO memberVO) {
		logger.info("public int insert(MemberVO memberVO) 호출됨!!");
		logger.info(memberVO.toString());
		int cnt = 0;
		
		// sql문 작성
		StringBuffer sql = new StringBuffer();
		sql.append("INSERT INTO member (id, pw, tel, nickname, gender, region, birth, cdate) ");
		sql.append("VALUES (?,?,?,?,?,?,?,systimestamp)");
		
		// sql 실행
		cnt = jdbcTemplate.update(
				sql.toString(),
				memberVO.getId(),
				memberVO.getPw(),
				memberVO.getTel(),
				memberVO.getNickname(),
				memberVO.getGender(),
				memberVO.getRegion(),
				memberVO.getBirth()				
				);
		
		return cnt;
	}

}
