package com.kh.junit;

import java.sql.Types;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.kh.portfolio.member.dao.MemberDAOImplTest;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(locations = { "file:src/main/webapp/WEB-INF/spring/root-context.xml" })
public class SelectJdbcTemplateTest {
	private final static Logger logger = LoggerFactory.getLogger(MemberDAOImplTest.class);
	 
	
	@Inject
	JdbcTemplate jt;
	
	@Test
	@Disabled
	void Select1() {
		StringBuffer sql = new StringBuffer();
		sql.append("select id,name,kor,eng,mat from student ");
		
		// 하나의 레코드를 컬럼은 key, 값은 value를 매핑하여 맵객체를 만들고 List에  담아올 때 사용
		List<Map<String, Object>> list = jt.queryForList(sql.toString());
		for(Map<String,Object> item : list) {
			logger.info(item.toString());
		}
		
		
	}
	
	@Test
	@Disabled
	void select2() {
		StringBuffer sql = new StringBuffer();
		sql.append("select id,name,kor,eng,mat from student where kor>=90 ");
		List<Integer> list = jt.queryForList(sql.toString(), Integer.class);
		for(Integer i : list) {
			logger.info(i.toString());
		}
	}
	
	@Test
	@Disabled
	void select3() {
		StringBuffer sql = new StringBuffer();
		sql.append("select id,name,kor,eng,mat from student where kor>=? and mat >= ? ");
		
		List<Map<String, Object>> list = jt.queryForList(sql.toString(), 90, 90);
		for(Map<String,Object> item : list) {
			logger.info(item.toString());
		}
	}
	
	@Test
	@Disabled
	void select4() {
		StringBuffer sql = new StringBuffer();
		sql.append("select name from student where kor>=? and mat >= ? ");
		List<String> list = jt.queryForList(sql.toString(), String.class,80,80);
		for(String name : list) {
			logger.info(name);
		}
		
	}
	
	@Test
	@Disabled
	void select5() {
		StringBuffer sql = new StringBuffer();
		sql.append("select name from student where kor>=? and mat >= ? ");
		List<String> list = jt.queryForList(
				sql.toString(), new Object[] {80,80},
				String.class);
		for(String name : list) {
			logger.info(name);
		}
	}
	
	@Test
	@Disabled
	void select6() {
		StringBuffer sql = new StringBuffer();
		sql.append("select kor from student where kor>=? and mat >= ? ");
		List<Map<String,Object> > list = jt.queryForList(sql.toString(), 
				new Object[] {80,80}, 
				new int[] {Types.INTEGER, Types.INTEGER});
		
		for(Map<String,Object> item : list) {
			logger.info(item.toString());
		}
	}
	
	@Test
	@Disabled
	void select7() {
		StringBuffer sql = new StringBuffer();
		sql.append("select name from student where kor>=? and mat >= ? ");
		List<String> list = jt.queryForList(
				sql.toString(),
				new Object[] {80,80},
				new int[] {Types.INTEGER,Types.INTEGER},
				String.class
				);
		for(String item: list) {
			logger.info(item);
		}
	}
	@Test
	@Disabled
	void select10() {
		
	}
	
	@Test
	void select11() {
		StringBuffer sql = new StringBuffer();
		sql.append("select id,name,kor,eng,mat from student where id = 'id1' ");
		
		// 하나의 레코드를 키, 값 형태로 
		Map<String, Object> map = jt.queryForMap(sql.toString());
		logger.info(map.toString());
	}
	
}
