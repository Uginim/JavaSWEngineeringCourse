package com.kh.common;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * 풀링 테스트
 * 
 * @author Administrator
 *
 */
@WebServlet(name = "pt", description = "커넥션풀링 테스트", urlPatterns = { "/pt" })
public class PoolTest extends HttpServlet {
	private static final long serialVersionUID = 1L;
	Connection conn;

	public PoolTest() {
		super();
		// TODO Auto-generated constructor stub
	}

	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
	}

	public void destroy() {
		// TODO Auto-generated method stub

	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		try {

			conn = Dbcon.getConnection();
			System.out.println("커넥션 풀로부터 커넥션 객체 획득");

			// 쿼리수행
			String sql = "select * from book";
			PreparedStatement pstmt = conn.prepareStatement(sql);
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {

			}

			// 반납
			Dbcon.close();
			System.out.println("커넥션 풀로부터 커넥션 객체 반납 ");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			System.out.println("커넥션 객체 획득 오류" + e.getMessage());
		}

		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
