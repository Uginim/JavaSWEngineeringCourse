package com.kh.member.dao;

import java.util.List;

import com.kh.dto.MemberDTO;

public interface MemberDAO {
	// 회원가입
	int memberJoin(MemberDTO memberDTO);
	// 회원 조회(1명)
	MemberDTO memberSelect(String id);
	// 회원목록조회(전체)
	List<MemberDTO> memberList();
	// 회원수정
	int memberModify(MemberDTO memberDTO);
	// 회원탈퇴
	int memberOut(String id, String pw);
	// 로그인
	MemberDTO memberLogin(String id, String pw);
	// 아이디찾기
	String findID(String tel, String birth);
	// 비밀번호찾기
	boolean findAccount(String id, String tel, String birth);
	boolean changePW(String id, String pw);
	
}
