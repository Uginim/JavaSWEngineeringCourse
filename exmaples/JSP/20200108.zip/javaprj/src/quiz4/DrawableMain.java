package quiz4;

import java.util.Vector;

public class DrawableMain {
	public static void main(String[] args) {
		Vector <Drawable> shapes = new Vector<Drawable>(); 
		shapes.add(new DrawableCircle(10));
		shapes.add(new DrawableRectangle(10,20));
		shapes.add(new DrawableSquare(10,10,10));
		shapes.add(new DrawableSquare(3,4,5));		
		shapes.add(new DrawableRectangle(44.22,45.04));
		shapes.add(new DrawableCircle(10));
		// 부피 구하기 figureOutVolume();
//		System.out.println("부피는 "+new Square(3,4,5).figureOutVolume());
		for(int i=0;i< shapes.size();i++) {
			Drawable d = shapes.get(i);
			Shape s = (Shape)d;
			System.out.printf("[%d]번 %s의 넓이는 %.2f이고 둘레의 길이는 %.2f이다.%n%4s",i+1,d,s.figureOutArea(),s.figureOutCircumference(),"");
			d.draw();
		} 
	}
}
