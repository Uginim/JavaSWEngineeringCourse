package quiz4;

public class DrawableRectangle extends Rectangle implements Drawable {
	final static String name = "Rectangle";

	public DrawableRectangle(double width, double depth) {
		super(width, depth);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void draw() {
		// TODO Auto-generated method stub
		System.out.println(name+"를 그립니다.");
	}
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return name;
	}
}
