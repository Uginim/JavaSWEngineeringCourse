package quiz4;

abstract public class Shape {
	public abstract double figureOutArea ();
	public abstract double figureOutCircumference();
	@Override
	public String toString() {		
		return getClass().getSimpleName();
	}
}
