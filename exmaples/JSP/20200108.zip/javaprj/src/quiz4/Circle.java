package quiz4;

public class Circle extends Shape {
	private double radius;
	public Circle(double radius) {
		this.radius = radius;
	}
	@Override
	public double figureOutArea() {
		return Math.PI * 2 * radius; 
		
	}

	@Override
	public double figureOutCircumference() {
		// TODO Auto-generated method stub
		return Math.PI * radius * radius;
	}

}
