package quiz4;

public class DrawableSquare extends Square implements Drawable {
	final static String name = "Square";
	
	public DrawableSquare(double width, double depth, double height) {
		super(width, depth, height);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void draw() {
		// TODO Auto-generated method stub
		System.out.println(name+"를 그립니다.");
	}
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return name;
	}
}
