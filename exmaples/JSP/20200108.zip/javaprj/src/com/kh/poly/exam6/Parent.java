package com.kh.poly.exam6;

public class Parent {
	String parentField1;
	String parentField2;
	
	void method1() {
		System.out.println("Parent-method1()");
	}
	void method2() {
		System.out.println("Parent-method1()");
	}
	
}
