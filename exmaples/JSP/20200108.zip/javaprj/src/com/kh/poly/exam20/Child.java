package com.kh.poly.exam20;


public class Child extends Parent{
	int field = 20;
	
	public void method2() {
		System.out.println("Child-method2()");
	}
	public void method3() {
		System.out.println("Child-method3()");
	}
}
