package com.kh.poly.exam4;

public class BuyerMain {

	public static void main(String[] args) {

		Tv tv = new Tv();
		Computer computer = new Computer();
		Audio audio = new Audio();

		// 필드의 다형성
		Product p1 = new Tv();
		Product p2 = new Computer();
		Product p3 = new Audio();

		Buyer buyer = new Buyer();
		System.out.println("=================");
		buyer.buy(p1);
		buyer.buy(p2);
		buyer.buy(p3);
		System.out.println("=================");
		buyer.buy(tv);
		buyer.buy(computer);
		buyer.buy(audio);
		
		System.out.println("=================");
		buyer.buy(new Tv());
		buyer.buy(new Computer());
		buyer.buy(new Audio());
		
		buyer.getItemList();
		System.out.println(buyer);
	}

}
