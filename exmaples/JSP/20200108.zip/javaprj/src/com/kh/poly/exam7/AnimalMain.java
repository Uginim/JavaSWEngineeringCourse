package com.kh.poly.exam7;

public class AnimalMain {
	public static void main(String[] args) {
		
		// 추상클래스는 (미완성 클래스라)객체화 할 수 없지만 자식 인스턴스를 가리킬 수 있다.
//		Animal animal = new Animal();
		Animal animal1 = new Cat();
		Animal animal2 = new Dog();
		Animal animal3 = new Pig();
		
		animal1.cry();
		animal2.cry();
		animal3.cry();
		
	}
}
