package com.kh.poly.exam1;

public class D extends B{

}
