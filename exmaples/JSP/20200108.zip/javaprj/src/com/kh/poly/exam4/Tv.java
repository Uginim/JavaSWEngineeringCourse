package com.kh.poly.exam4;

public class Tv extends Product{
	public Tv() {
		super(300);
	}

	@Override
	public String toString() {
		return "Tv";
	}
	
}
