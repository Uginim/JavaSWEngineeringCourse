package com.kh.poly.exam3;

public class Audio extends Product{

}
