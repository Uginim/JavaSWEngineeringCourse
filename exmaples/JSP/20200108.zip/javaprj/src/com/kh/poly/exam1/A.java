package com.kh.poly.exam1;

public class A {

}
