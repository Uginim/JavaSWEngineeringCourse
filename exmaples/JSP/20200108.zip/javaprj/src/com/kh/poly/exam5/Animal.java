package com.kh.poly.exam5;

public class Animal {
	int age;					// 나이
	String color;			// 색상
	void cry() {
		System.out.println("울다");
	}
}
