package com.kh.poly.exam1;

public class C extends A{

}
