package com.kh.collcetion.list;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class LinkedListMain {

	public static void main(String[] args) {
		List<String> list1 = new ArrayList<>();
		List<String> list2 = new LinkedList<>();
		
		long startTime = 0l;
		long endTime = 0l;

		System.out.println("맨 앞에 추가하기");
		startTime = System.nanoTime();
		for(int i=0; i<100000;i++) {
			list1.add(0,String.valueOf(i));
		}
		endTime = System.nanoTime();
		System.out.printf("ArrayList걸린 시간:%d ns %n",endTime-startTime);
		
		startTime = System.nanoTime();
		for(int i=0; i<100000;i++) {
			list2.add(0,String.valueOf(i));
		}
		endTime = System.nanoTime();
		System.out.printf("LinkedList걸린 시간:%d ns %n",endTime-startTime);
		
		// 맨 앞부터 삭제
		System.out.println();
		System.out.println("맨 앞에부터 삭제");
		startTime = System.nanoTime();
		for(int i=0; i<100000;i++) {
			list1.remove(0);
		}
		endTime = System.nanoTime();
		System.out.printf("ArrayList걸린 시간:%d ns %n",endTime-startTime);		
		startTime = System.nanoTime();
		for(int i=0; i<100000;i++) {
			list2.remove(0);
		}
		endTime = System.nanoTime();
		System.out.printf("LinkedList걸린 시간:%d ns %n",endTime-startTime);
		
		// 맨 뒤에 추가
		System.out.println();
		System.out.println("맨 뒤에 추가하기");
		list1 = new ArrayList<>();
		list2 = new LinkedList<>();
		startTime = System.nanoTime();
		for(int i=0; i<100000;i++) {
			list1.add(String.valueOf(i));
		}
		endTime = System.nanoTime();
		System.out.printf("ArrayList걸린 시간:%d ns %n",endTime-startTime);
		
		startTime = System.nanoTime();
		for(int i=0; i<100000;i++) {
			list2.add(String.valueOf(i));
		}
		endTime = System.nanoTime();
		System.out.printf("LinkedList걸린 시간:%d ns %n",endTime-startTime);
		
		
		// 맨 뒤부터 삭제
		System.out.println();
		System.out.println("맨 뒤부터 삭제");
		startTime = System.nanoTime();
		for(int i=0; i<100000;i++) {
			list1.remove(list1.size()-1);
		}
		endTime = System.nanoTime();
		System.out.printf("ArrayList걸린 시간:%d ns %n",endTime-startTime);		
		startTime = System.nanoTime();
		for(int i=0; i<100000;i++) {
			list2.remove(list2.size()-1);
		}
		endTime = System.nanoTime();
		System.out.printf("LinkedList걸린 시간:%d ns %n",endTime-startTime);
		
		
	}
	
}
