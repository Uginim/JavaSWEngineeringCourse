package com.kh.collcetion.map;

import java.util.HashMap;
import java.util.Map;

public class ScoreManager {
	public static void main(String[] args) {
		Map<String,Integer> map = new HashMap<>();
		
		map.put("white", 80);
		map.put("balck", 90);
		map.put("red", 100);
		
		int totalScore=0;
		double average=0;
		int scoreHighest = Integer.MIN_VALUE;
		String idHighest = null;
		for(Map.Entry<String, Integer> entry: map.entrySet()) {
			int score = entry.getValue();
			totalScore +=score; 
			if(scoreHighest<score) {
				idHighest = entry.getKey();
				scoreHighest = score;
			}
		}
		average=(double)totalScore/map.size();
		System.out.println("총점 : " +totalScore);
		System.out.println("평균 : " + average);
		System.out.println("최고점수를 받은 아이디 : "+idHighest);
		System.out.println("\t"+idHighest+"의 점수:"+scoreHighest);
	}
}
