package com.kh.collcetion.list;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
/**
 * 2019.11.24 Java SW Engineering Course
 * @author Hyeonuk
 */
public class ArrayListMain {
	
	public static void main(String[] args) {
		List<String> list = new ArrayList<String>();
//		List<Integer> list = new ArrayList<Integer>();
		list.add("java");
		list.add("jdbc");
		list.add("servlet/jsp");
		list.add("html");
		list.add("css");
		list.add("javascript");
		
		// 컬렉션 요소 갯수
		int size = list.size();
		System.out.printf("총 객체 갯수: %d%n",size);
		System.out.println("======================");
		
		// 요소 검색 - 인덱스
		String element = list.get(2);
		System.out.println(element);
		System.out.println("======================");
		
		// 컬렉션 요소 전체 목록
		for(int i=0; i < list.size(); i++) {
			element = list.get(i);
			System.out.printf("%d : %s%n",i,element);
		}
		System.out.println("======================");
		
		// 컬랙션 요소 삭제
		list.remove(2);
		for(int i=0; i < list.size(); i++) {
			element = list.get(i);
			System.out.printf("%d : %s%n",i,element);
		}
		System.out.println("======================");
		
		// 요소 검색 - 특정 요소
		if(list.contains("java")) {
			System.out.println("java 있음!");
		}
		if(list.contains("servlet/jsp")) {
			System.out.println("servlet/jsp 있음!");			
		}
		System.out.println("======================");
		
		// 컬랙션 요소 전체 목록
		int cnt=0;
		for( String str : list) {
			System.out.println(++cnt+":"+str);
		}
		System.out.println("======================");
		
		// 배열을 리스트 계열로 전환하기
		List<String> list2 = Arrays.asList("길동","길순","길남","길서");
		for(String str: list2) {
			System.out.println(str);
		}
		List<Integer> list3 = Arrays.asList(1,2,3,4,5);
		for(Integer num: list3) {
			System.out.println(num);
		}
		
	}
	
}
