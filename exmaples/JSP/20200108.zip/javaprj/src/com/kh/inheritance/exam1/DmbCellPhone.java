package com.kh.inheritance.exam1;
/**
 * 2019.11.13 Java SW Engineering Course
 * @author Hyeonuk
 */
public class DmbCellPhone extends CellPhone {
	// 멤버 필드
	int channel;
	String color;	
	// 생성자
	public DmbCellPhone() {
		System.out.println("DmbCellPhone 생성자 호출!");
	}
	
	public DmbCellPhone(String model, String color, int channel) {
		this.model = model;
		this.color = color;
		this.channel = channel;		
	}
	
	// 멤버 메소드
	void turnOnDmb() {
		System.out.println("채널" + channel + "번 DMB 방송 수신시작~!");
	}
	
	void changeChannelDmb(int channel) {
		this.channel = channel;
		System.out.println("채널 " + channel + "번으로 변경!!");
	}
	
	void turnOffDmb() {
		System.out.println("DMB방송 수신 종료~!");
	}

	@Override
	public String toString() {
		return "DmbCellPhone [channel=" + channel + ", model=" + model + ", color=" + color + "]";
	}
	
}

