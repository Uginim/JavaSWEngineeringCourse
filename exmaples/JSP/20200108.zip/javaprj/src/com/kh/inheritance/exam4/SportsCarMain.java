package com.kh.inheritance.exam4;

public class SportsCarMain {
	public static void main(String[] args) {
		Car car = new Car();
		SportsCar sportsCar = new SportsCar();
		
		for(int i=1; i<10 ;i++) {
			car.speedUp();
			sportsCar.speedUp();			
			if(i == 5) {
				car.stop();
				sportsCar.stop();
				break;
			}
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}
