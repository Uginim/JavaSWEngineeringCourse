package com.kh.inheritance.exam2;

public class People {
	public String name;			// 이름
	public String ssn;			// 주민번호
	
	public People(String name, String ssn) {
		this.name = name;
		this.ssn = ssn;
	}

}
