package com.kh.inheritance.exam4;

public class Car {
	// 멤버 필드
	public int speed;
	
	// 멤버메소드
	public void speedUp() {
		speed++;
		System.out.println("현재 속도 :"+speed);
	}
	
//	public final void stop() {
	public void stop() {
		System.out.println("차를 멈춤");
		speed = 0;
	}
}
