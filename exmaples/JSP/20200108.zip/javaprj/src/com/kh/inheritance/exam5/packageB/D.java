package com.kh.inheritance.exam5.packageB;

import com.kh.inheritance.exam5.packageA.A;

public class D extends A{
	public D() {
		this.field = "홍길동";
		this.method();
	}
	public void method() {
//		A a = new A();
	}
}
