package com.kh.inheritance.exam3;

public class SupersonicAirplaneMain {
	public static void main(String[] args) {
		SupersonicAirplane supersonicAirplane = new SupersonicAirplane();
		
		supersonicAirplane.takeOff();
		supersonicAirplane.fly();		
		supersonicAirplane.flyMode = SupersonicAirplane.SUPERSONIC;
		supersonicAirplane.fly();
		supersonicAirplane.flyMode = supersonicAirplane.NOMAL;
		supersonicAirplane.fly();
		supersonicAirplane.land();
	}
}
