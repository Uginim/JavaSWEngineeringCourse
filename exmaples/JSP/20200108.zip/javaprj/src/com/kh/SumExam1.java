package com.kh;
/**
 * 문제 1) SumExam1
 * 1~100까지의 합구하기
	1) for문
	2) while문
	3) do~while문
 * @author Administrator
 *
 */
public class SumExam1 {
	public static void main(String[] args) {
		int sum=0;
		System.out.println("for문 ");
		for(int i=1;i<=100;i++) {
			sum+=i;
		}
		System.out.println("sum="+sum);
		System.out.println("=================");
		System.out.println("while문 ");
		int i=1;sum=0;
		while(i<=100) {
			sum+=i++;
		}
		System.out.println("sum="+sum);
		System.out.println("=================");
		System.out.println("do while문 ");
		i=0;sum=0;
		do {
			sum+=i++;
		} while(i<=100);
		System.out.println("sum="+sum);
		System.out.println("=================");
	}
}
