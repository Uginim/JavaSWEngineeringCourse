package com.kh.array;

import java.util.Arrays;

public class ArrayExam4 {
	public static void main(String[] args) {
		int[] array = new int[5];
		int max = Integer.MIN_VALUE;
		int min = Integer.MAX_VALUE;
		for(int i=0; i<array.length; i++) {
			array[i] = (int) (Math.random()*10)+1;
		}
		// 최대값 구하기
		for(int i=0; i<array.length; i++) {
			if(max <array[i]) {
				max = array[i];
			}
		}
		
		min = max;
		// 최소값 구하기
		for(int i=0;i<array.length;i++) {
			if(min > array[i]) {
				min = array[i];
			}
		}
		
		// 최대최소값구하기
		max = Integer.MIN_VALUE;
		min = Integer.MAX_VALUE;
		for(int i=0; i<array.length; i++) {
			if(max < array[i]) {
				max = array[i];
			}
			min = Math.min(min, array[i]);			 
		}
		System.out.println(Arrays.toString(array));
		System.out.println("최대값="+max);
		System.out.println("최소값="+min);
	}
}
