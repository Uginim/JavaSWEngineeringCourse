package com.kh.array;

public class MainStringArrayParam3 {
	public static void main(String[] args) {
		double result = 0.0;

		// 1) 실행 매개값 갯수 체크
		if (args.length != 3) {
			System.out.println("매개값 3개가 필요합니다.");
			System.exit(0);
		}
		// 2) 연산자 유효성 체크
		if(!checkOperator(args[1])) {
			System.out.println("4칙연산자 아닙니다.");
			System.out.println("프로그램 종료!");
			System.exit(0);
		}	

		// 3) 피연산자 정수유무 체크		 
		if (!checkOperand(args[0]) || !checkOperand(args[2]) ) {
			System.out.println("피연산자는 숫자이어야합니다.");
			System.out.println("프로그램 종료!");
			System.exit(0);
		}

		System.out.println("유효성 체크 통과!!");

		// 4) 연산 수행
		int num1 = Integer.parseInt(args[0]);
		int num2 = Integer.parseInt(args[2]);
		double resultValue = 0.0; // 4칙연산 결과를 저장하는 변수
		switch (args[1]) {
		// 덧셈
		case "+":
			resultValue = add(num1, num2);
			break;
		// 뺄셈
		case "-":
			resultValue = minus(num1, num2);
			break;
		// 곱셈
		case "x":
		case "X":
			resultValue = multi(num1, num2);
			break;
		// 나눗셈
		case "/":
			resultValue = divide(num1, num2);
			break;
		default:
			System.out.println("4칙연산자 아닙니다.");
			System.out.println("프로그램 종료!!");
			System.exit(0);
		}
		// 5) 연산결과 출력하기
		System.out.printf("%d %s %d = %.2f%n",num1,args[1], num2,resultValue);
	}
	/**
	 * 4칙 연산자(+,-,x,X,/) 유효성 체크
	 * @param string 연산자
	 * @return 4칙연산자이면 true
	 */
	private static boolean checkOperator(String string) {
		// 1개의 문자인지 체크, 그리고 +,-,x,/에 해당하는 문자인지 체크
		boolean flag = false;
		if (string.length() == 1) {
			switch (string) {
			case "+": case "-": case "x": case "X": case "/":
				flag = true;
				break;
			default:
				break;
			}
		}
		return flag;
	}
	/**
	 * 숫자인지 체크
	 * @param string 숫자인지 체크할 대상
	 * @return 숫자면 true 
	 */
	private static boolean checkOperand(String string) {
		// 1문자씩 읽어 들여서 모든 자릿수가 0~9 범위내에 포함되는지
		boolean isOperand = false;
		for (char ch : string.toCharArray()) {
			if (ch >= '0' && ch < '9') {
				isOperand = true;
			} else {
				isOperand = false;
				break;
			}
		}
		return isOperand;
	}
	/**
	 * 나눗셈연산
	 * @param num1 피연산자1
	 * @param num2 피연산자2
	 * @return 나눗셈 결과
	 */
	private static double divide(int num1, int num2) {		// 
		return (double) num1 / num2;
	}

	/**
	 * 곱셈연산
	 * @param num1 피연산자1
	 * @param num2 피연산자2
	 * @return 곱셈 결과
	 */
	private static double multi(int num1, int num2) {
		return num1 * num2;
	}

	/**
	 * 뺄셈연산
	 * @param num1 피연산자1
	 * @param num2 피연산자2
	 * @return 뺄셈결과
	 */
	private static double minus(int num1, int num2) {
		return num1 - num2;
	}

	/**
	 * 덧셈연산
	 * @param num1 피연산자1
	 * @param num2 피연산자2
	 * @return 덧셈 결과
	 */
	private static double add(int num1, int num2) {
		return num1 + num2;
	}
}
