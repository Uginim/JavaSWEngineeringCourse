package com.kh.array;
/**
 * 2019.10.29 Java SW Engineering Course
 * Main메소드 파라미터 입력
 * @author Hyeonuk
 *
 */
public class MainStringArrayParam {
	public static void main(String[] args) {
		if(args.length != 2) {
			System.out.println("매개값 2개가 필요합니다.");
			System.exit(0); // 프로그램 종료
		} else {
			System.out.println(args[0]);
			System.out.println(args[1]);			
		}
	}
}
