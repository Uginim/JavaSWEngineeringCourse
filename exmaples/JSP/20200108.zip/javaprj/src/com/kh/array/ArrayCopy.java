package com.kh.array;

import java.util.Arrays;

public class ArrayCopy {
	public static void main(String[] args) {
		int[] arr1 = new int[] {1,2,3,4,5}; // 배열 선언, 생성, 초기화
		int[] arr2 = new int[10]; // 배열선언, 생성
		ArrayExam1 exam1= new ArrayExam1();
		for(int i = 0; i<arr1.length; i++) {
			arr2[i] = arr2[i];
		}

		// 복사 전
		System.out.println(Arrays.toString(arr1));
		System.out.println(Arrays.toString(arr2));
		
		// for문을 이용해서 직접 복사
		for(int i=0; i<arr1.length; i++) {
			arr2[i] = arr1[i];
		}
		
		// 복사 후
		System.out.println(Arrays.toString(arr1));
		System.out.println(Arrays.toString(arr2));
		
		// 배열(arr2) 초기화 호출
		resetArray(arr2);
		System.out.println(Arrays.toString(arr2));
		
		for(int i=0; i<arr1.length; i++) {
			arr2[i+5] = arr1[i];
		}
		System.out.println(Arrays.toString(arr2));
		
		// arr1[1]~arr1[3] 값을 arr2[5]~arr2[7]에 복사하기
		// case1) for문
		System.out.println("-----for 문 이용---------------");
		resetArray(arr2);
		for(int i=0; i<3; i++) {
			arr2[i+5] = arr1[i+1];
		}
		System.out.println(Arrays.toString(arr2));
		
		// case2) System.arraycopy() 사용
		System.out.println("------System.arraycopy()-----");
		resetArray(arr2);

		System.arraycopy(arr1, 1, arr2, 5, 3);
		System.out.println(Arrays.toString(arr2));
	}
	
	// private
	private static void resetArray(int[] arr2) {
		for(int i=0; i<arr2.length;i++) {
			arr2[i] = 0;
		}		
	}

}
