package com.kh.array;

/**
 * 502호 학습자 자리 배치 2차원 배열로 표현하기
 * @author Hyeonuk
 *
 */
public class Array2Exam2 {
	public static void main(String[] args) {
//		String[][] students = new String[][] { 	{ "박용민", "이유동", "허은열", "김현욱", }
//																					, {	"백인환", "박서영", "백다래", "이두희", }
//																					, {	"신재웅", "오상훈", "박대진", "정재송", "이동근", }
//																					, {	"이명균", "전민식", "이한별", "강나래", } 
//																					};
		String[][] students = new String[4][];
		students[0] = new String[] {"김현욱", "허은열", "이유동", "박용민" };
		students[1] = new String[] {"백인환", "오상훈", "이두희" };
		students[2] = new String[] {"신재웅", "박대진", "정해송", "이동근" };
		students[3] = new String[] {"이명균", "전민식", "이한별", "강나래" };
		
		for(int i=0;i<students.length;i++) {
			System.out.print("{ ");
			for(int j=0;j<students[i].length;j++) {
				System.out.printf("%s%s",students[i][j],(students[i].length==j+1)?"":", ");
			}
			System.out.println(" }");
		} 
		System.out.println("반장님 : " + students[2][2]);
		System.out.println("부반장님 : " + students[0][3]);
		System.out.println("1조 조장님 : " + students[0][3]);
		System.out.println("2조 조장님 : " + students[1][3]);
		System.out.println("3조 조장님 : " + students[2][2]);
		System.out.println("4조 조장님 : " + students[3][2]);
		// 오늘의 주인공
		int row = (int)(Math.random()*students.length);
		int col = (int)(Math.random()*students[row].length);
		
		System.out.println("오늘의 주인공 : " + students[row][col]);
	}
	
	
}
