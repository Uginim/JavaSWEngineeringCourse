package com.kh;
/**
 * 2019.10.22 Java SW Engineering Course
 * loop statement Example 
 * Print stars like below

   *
  **
 ***
****

 * @author Hyeonuk
 */
public class StarPrinter {
	public static void main(String[] args) {
		// my solution
		int num=4;
		for(int i=0;i<num;i++) {
			for(int j=0;j<num;j++) {
				if(i+j+1<num) {
					System.out.print(" ");
				} else {
					System.out.print("*");
				}
				
			}
			System.out.println();
		}
		// other solutions
		System.out.println("------------1-----------");
		System.out.println("   *");
		System.out.println("  **");
		System.out.println(" ***");
		System.out.println("****");
		
		System.out.println("------------2-----------");
		System.out.printf("%4s%n","*");
		System.out.printf("%4s%n","**");
		System.out.printf("%4s%n","***");
		System.out.printf("%4s%n","****");
		
		System.out.println("------------3-----------");
		System.out.printf("%-4s%n","*");
		System.out.printf("%-4s%n","**");
		System.out.printf("%-4s%n","***");
		System.out.printf("%-4s%n","****");
		
		System.out.println("------------4-----------");
		for(int i=1; i<=4;i++) {
			for(int j=4; j>i; j--) {
				System.out.print(' ');
			}
			for(int j=1; j<=i; j++) {
				System.out.print('*');
			}
			System.out.println();
		}
		System.out.println("------------5----------");
		for(int i=1; i<=4; i++) {
			for(int j=4; j>=1;j--) {
				if(i<j) {
					System.out.print(' ');
				}else {
					System.out.print('*');
				}
			}
			System.out.println();
		}
	}
}
