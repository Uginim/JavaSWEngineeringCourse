package com.kh.exception.exam2;

public class TryCatchFinallyEx {
//	public static void main(String[] args) throws Exception {
	public static void main(String[] args) {
		try {
			Class clazz = Class.forName("java.lang.String");
		} catch (ClassNotFoundException e) {
//			e.printStackTrace();
			System.out.println("해당 클래스를 찾을 수 없습니다.");
		}
		findClass();
		try {
			findClass2();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static void findClass()  {
		// case 1) 예외 발생지점에서 직접 예외처리한 경우
		try {
			Class clazz = Class.forName("java.leng.String2");
		} catch (ClassNotFoundException e) {
			System.out.println("해당 클래스를 찾을 수 없습니다.");
//			e.printStackTrace();
		}
	}
	
	// case 2) 예외처리를 호출한 메소드로 위임한 경우
	public static void findClass2() throws ClassNotFoundException {
		Class clazz = Class.forName("java.leng.String2");
	}
}
