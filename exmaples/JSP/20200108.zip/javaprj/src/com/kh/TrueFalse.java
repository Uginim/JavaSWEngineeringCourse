package com.kh;

public class TrueFalse {

	public static void main(String[] args) {
		System.out.printf("소문자 : %d~%d%n대문자 : %d~%d%n숫자 : %d~%d%n",(int)'a',(int)'z',(int)'A',(int)'Z',(int)'0',(int)'9');
		boolean result;
		result = ((6%3)==0) && ((6%2) == 0);
		System.out.println(result);
		System.out.println("---------------");
		if( ((6%3)==0) && ((6%2) == 0)) {
			System.out.println("2와 3의 배수입니다.");
		}
		System.out.println("---------------");
		char charCode = '1';
		System.out.println((int)charCode);
		// 65 ~ 90
		if((charCode>='A')&& (charCode<='Z')) {
			System.out.println("대문자");
		}
		
		if((charCode>='a') && (charCode<='z')) {
			System.out.println("소문자");
		}
		
		if((charCode>='0') && (charCode<='9')) {
			System.out.println("숫자입니다");
		} else {
//			if(!(charCode>='0') && (charCode<='9')) 
			System.out.println("숫자가 아닙니다.");
		}		
		System.out.println((int)charCode);
		char character = ' ';
//		for(int i=0; i<=65535;i++) {
		for(int i=0; i<=128;i++) {
			character = (char) i;
			System.out.println(i + ">>" + character);
		}
		
		
		
	}

}
