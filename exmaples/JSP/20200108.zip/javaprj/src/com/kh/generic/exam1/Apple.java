package com.kh.generic.exam1;

public class Apple {

}
