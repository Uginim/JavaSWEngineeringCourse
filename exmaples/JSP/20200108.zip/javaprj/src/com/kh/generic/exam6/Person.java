package com.kh.generic.exam6;

import java.util.Objects;

public class Person {
	/* 멤버 필드 */
	private String name;
	private int age;
	
	public Person(String name, int age) {
		this.name = name;
		this.age = age;		
	}
	@Override
	public boolean equals(Object obj) {
		System.out.println("Person.equals()호출 됨");
		boolean result = false;
		if(obj instanceof Person) {
			Person p = (Person)obj;
			if(this.name.equals(p.name) && this.age == p.age) {
				result = true;
			}
		}
		return result;
	}
	
	@Override
	public int hashCode() {
		System.out.println("Person.hashCode()호출 됨");
//		return this.name.hashCode() + age;
		return Objects.hash(name,age);
	}
}
