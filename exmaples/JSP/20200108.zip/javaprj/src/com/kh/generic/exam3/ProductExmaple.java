package com.kh.generic.exam3;

import com.kh.poly.exam4.Tv;

public class ProductExmaple {
	public static void main(String[] args) {
		Product<Tv, String> product1 = new Product<Tv, String>();
//		product1.setKind(kind);
	}
}
