package com.kh.generic.exam2;

public class Apple {

}
