package com.kh.generic.exam5;

import java.util.Arrays;

public class WildCardMain {
	// Course 제너릭 타입인 인스턴스 다됨
	public static void registerCourse(Course<?> course) {
		System.out.println(course.getName() + " 수강생: "+Arrays.toString(course.getStudents()));
	}
	// Course 제너릭 타입인 인스턴스 중 Student와 Student 자손은 다 됨
	public static void registerCourseStudent(Course<? extends Student> course) {
		System.out.println(course.getName() + " 수강생: "+Arrays.toString(course.getStudents()));
	}
	// Course 제너릭 타입의 인스턴스 중 Student와 Student 자손은 다 됨
	public static void registerCourseWorker(Course<? super Worker> course) {
		System.out.println(course.getName() + " 수강생: "+Arrays.toString(course.getStudents()));
	}
	public static void main(String[] args) {
		Course<Person> personCourse = new Course<Person>("일반과정", 5);
		personCourse.add(new Person("일반인"));
		personCourse.add(new Worker("직장인"));
		personCourse.add(new Student("학생"));
		personCourse.add(new HighStudent("고등학생"));

//		Object[] person = personCourse.getStudents();
//		for(Object p: person) {
//			System.out.println(p);
//		}
		Course<Worker> workerCourse = new Course<>("직장인 과정", 5);
		workerCourse.add(new Worker("직장인"));
//		workerCourse.add(new Person("직장인척 하는 사람"));

		Course<Student> studentCourse = new Course<>("학생 과정", 5);
		studentCourse.add(new Student("학생"));
		studentCourse.add(new HighStudent("고등학생"));
		
		Course<Student> highStudentCourse = new Course<>("고등학생 과정", 5);
//		studentCourse.add(new Student("학생"));
		studentCourse.add(new HighStudent("고등학생"));

		registerCourse(personCourse);
		registerCourse(workerCourse);
		registerCourse(studentCourse);
		registerCourse(highStudentCourse);
		
		registerCourseStudent(studentCourse);
		registerCourseStudent(highStudentCourse);
		
		registerCourse(personCourse);
		registerCourse(workerCourse);
	}
}
