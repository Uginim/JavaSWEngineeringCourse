package com.kh.generic.exam2;

public class BoxMain {
	
	// 피호출자 : 파라미터(parameter) = 매개변수 = 인수
	// 호출자 : 아규먼트(argument) = 매개값 = 인자 
	public static void main(String[] args) {
		
		Box<String> box = new Box<String>();
		
		
		box.setObject("홍길동");
		String name = box.getObject();
		System.out.println(name);
		
		Box<Integer> box2 = new Box<Integer>();
		box2.setObject(44);
		System.out.println(box2.getObject());
		
		Box<Apple> box3 = new Box<Apple>();
		box3.setObject(new Apple());
		System.out.println(box3.getObject());
	}
}
