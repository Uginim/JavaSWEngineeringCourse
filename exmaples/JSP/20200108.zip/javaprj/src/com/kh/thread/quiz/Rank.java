package com.kh.thread.quiz;

import javax.swing.JOptionPane;

public class Rank {
	int rank;
	public void finishLine(int number) {
		rank = ++Horse.cnt;
		
		System.out.println(number+"번 말의 순위 :" + rank);
		if(rank == 1) {
			System.out.println("1등 : " + number+"번 말입니다");
			JOptionPane.showMessageDialog(null, "1등 : " + number+"번 말입니다");
		}
	}
}
