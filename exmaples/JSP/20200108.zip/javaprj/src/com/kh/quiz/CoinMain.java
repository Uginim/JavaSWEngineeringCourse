package com.kh.quiz;

import java.util.Scanner;

public class CoinMain {

	public static void main(String[] args) {
		// 동전 생성
		Coin coin = new Coin();
		while(true) {
		// 동전 던진다.
		coin.throwCoin();
			System.out.println("\"앞면\" | \"뒷면\" 중 하나를 입력하세요\n(종료하려면 \"q\"입력)");
			//던저진 동전의 앞, 뒷면 맞추기
			Scanner sc = new Scanner(System.in);
			String input = sc.nextLine();
			if(input.equalsIgnoreCase("q")) {
				System.out.println("종료합니다.");
				break;
			}
				
			System.out.println("정답은 "+coin.getCurrentSideString()+"이였습니다.");
			if(coin.getCurrentSideString().equals(input)) {
				System.out.println("정답");
			}else if(Coin.changeToString(1-coin.getCurrentSide()).equals(input)) {
				System.out.println("오답!");
			} else {
				System.out.println("잘못된 답변입니다.");
			}
			System.out.println();
		}
	}
	
}
