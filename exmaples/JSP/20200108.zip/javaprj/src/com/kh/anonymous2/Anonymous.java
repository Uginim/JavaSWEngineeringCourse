package com.kh.anonymous2;

public class Anonymous {
	Vehicle field = new Bycle();
	void method1() {
		Vehicle local = new Car();
		local.run();
	}
	void method2(Vehicle a) {
		a.run();
	}
}
