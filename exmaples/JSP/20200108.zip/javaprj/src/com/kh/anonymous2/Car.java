package com.kh.anonymous2;

public class Car implements Vehicle {

	@Override
	public void run() {
		System.out.println("승용차, 가고싶은데로 간다!");

	}

}
