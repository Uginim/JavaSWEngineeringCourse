package com.kh;

import java.util.Scanner;

/**
 * 2019.10.22 Java SW Engineering Course
 * 국어 영어 수학 점수 입력받아서 합계 평균 구하기  
 * @author Hyeonuk
 *
 */
public class Sum_Avg {

	public static void main(String[] args) {
		
		/*
		// 1) 변수 선언(합계, 평균)
		// 2) 사용자로부터 점수입력받기
		// 3) 점수 누적하기("q"입력시까지)
		// 4) 평균 출력하기("입력받은 점수 누적" / "입력받은 점수 개수")
		int sum=0;
		int count =0;
		double avg=0.0;
		Scanner scan = new Scanner(System.in);
		System.out.println("합계를 구할 점수를 계속 입력하세요(종료시 q입력)");
		while(true) {
			String input = scan.nextLine();
			if(input.equals("q")) {
				break;
			}				
			else {
				sum+=Integer.parseInt(input);
				count++;
			}
		}
		avg = sum*1.0d/count;
		System.out.println("평균="+avg+" 합계="+sum);
		*/
		
		// --- 이하 선생님 코드
		// 0입력받을 때 종료되는 것으로 문제가 바뀜
		
		// 1) 변수 선언(합계, 평균)
		int score = 0; 		// 점수
		int sum = 0; 			// 합계	
		double ave = 0.0; // 평균
		boolean flag = true;		
		int count = 0; // 입력받은 점수 카운트
		System.out.println("합계, 평균을 구할 점수를 입력하세요(종료: 0을 입력)");
		do {
		// 2) 사용자로부터 점수입력받기
			count++;
			System.out.println(count +" 점수>>");;
			
			Scanner scanner = new Scanner(System.in);
			String tmp = scanner.nextLine();
			score = Integer.parseInt(tmp);
		// 3) 점수 누적하기(종료조건: 사용자가0 입력시)
			if(score != 0) {
				sum += score;
			} else {
				count--;
				flag = false;
			}
		} while(flag);
		// 4) 평균 출력하기("입력받은 점수 누적" / "입력받은 점수 개수")
		System.out.println("총합계= "+sum);
		
		ave = sum / (double)count;
		System.out.println("평균= "+ave);
	}

}
