package com.kh.quiz2;

public class FakeDice extends Dice{
	int fakeNumber ;
	static boolean fake;
	void setNumber(int number) {
		fakeNumber=number;		
	}
	@Override
	public void castDice() {
		// TODO Auto-generated method stub		
	}
	@Override
	public int getNumber() {
		// TODO Auto-generated method stub
		if(fake)
			return fakeNumber;
		else 
			return super.getNumber();
	}
	
}
