package com.kh.quiz2;
/**
 * 2019.11.14 Java SW Engineering Course
 * @author Hyeonuk
 */
public class Dice {
	private int number; // 주사위의 현재면
	private final int MAX = 6;
	
	// 주사위 굴리기
	public void castDice() {
		number = (int)(Math.random()*MAX)+1;
	}

	// 주사위값 반환
	public int getNumber() {
		return number;
	}
	

}
