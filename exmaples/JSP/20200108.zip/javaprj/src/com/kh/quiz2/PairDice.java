package com.kh.quiz2;
/**
 * 2019.11.14 Java SW Engineering Course
 * @author Hyeonuk
 */
public class PairDice {
	Dice[] dices ;
	{
		dices = new Dice[2];
		dices[0] = new Dice();
		dices[1] = new Dice();
	}
	public void castTwoDices() {
		for(Dice dice : dices) {
			dice.castDice();
		}
	}
	public int getSum() {
		return dices[0].getNumber() + dices[1].getNumber();
	}
	
	// 두개의 주사위중 하나의 결과반환
	public int getDiceNumber(int which) {
		if( which<1||2<which) {
			System.out.println("잘못된 주사위 번호\n1이나2를 입력해주세요");
			return -1;
		}else {
			return dices[which-1].getNumber();
		}	
			
	}
	
	@Override
	public String toString() {
		return String.format("두 주사위의 결과:%n첫번째주사위:[%d]%n두번째주사위:[%d]%n합계:%d %n"
				,dices[0].getNumber()
				,dices[1].getNumber()
				,getSum());
	}
	
	
	
	
}
