package com.kh;

public class Person {
	int score = 0;
	public void add10() {
		this.score =10;
	}
	public static void main(String[] args) {
		Person aPerson = new Person();
		Person bPerson = new Person();
		bPerson.add10();
		aPerson.score = 50;
		System.out.println(aPerson.score);
		System.out.println(bPerson.score);
	}
}
