package com.kh.object.exam1;
/**
 * 계산기 : 덧셈, 뺄셈
 * 2019.11.06 Java SW Engineering Course
 * @author Hyeonuk
 * @version 1.0.0
 *
 */
public class Calculator {
	// 속성
	/**
	 * 제조사
	 */
	String maker; // 제조사
	
	// 행위
	/**
	 * 덧셈
	 * @param num1 피연산자1
	 * @param num2 피연산자2
	 * @return 덧셈 결과
	 */
	public int plus(int num1, int num2) {
		int result = 0;		
		result = num1 + num2;
		System.out.println(maker+": 덧셈한 결과");
		return result;
		// return num1 + num2;
	}
	
	/**
	 * 뺄셈
	 * @param num1 피연산자1
	 * @param num2 피연산자2
	 * @return 뺄셈 결과
	 */
	public int minus(int num1, int num2) {
		int result = 0;
		result = num1 - num2;
		System.out.println(maker+": 뺄셈한 결과");
		return result;
	}
}
