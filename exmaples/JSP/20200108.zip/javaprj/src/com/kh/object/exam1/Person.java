package com.kh.object.exam1;




import java.io.PrintStream;

/**
 * 2019.11.06 Java SW Engineering Course
 * @author Hyeonuk
 *
 */
public class Person {
	// 속성,특성	
	String name; 						// 이름
	
	Calculator calculator; 	// 계산기
	public Person() {//
	}
	// 생성자(Constructor)
	public Person(String name, Calculator calculator) {//
		this.name = name;
		this.calculator = calculator;
	}
	
	// 행위(동작)
	public void smile() {
		System.out.println(name + "(이)가 웃다");
	}
	
	public void eat() {
		System.out.println(name + "(이)가 먹다");
	}
	
	// 계산기를 사용하여 덧셈하는 행위
	// 관계설정 방법
	// case 1)
	// 메소드의 매개값으로 받아서 calculator를 사용
//	public void doPlus(Calculator calculator, int num1, int num2) {
//		int result = calculator.plus(num1, num2);
//		System.out.println("덧셈결과 :" + result);
//	}
	// case 2)
	// 메소드를 이용해 맴버필드에 넣어줌
	public void doPlus(Calculator cal, int num1, int num2) {
		calculator= cal;
		int result = calculator.plus(num1, num2);
		System.out.println("덧셈결과 :" + result);
	}
	// case 3)
	// 생성자를 통해 넣었던 맴버필드의 calculator 사용
	public void doPlus(int num1, int num2) {
		int result = this.calculator.plus(num1, num2);
		System.out.println("덧셈결과 :" + result);
	}
	// 계산기를 사용하여 뺄셈하는 행위
	
}
