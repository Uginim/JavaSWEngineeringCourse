package com.kh.object.exam1;
/**
 * 2019.11.06 Java SW Engineering Course
 * @author Hyeonuk
 *
 */
public class PersonMain {
	int a;
	public static void main(String[] args) {		
		// Person 객체 생성		
		Person person2 = new Person();
		person2.name = "홍길동";
		person2.smile();
		person2.eat();
		
		System.out.println("---------------------");
		Person person3 = new Person();
		person3.name = "홍길순";
		person3.smile();
		person3.eat();
		
		System.out.println("---------------------");
		// Calculator 객체 생성
		Calculator calculator = new Calculator();
		// 가상세계에 만들어진 계산기한테 덧셈행위
		
		Calculator calculator2 = new Calculator();
		calculator2.maker = "카시오";
		
		Calculator calculator3 = new Calculator();
		calculator3.maker = "모나미";	
		
		System.out.println(calculator2.plus(10, 20));
		System.out.println(calculator3.plus(10, 20));
		
	}
}
