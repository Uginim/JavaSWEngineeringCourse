package com.kh.object.exam6;

public class CarMain {
	public static void main(String[] args) {
		Car car1 = new Car("기아","2500","빨간색");
		System.out.println(car1.toString());
		
		Car car2 = new Car("현대", "3000", "검정");
		System.out.println(car2);
//		System.out.println(car2.getCc());
		
		Car car3 = new Car("쉐보레","2000","흰색");
		System.out.println(car3);
		
		System.out.println("총생산량 : " + Car.getCnt());
	}
}
