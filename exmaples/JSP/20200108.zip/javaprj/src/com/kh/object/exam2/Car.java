package com.kh.object.exam2;
/**
 * Car 클래스
 * 2019.11.06 Java SW Engineering Course
 * @author Hyeonuk
 *
 */
public class Car {
	public String maker;
	public String cc;
	public String color;
	
	public void run(int speed) {
		System.out.println(maker+"(이)가 "+speed+"km/h로 달립니다");
	}
	public void stop() {
		System.out.println(maker+"(이)가 멈췄습니다");
	}
	public void onRadio() {
		System.out.println("라디오가 켜졌습니다.");
	}
}
