package com.kh.object.exam8;

public class VarArgsEx {
	String str1;
	String str2;
	String str3;
	
	public void printStr(String...str) {
		System.out.println(str.length);
	}
	
	public void printStr2(String...str) {
		System.out.println(str.length);
	}
	
	public void printStr3(int num, String... str) {
		
	}
	/*
	public void printStr4(String... str,int num) { // 성립하지 않음
		
	}
//	*/	
	public void printStr5(String... str) { // 성립하지 않음
		
	}
}
