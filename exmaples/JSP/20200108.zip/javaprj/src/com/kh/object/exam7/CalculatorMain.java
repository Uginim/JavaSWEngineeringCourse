package com.kh.object.exam7;

public class CalculatorMain {

	public static void main(String[] args) {
		Calculator cal = new Calculator();
		System.out.println(cal);
		System.out.println(cal.toString());
		System.out.println(cal.countCalculator);
		System.out.println(Calculator.getCountCalculator2());
		
		cal.maker = "모나미";
		System.out.println(cal.maker);

		// 정적멤버는 객체를 생성하지 않고 클래스명으로 접근 가능하다.
		Calculator.maker = "카시오";
		System.out.println(cal.maker);		
		System.out.println(Calculator.maker);
		
		System.out.println("-----------------------");
		Calculator cal2 = new Calculator();
		System.out.println(cal2.countCalculator);
		System.out.println(Calculator.getCountCalculator2());
	}

}
