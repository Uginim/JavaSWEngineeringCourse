package com.kh.object.exam6;

import java.lang.*;

public class Car extends Object {
	private String maker;	// 제조사
	private String cc;		// 배기량
	private String color;	// 색상
	
	static int cnt; // 차량 생산 대수
	
	public Car() {
		super(); // 엄밀히 얘기하면 생략됨
		cnt++;
		countCar();
	}
	public Car(String maker) {
//		this.maker = maker;
		countCar();
		setMaker(maker);
	}

	public Car(String maker, String cc) {
//		this.maker = maker;
//		this.cc = cc;
		countCar();
		setMaker(maker);
		setCc(cc);
	}

	public Car(String maker, String cc, String color) {
		countCar();
		setMaker(maker);
		setCc(cc);
		setColor(color);
	}
	
	public void run() {
		
	}
	public void stop() {
		
	}
	
	public void countCar() {
		cnt++;
	}
	public static int getCnt() {
		return cnt;
	}
	
	public String getMaker() {
		return maker;
	}
	public void setMaker(String maker) {
		this.maker = maker;
	}
	public String getCc() {
		return cc+"CC";
	}
	public void setCc(String cc) {
		this.cc = cc;
	}
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	@Override
	public String toString() {
		return "Car [maker=" + maker + ", cc=" + cc + ", color=" + color + "]";
	}
	
}
