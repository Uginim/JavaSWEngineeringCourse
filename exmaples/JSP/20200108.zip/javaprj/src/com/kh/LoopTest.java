package com.kh;
/**
 * 2019.10.22 Java SW Engineering Course
 * Named Loop Practice 
 * @author Hyeonuk
 */
public class LoopTest {
	int score;
	public static void main(String[] args) {
		LoopTest loop = new LoopTest();
		loop.score = 100;
		
		int num = 100;
		outter: for(int i=0;i<10;i++) {
			num-=6;
			for(int j=0; j<10;j++) {
				num-=2;
				if(num<0) {					
					System.out.println("num is less than 0");
					break outter;
				}
			}
		}
			System.out.println("ended");;
	}
}
