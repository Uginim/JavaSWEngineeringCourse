package com.kh.abs;

public class SmartPhone extends Phone {
	// 5) abstract class를 상속받는 ㅋ믈래스에서는 abstract method를 반드시 구현해야한다.
	@Override
	public void method1() {
		
	}
}
