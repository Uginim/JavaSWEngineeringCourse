package com.kh.abs;

public class PhoneMain {
	
	public static void main(String[] args) {
		// 1) abstract class는 인스턴스 생성 불가.
//		Phone p = new Phone();
		
		SmartPhone sp = new SmartPhone();
		
		// 2) abstract class는 선언시 타입으로 사용 가능하다.
		Phone p2 = new SmartPhone();
		
	}
}
