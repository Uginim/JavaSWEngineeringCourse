package com.kh.inter;

public class RemoteControlMain {
	public static void main(String[] args) {
		// 1) 인터페이스는 인스턴스를 생성할 수 없다.
		// RemoteControl remoteControl = new RemoteControl():
		System.out.println(RemoteControl.MAX_VOLUME);
		System.out.println(RemoteControl.MIN_VOLUME);
		
		RemoteControl tv;
		tv = new Tv();
		
		// 자동 형변환
		RemoteControl tv2 = new Tv();
		tv2.turnOn();
		tv2.setVolume(5);
		tv2.turnOff();
		RemoteControl.changeBattery();
		
		System.out.println("=====================");
		RemoteControl audio = new Audio();
		audio.turnOn();
		audio.setVolume(4);
		audio.setVolume(11);
		audio.turnOff();
		RemoteControl.changeBattery();
		
		System.out.println("=====================");
		SmartTv smartTv = new SmartTv();
		RemoteControl remoteControl = smartTv;
		smartTv.turnOn();
		smartTv.setVolume(10);
		smartTv.setMute(true);
		smartTv.turnOff();
		
		Searchable searchable = smartTv;
		searchable.search("http://www.google.com");
		
		
	}

}
