package com.kh.inter;

public interface SmartRemoteControl extends RemoteControl, Searchable {

}
