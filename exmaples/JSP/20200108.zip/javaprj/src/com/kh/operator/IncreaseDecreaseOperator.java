package com.kh.operator;
/**
 * 2019.10.25 Java SW Engineering Course
 * 증감연산자( ++, -- )
 * @author Hyeonuk
 * @version 1.0
 * 
 */
public class IncreaseDecreaseOperator {
	/**
	 * 구분선 추가 
	 */
	public static void seperator() {
		System.out.println("---------------------");
	}
	public static void main(String[] args) {
		int x = 10;
		int y = 10;
		int z;
		

		seperator(); 		// 증감연산자 단독사용
		x++;
		++x;
		System.out.println("x=" + x);		
		y++;
		++y;
		System.out.println("y=" + y);
		seperator();
		
		z = ++x; // x=13, y=12, z=13 
		System.out.println("z=" + z); 
		System.out.println("x=" + x);
		seperator();
		
		z = x++; 	// x=14, y=12, z=13
		System.out.println("z=" + z); 
		System.out.println("x=" + x);	
		seperator();

		z = ++x + y++; // x=15, y=13, z=27 	
		System.out.println("x=" + x); 
		System.out.println("y=" + y);
		System.out.println("z=" + z); 
		seperator();
	}
}
