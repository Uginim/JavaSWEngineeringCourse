package com.kh.operator;
/**
 * 2019.10.25 Java SW Engineering Course 
 * @author Hyeonuk 
 */
public class OperatorExam {

	public static void main(String[] args) {
		int num1 = 6;
		boolean result = false;
		
		result  = num1 % 3 == 0 && ++num1 % 2 == 0;
		
		System.out.println("result="+result);
	}

}
