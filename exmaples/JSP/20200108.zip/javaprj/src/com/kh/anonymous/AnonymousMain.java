package com.kh.anonymous;

public class AnonymousMain {
	public static void main(String[] args) {
		Anonymous anony = new Anonymous();
		anony.field.run();
		anony.method1();
		anony.method2(new Vehicle() {
			
			@Override
			public void run() {
				System.out.println("스포츠카, 가고싶은데로 간다!");
				
			}
		});
		new Thread() {
			public void run() {
				System.out.println("hi");
			};
		}.start();;
	}
}
