package com.kh.anonymous.exam2;

public class ParentMain {
	public static void main(String[] args) {
		
		Parent parent = new Child();
		((Child)parent).method1();
		
		Parent parent2 = new Parent() {
			public void method1() {
				System.out.println("이름 없는 클래스:method1()호출됨");
			}
		};		
		parent2.method1(); //		참조할 수 있는 방법이 없음
	}
}
