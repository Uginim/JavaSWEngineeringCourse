package com.kh;
/**
 * 문제 4) SumExam4
 * 구구단(2~9단까지) 출력하기(중첩 반복문사용)
	1) for문
	2) while문
	3) do~while문
 * @author Hyeonuk
 */	
public class SumExam4 {
	public static void main(String[] args) {		
		System.out.println("for문 ");
		for(int i=2;i<=9;i++) {
			System.out.println(i+"단");
			for(int j=1 ; j<=9 ; j++) {
				System.out.println(i+" x "+j+" = "+(i*j));
			}
		}
		System.out.println("=================");
		System.out.println("while문 ");
		int i=2;
		while(i<=9) {
			int j=2;
			System.out.println(i+"단");
			while(j<=9) {
				System.out.println(i+" x "+j+" = "+(i*j));
				j++;
			}
			i++;
		}
		System.out.println("=================");
		System.out.println("do while문 ");
		i=2;
		do {
			int j=2;
			System.out.println(i+"단");
			while(j<=9) {
				System.out.println(i+" x "+j+" = "+(i*j));
				j++;
			}
			i++;
		} while(i<=9);
		System.out.println("=================");
	}
}
