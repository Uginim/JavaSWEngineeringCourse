package com.kh.control;

public class ArrayExam1 {

	public static void main(String[] args) {
//		int[] arr = {10, 20, 30, 40, 50};
		int sum = 0; 
		
		int num1 = 10;
		int num2 = 20;
		int num3 = 30;
		int num4 = 40;
		int num5 = 50;
		
		sum = num1 + num2 + num3 + num4 + num5 ; 
		System.out.println("num1~num5까지의 합 = " + sum);
		
		System.out.println("-----------------------");
		
//		int num[] = {10, 20, 30, 40, 50};
		int num[] = {10, 20, 30, 40, 50, 60};
		System.out.println("배열의 크기="+ num.length);
		
		sum = 0;
//		for(int i=0; i<=4; i++) {
//			System.out.println(num[i]);
//		}
		for(int i=0; i<num.length ;i++) {
			sum += num[i]; // sum = sum + num[i];
//			System.out.println(num[i]);
		}
		System.out.println("num배열의 총 합=" + sum);

	}

}
