package com.kh;

import java.util.Scanner;
/**
 * 2019.10.23 Java SW Engineering Course
 * Make a Calculator 
 * @author Hyeonuk
 *
 */

public class Calculator {

	public static void main(String[] args) {
		int result;
		Scanner scan = new Scanner(System.in);
		outer: while(true) {
			System.out.println("(1) 덧셈 \r\n" + 
					"(2) 뺄셈\r\n" + 
					"(3) 곱셈\r\n" + 
					"(4) 나눗셈\r\n" + 
					"원하는 메뉴(1~4)를 선택하세요. (종료:0)>");
			String inputedLine = scan.nextLine();
			int menu = Integer.parseInt(inputedLine);
			if(menu>4|| menu<1)
				continue;
			while(true) {
				System.out.println("계산할 값(피연산자1)을 입력하세요.(계산 종료:0, 전체 종료:99)>");
				inputedLine = scan.nextLine();
				int op1 = Integer.parseInt(inputedLine);
				if(op1==0)break;
				if(op1==99)break outer;
				System.out.println("계산할 값(피연산자2)을 입력하세요.(계산 종료:0, 전체 종료:99)>");
				inputedLine = scan.nextLine();				
				int op2 = Integer.parseInt(inputedLine);
				if(op2==0)break;
				if(op2==99)break outer;								
				switch(menu) {
				case 1:
					System.out.printf("계산결과>> %d + %d = %d%n",op1,op2,op1+op2);					
					break;
				case 2:
					System.out.printf("계산결과>> %d - %d = %d%n",op1,op2,op1-op2);
					break;
				case 3:
					System.out.printf("계산결과>> %d * %d = %d%n",op1,op2,op1*op2);
					break;
				case 4:
					System.out.printf("계산결과>> %d / %d = %f%n",op1,op2,op1/(double)op2);
					break;
				default:
				}
			}
		}

	}

}
