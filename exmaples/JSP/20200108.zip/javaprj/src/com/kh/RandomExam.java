package com.kh;
/**
 * 2019.10.22 Java SW Engineering Course
 * 국어 영어 수학 점수 입력받아서 합계 평균 구하기  
 * @author Hyeonuk
 *
 */
public class RandomExam {

	public static void main(String[] args) {
		for(int i=1; i<=6; i++) {
			System.out.println((int)(Math.random()*45)+1);
		}
	}

}
