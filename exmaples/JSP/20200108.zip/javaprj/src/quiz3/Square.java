package quiz3;

public class Square extends Rectangle{
	private double height;
	public Square(double width, double depth, double height) {
		super(width, depth);
		// TODO Auto-generated constructor stub
		this.height = height;
	}

	@Override
	public double figureOutArea() {		
		return height*getDepth()*2+height*getWidth()*2+getWidth()*getDepth()*2;
	}

	@Override
	public double figureOutCircumference() {
		// TODO Auto-generated method stub
		return (height + getWidth()+getDepth() )*4;
	}
	
	public double figureOutVolume() {
		return height * getWidth() * getDepth();
	}

}
