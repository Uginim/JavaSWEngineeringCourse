package com.kh.db;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.kh.dto.Book;

/**
 * Servlet implementation class UpdateServlet
 */
@WebServlet(name = "update", description = "수정하기", urlPatterns = { "/update" })
public class UpdateServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	Connection conn = null;
	private String URL = "jdbc:oracle:thin:@127.0.0.1:1521:xe";
	private String ID = "madang";
	private String PW = "madang";
	
    public UpdateServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	public void init(ServletConfig config) throws ServletException {
		super.init();
		System.out.println("멤버변수 초기화:DB연결");
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection(URL, ID, PW);
			System.out.println("	");
		} catch (Exception e) {
			System.out.println("연결실패!");
		}
	}

	public void destroy() {
		try {
			if (conn != null) {
				conn.close();
				System.out.println("연결종료");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doAction(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doAction(request, response);
	}
	
	private void doAction(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
		request.setCharacterEncoding("utf8");
		String bookid = request.getParameter("bookid");
		String bookname = request.getParameter("bookname");
		String publisher = request.getParameter("publisher");
		String price = request.getParameter("price");
		System.out.println(bookid +"," + bookname + "," +publisher+","+price);

		response.setContentType("text/html;charset=utf8;");
		String sql = "update book set bookname = ?, publisher = ?, price = ? where bookid=? ";
		PreparedStatement pstmt;
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, bookname);
			pstmt.setString(2, publisher);
			pstmt.setString(3, price);
			pstmt.setString(4, bookid);
			
//			pstmt.setInt(4, Integer.parseInt(bookid));
			System.out.println(pstmt.toString());
			int r = pstmt.executeUpdate();
			System.out.println("r :" + r);
//			request.getRequestDispatcher("select").forward(request, response);
			response.sendRedirect("select");
		} catch (SQLException e) {
			e.printStackTrace();
			PrintWriter out = response.getWriter();
			out.append("<script>");
			out.append(" alert('도서수정 오류발생');");
			out.append(" history.go(-1);");
			out.append("</script>");
		}
		
	}
	

}
