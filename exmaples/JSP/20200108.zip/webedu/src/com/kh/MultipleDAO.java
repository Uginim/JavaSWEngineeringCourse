package com.kh;

public class MultipleDAO {
	public int Multiple(int param1, int param2) {
		return param1*param2;
	}	
}
