package com.kh;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class FormService
 */
@WebServlet("/Form.do")
public class Member extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public Member() {
        super();
        // TODO Auto-generated constructor stub
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		String id = request.getParameter("id");
		String pw = request.getParameter("pw");
		System.out.println("id:"+id);
		System.out.println("pw:"+pw);
		String fruits[] = request.getParameterValues("fruit");
		for (String fruit : fruits) {
			System.out.println("fruit:"+fruit);
		}
		String sex = request.getParameter("sex");
		System.out.println("sex: "+sex);
		String job = request.getParameter("job");
		System.out.println("job: "+job);
		String data = request.getParameter("data");
		System.out.println("data: "+data);		
		String file = request.getParameter("file");
		System.out.println("file:"+file);
		// 2) 사용자 요청정보를 이용하여 연산처리
		// 3) 처리결과를 응답
		response.setContentType("text/html); charset=utf-8");
		PrintWriter out = response.getWriter();
		out.println("아이디 : "+id);
		out.println("비밀번호 : "+id);
		out.println("좋아하는 과일 : ");
		for(String fruit : fruits) {
			out.println(fruit +" ");
		}
		out.println("성별 : "+sex);
		out.println("직업 : "+job);
		out.println("텍스트 : "+data);
		out.println("파일명 : "+file);
		
	}

}
