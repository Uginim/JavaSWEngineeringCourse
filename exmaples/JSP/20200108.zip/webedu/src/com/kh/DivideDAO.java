package com.kh;

public class DivideDAO {
	public double divide(int param1, int param2) {
		return (double)param1/param2;
	}	
}
