package com.kh;

public class MinusDAO {
	public int sub(int param1, int param2) {
		return param1-param2;
	}	
}
