package com.kh.dto;

import java.util.Date;

public class MemberDTO {
	
	private String id;				// ID	아이디(이메일)	X			VARCHAR2
	private String pw;				//PW	비밀번호				VARCHAR2
	private String tel; 			//TEL	전화번호				VARCHAR2
	private String nickname;	//NICKNAME	별칭				VARCHAR2
	private String gender;		//GENDER	성별('남','여')				CHAR
	private String region;		//REGION	지역				VARCHAR2
	private Date birth;				//BIRTH	생년월일('yyyymmdd')				DATE
	private Date cdate;				//CDATE	생성일시		sysdate		DATE
	private Date udate;				//UDATE	변경일시		sysdate		DATE
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getPw() {
		return pw;
	}
	public void setPw(String pw) {
		this.pw = pw;
	}
	public String getTel() {
		return tel;
	}
	public void setTel(String tel) {
		this.tel = tel;
	}
	public String getNickname() {
		return nickname;
	}
	public void setNickname(String nickname) {
		this.nickname = nickname;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getRegion() {
		return region;
	}
	public void setRegion(String region) {
		this.region = region;
	}
	public Date getBirth() {
		return birth;
	}
	public void setBirth(Date birth) {
		this.birth = birth;
	}
	public Date getCdate() {
		return cdate;
	}
	public void setCdate(Date cdate) {
		this.cdate = cdate;
	}
	public Date getUdate() {
		return udate;
	}
	public void setUdate(Date udate) {
		this.udate = udate;
	}
	@Override
	public String toString() {
		return "MemberDTO [id=" + id + ", pw=" + pw + ", tel=" + tel + ", nickname=" + nickname + ", gender=" + gender
				+ ", region=" + region + ", birth=" + birth + ", cdate=" + cdate + ", udate=" + udate + "]";
	}
}
