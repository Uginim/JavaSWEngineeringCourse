package com.kh.test;

import com.kh.member.dao.MemberDAO;
import com.kh.member.dao.MemberDAOImp;

public class MemberDAOImpTest {

	public static void main(String[] args) {
		
		MemberDAO memberDAO = MemberDAOImp.getMemberDAO();
		
		String tel = "010-1234-5678";
		String birth = "2020-01-14";
		String findID = memberDAO.findID(tel, birth);
		System.out.println("findId="+findID);
		
	}

}
