package com.kh;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.kh.member.svc.MemberSVC;
import com.kh.member.svc.MemberSVCImpl;

@WebServlet(name = "FrontColtroller", urlPatterns = { "*.do" })
public class FrontController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
  public FrontController() {
      super();
   }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("doGet호출");
		doAction(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("doPost호출");
		doAction(request, response);
	}

	private void doAction(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		System.out.println("doAction호출");
		// 한글처리 
		req.setCharacterEncoding("utf-8");
		res.setContentType("text/html;charset=utf-8");		
		
		//URL분석
		String uri 					= req.getRequestURI();
		String contextPath 	= req.getContextPath();
		String command 			= uri.substring(contextPath.length());
		
		String url = req.getRequestURL().toString();
		System.out.println("uri = " + uri);
		System.out.println("contextPath = " + contextPath);
		System.out.println("command = " + command);
		System.out.println("url = " + url);
		
		String viewPage = null;
		MemberSVC memberSVC = MemberSVCImpl.getMemberSVC();
		
		switch(command) {
			//회원가입 화면
			case	"/member/joinForm.do":
				viewPage = "/member/joinForm.jsp";
				break;
			//회원가입처리	
			case	"/member/join.do":
				memberSVC.memberJoin(req,res);
				viewPage = "/member/loginForm.do";
				res.sendRedirect(req.getContextPath()+viewPage);
				return;
			case	"/admin/memberList.do":
	    break;
	    //회원수정화면
			case	"/member/modifyForm.do":
				memberSVC.memberSelect(req, res);
				viewPage = "/member/modifyForm.jsp";
				break;
			//회원수정 처리	
			case	"/member/modify.do":
				memberSVC.memberModify(req, res);
				viewPage = "/";
				res.sendRedirect(req.getContextPath()+viewPage);
				return;
			//회원탈퇴 화면	
			case	"/member/outForm.do":
				viewPage = "/member/outForm.jsp";
				break;
			//회원탈퇴 처리	
			case	"/member/out.do":
				if(memberSVC.memberOut(req, res)) {
					viewPage = "/";
					res.sendRedirect(req.getContextPath()+viewPage);
					return;
				}else{
					viewPage = "/member/outForm.do";
				}
				break;
			case	"/member/select.do":
	    break;
	    //로그인 화면
			case	"/member/loginForm.do":
				viewPage = "/member/loginForm.jsp";
				break;
			//로그인 처리	
			case	"/member/login.do":
				memberSVC.memberLogin(req, res);
				if(req.getSession(false).getAttribute("member") != null) {
					viewPage = "/";
				}else {
					viewPage = "/member/loginForm.do";
				}
				break;
			//로그 아웃	
			case	"/member/logout.do":
				memberSVC.memberLogout(req, res);
				viewPage = "/";
				break;
			//아이디찾기(화면)
			case "/member/findIDForm.do":	
				viewPage = "/member/findIDForm.jsp";
				break;
			//아이디찾기(Restful)
			case "/member/findID.do":
				memberSVC.findID(req, res);
//				viewPage = "/member/findID.jsp";
				break;
	    default:
	    	System.out.println("제공되지않는 서비스 요청!!");
	    	break;
		}
		
		//forward
		if(viewPage !=null) {
			req.getRequestDispatcher(viewPage).forward(req, res);
		}	
	}
}










