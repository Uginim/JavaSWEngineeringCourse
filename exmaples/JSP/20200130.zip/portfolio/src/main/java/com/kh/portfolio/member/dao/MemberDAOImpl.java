package com.kh.portfolio.member.dao;

import java.sql.Date;
import java.util.List;

import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.kh.portfolio.member.vo.MemberVO;
@Repository
public class MemberDAOImpl implements MemberDAO {
	
	private static final Logger logger = LoggerFactory.getLogger(MemberDAOImpl.class);
	
	@Inject
	JdbcTemplate jdbcTemplate; // 참조로 얻어옴 이후 이것으로 CRUD를 함
	
	// 회원등록
	@Override
	public int joinMember(MemberVO memberVO) {
		logger.info("public int insert(MemberVO memberVO) 호출됨!!");
		logger.info(memberVO.toString());
		int cnt = 0;
		
		// sql문 작성
		StringBuffer sql = new StringBuffer();
		sql.append("INSERT INTO member (id, pw, tel, nickname, gender, region, birth, cdate) ");
		sql.append("VALUES (?,?,?,?,?,?,?,systimestamp)");
		
		// sql 실행
		cnt = jdbcTemplate.update(
				sql.toString(),
				memberVO.getId(),
				memberVO.getPw(),
				memberVO.getTel(),
				memberVO.getNickname(),
				memberVO.getGender(),
				memberVO.getRegion(),
				memberVO.getBirth()				
				);
		
		return cnt;
	}

	// 회원 수정
	@Override
	public int modifyMember(MemberVO memberVO) {
		int cnt = 0;
		StringBuffer sql = new StringBuffer("UPDATE Member SET ");
		sql.append("nickname = ?, ");
		sql.append("tel= ?, ");
		sql.append("gender = ?, ");
		sql.append("region = ?, ");
		sql.append("birth = ?, ");
		sql.append("udate = systimestamp ");
		sql.append("WHERE id = ? ");
		
		cnt = jdbcTemplate.update(
				sql.toString(),
				memberVO.getNickname(),
				memberVO.getTel(),
				memberVO.getGender(),
				memberVO.getRegion(),
				memberVO.getBirth(),
				memberVO.getId());
		return cnt;
	}

	@Override
	public List<MemberVO> selectAllMember() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public MemberVO selectMember(String id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int outMember(String id, String pw) {
		// TODO Auto-generated method stub
		return 0;
	}
	
	// 로그인
	@Override
	public MemberVO loginMember(String id, String pw) {
		// TODO Auto-generated method stub
		return null;
	}

	// 아이디 찾기
	@Override
	public String findID(String tel, Date birth) {
		// TODO Auto-generated method stub
		return null;
	}

	// 비밀번호 변경
	@Override
	public int changePW(String id, String pw) {
		// TODO Auto-generated method stub
		return 0;
	}

}
