package com.kh.dto;

public class Book {

	private int bookid; 			//BOOKID	NUMBER(2,0)
	private String bookName;	//BOOKNAME	VARCHAR2(40 BYTE)
	private String publisher; //PUBLISHER	VARCHAR2(40 BYTE)
	private int price;			//PRICE	NUMBER(8,0)
	
	public int getBookid() {
		return bookid;
	}
	public void setBookid(int bookid) {
		this.bookid = bookid;
	}
	public String getBookName() {
		return bookName;
	}
	public void setBookName(String bookName) {
		this.bookName = bookName;
	}
	public String getPublisher() {
		return publisher;
	}
	public void setPublisher(String publisher) {
		this.publisher = publisher;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}	
}
