package com.kh.db;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.kh.dto.Book;

@WebServlet(name = "select", description = "book테이블 조회", urlPatterns = { "/select" })
public class SelectServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
     
	Connection conn = null;
	private final String  URL = "jdbc:oracle:thin:@127.0.0.1:1521:orcl";
	private final String  ID 	= "madang";
	private final String  PW 	= "madang";
	
  public SelectServlet() {
      super();
  }

	public void init(ServletConfig config) throws ServletException {
		System.out.println("멤버변수 초기화 : DB연결");
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection(URL,ID,PW);
			System.out.println("연결성공!");
		}catch(Exception e){
			System.out.println("연결실패!");
		}
	}

	public void destroy() {
		try{
			if(conn != null){
				conn.close();
				System.out.println("연결 종료!!");
			}
		}catch(Exception e){
			System.out.println("연결 종료 실패!!");
		}
		System.out.println("멤버변수 해제 : DB연결 종료!!");
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doAction(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doAction(request, response);
	}

	private void doAction(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
		
		List<Book> list = new ArrayList();
		String sql = "select bookid, bookname, publisher, price from book";
		
		try {
			PreparedStatement pstmt = conn.prepareStatement(sql);
			ResultSet rs = pstmt.executeQuery();
			
			//결과셋에 레코드가 존재하면
			while( rs.next()) {
				Book book = new Book();
				book.setBookid(rs.getInt("bookid"));
				book.setBookName(rs.getString("bookname"));
				book.setPublisher(rs.getString("publisher"));
				book.setPrice(rs.getInt("price"));
				list.add(book);
			}
			System.out.println(list);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		request.setAttribute("booklist", list);
		RequestDispatcher rd = request.getRequestDispatcher("bookList.jsp");
		rd.forward(request, response);
		
	}
}
















