package com.kh.db;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.kh.dto.Book;

@WebServlet(name = "selectOne", urlPatterns = { "/selectOne" })
public class SelectOneServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	Connection conn = null;
	private final String  URL = "jdbc:oracle:thin:@127.0.0.1:1521:orcl";
	private final String  ID 	= "madang";
	private final String  PW 	= "madang";	
	
  public SelectOneServlet() {
      super();
  }

	public void init(ServletConfig config) throws ServletException {
		System.out.println("멤버변수 초기화 : DB연결");
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection(URL,ID,PW);
			System.out.println("연결성공!");
		}catch(Exception e){
			System.out.println("연결실패!");
		}				
	}

	public void destroy() {
		try{
			if(conn != null){
				conn.close();
				System.out.println("연결 종료!!");
			}
		}catch(Exception e){
			System.out.println("연결 종료 실패!!");
		}
		System.out.println("멤버변수 해제 : DB연결 종료!!");
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doAction(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doAction(request, response);
	}

	private void doAction(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//1) 파라미터 정보 읽어오기(bookid)
		String bookid = request.getParameter("bookid");
		
		//2) SQL생성
		String sql ="select * from book where bookid = ?";
		try {
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, Integer.parseInt(bookid));
			//3) SQL실행
			ResultSet rs = pstmt.executeQuery();
			Book book = null;
			if(rs.next()) {
				book = new Book();
				book.setBookid(rs.getInt("bookid"));
				book.setBookName(rs.getString("bookname"));
				book.setPublisher(rs.getString("publisher"));
				book.setPrice(rs.getInt("price"));
			}
			
			request.setAttribute("book", book);
			RequestDispatcher rd = request.getRequestDispatcher("update.jsp");
			rd.forward(request, response);
			
						
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		
		
		//4) SQL결과 처리
		
		//5) 응답페이지
	}

}











