package quiz4;

public class DrawableCircle extends Circle implements Drawable {
	final static String name = "Circle";

	public DrawableCircle(double radius) {
		super(radius);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void draw() {
		// TODO Auto-generated method stub
		System.out.println(name+"를 그립니다.");
	}
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return name;
	}
}
