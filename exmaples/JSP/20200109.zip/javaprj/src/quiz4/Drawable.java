package quiz4;

public interface Drawable {
	void draw();
}
