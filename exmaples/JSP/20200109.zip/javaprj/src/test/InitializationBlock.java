package test;
/**
 * 2019.11.12 Java SW Engineering Course
 * @author Hyeonuk
 *
 */
public class InitializationBlock {
	// 0. 가장 먼저 초기화 됨
	static int num = 10;
	// 1. 인스턴스 생성 전에 실행 됨.
	static {
		num = 20;
		System.out.println("클래스 초기화 블럭 실행");
	}
	// 2. 인스턴스 생성하면 제일 먼저 실행됨
	{
		System.out.println("인스턴스 초기화 블럭 실행");
	}
	{
		System.out.println("인스턴스 초기화 블럭 실행 두 번째");
	}

	// 3. 인스턴스 초기화 블록 실행 후 실행됨
	public InitializationBlock() {
		System.out.println("생성자 실행");
	}

	public static void main(String args[]) {
		System.out.println("InitializationBlock ib = new InitializationBlock(); ");
		InitializationBlock ib = new InitializationBlock();

		System.out.println("InitializationBlock ib2 = new InitializationBlock(); ");
		InitializationBlock ib2 = new InitializationBlock();
	}
}
