package test;

import java.util.ArrayList;
import java.util.Arrays;

public class Commandline {
	public static void main(String[] args) {
//		System.out.println("inputed word ("+args.length+") : "+Arrays.toString(args));
//		float a = Integer.MAX_VALUE;
//		System.out.println(Integer.MAX_VALUE+" "+a);
//		int[] scores = new int[]{10,20,30,40,50,60}; // 6개의 값
////    for(int i=0; i < 7; i++) {
//    for(int i=0; i < 6; i++) {
//        System.out.printf("점수[%d]:%d%n",i, scores[i]);		
//    }
		long startTime = 0l;
		long endTime = 0l;
    ArrayList al1 = new ArrayList(); 
    ArrayList<String> al2 = new ArrayList<String>();
    
    startTime = System.nanoTime();
    for(int i=0;i<1000000;i++) {
    	al2.add("Sachin");
    } 
    for(int i=0;i<1000000;i++) {
    	String s = al2.get(i);
    } 
    endTime = System.nanoTime();
    System.out.printf("걸린 시간:%d ns %n",endTime-startTime);
    al2.clear();
    
    startTime = System.nanoTime();
    for(int i=0;i<1000000;i++) {
    	al1.add("Sachin");
    } 
    for(int i=0;i<1000000;i++) {
    	String s = (String)al1.get(i);
    } 
    endTime = System.nanoTime();
    System.out.printf("걸린 시간:%d ns %n",endTime-startTime);
    
    startTime = System.nanoTime();
    for(int i=0;i<1000000;i++) {
    	al2.add("Sachin");
    } 
    for(int i=0;i<1000000;i++) {
    	String s = al2.get(i);
    } 
    endTime = System.nanoTime();
    System.out.printf("걸린 시간:%d ns %n",endTime-startTime);
    
    al1.clear();
    al2.clear();
    startTime = System.nanoTime();
    for(int i=0;i<1000000;i++) {
      al1.add("Sachin");
    } 
    for(int i=0;i<1000000;i++) {
    	String s = (String)al1.get(i);
    } 
    endTime = System.nanoTime();
		System.out.printf("걸린 시간:%d ns %n",endTime-startTime);
    
    startTime = System.nanoTime();
    for(int i=0;i<1000000;i++) {
      al2.add("Sachin");
    } 
    for(int i=0;i<1000000;i++) {
    	String s = al2.get(i);
    } 
    endTime = System.nanoTime();
		System.out.printf("걸린 시간:%d ns %n",endTime-startTime);

		
		startTime = System.nanoTime();		 
		for(int i=0;i<100000;i++) {
			String s = (String)al1.get(i);
		} 
		endTime = System.nanoTime();
		System.out.printf("걸린 시간:%d ns %n",endTime-startTime);
		
		startTime = System.nanoTime();		 
		for(int i=0;i<100000;i++) {
			String s = al2.get(i);
		} 
		endTime = System.nanoTime();
		System.out.printf("걸린 시간:%d ns %n",endTime-startTime);
	}
}
