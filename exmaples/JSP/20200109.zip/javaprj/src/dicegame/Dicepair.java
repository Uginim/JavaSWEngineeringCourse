package dicegame;

public class Dicepair {
	
	int[] dicepair = new int[2];
	
	
	

}
