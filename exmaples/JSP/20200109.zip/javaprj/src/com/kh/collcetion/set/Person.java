package com.kh.collcetion.set;

public class Person {
	/* 멤버 필드 */
	private String name;
	private int age;
	
	public Person(String name, int age) {
		this.name = name;
		this.age = age;
		
	}
	@Override
	public boolean equals(Object obj) {
		boolean result = false;
		if(obj instanceof Person) {
			Person p = (Person)obj;
			if(this.name.equals(p.name) && this.age == p.age) {
				result = true;
			}
		}
		return result;
	}
	
	@Override
	public int hashCode() {
		return this.name.hashCode() + age;
	}
}
