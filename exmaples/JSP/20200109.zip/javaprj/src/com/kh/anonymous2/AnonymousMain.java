package com.kh.anonymous2;

public class AnonymousMain {
	public static void main(String[] args) {
		Anonymous anony = new Anonymous();
		anony.field.run();
		anony.method1();
		anony.method2(new SportsCar());
	}
}
