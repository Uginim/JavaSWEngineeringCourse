package com.kh.anonymous;

public interface Vehicle {
	void run();
}
