package com.kh.anonymous;

public class Anonymous {
	Vehicle field = new Vehicle() {		
		@Override
		public void run() {
			System.out.println("자전거! 가고싶은데로 간다!");
		}
	};
	void method1() {
		Vehicle local = new Vehicle() {
			
			@Override
			public void run() {
					System.out.println("승용차! 가고싶은데로 간다!");
			}
		};
		local.run();
	}
	void method2(Vehicle a) {
		a.run();
	}
}
