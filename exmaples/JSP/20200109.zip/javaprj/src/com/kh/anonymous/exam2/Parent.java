package com.kh.anonymous.exam2;

public class Parent {
	public void method1() {}
}
