package com.kh;

public class SwtichTester {

	public static void main(String[] args) {
		int i =0;
		switch(i) {
		case 0:
			System.out.println("case0");
			i=1;
			break;
		case 1:
			System.out.println("case1");
		default:
			break;
		}
		System.out.println("i="+i);
	}

}
