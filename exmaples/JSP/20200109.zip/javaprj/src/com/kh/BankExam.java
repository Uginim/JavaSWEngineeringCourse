package com.kh;

import java.util.Scanner;

public class BankExam {
	public static void main(String[] args) {
		// 1) 변수선언
		int balance = 0; //잔액
		boolean flag = true;
		System.out.println("----------------------------------");
		System.out.println("1)예금 | 2)출금 | 3)잔액 | 4)종료 ");
		System.out.println("----------------------------------");
		
		Scanner scanner = new Scanner(System.in);
		while(flag) {
			System.out.print("선택> ");
			String tmp = scanner.nextLine();
			
			switch (tmp) {
			case "1":
				System.out.print("예금액>>");
//				tmp = scanner.nextLine();
//				int money = Integer.parseInt(tmp);
				balance += Integer.parseInt(scanner.nextLine());
				break;
			case "2":		
				System.out.print("출금액>>");
				balance -= Integer.parseInt(scanner.nextLine());
				break;
			case "3":				
				System.out.println("잔액>> "+balance);
				break;
			case "4":
				flag =false;				
				break;
			}
			
		}
		System.out.println("프로그램 종료!");
	}
}
