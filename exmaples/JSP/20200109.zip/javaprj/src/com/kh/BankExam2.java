package com.kh;

import java.util.Scanner;
/**
 * 2019.10.25 Java SW Engineering Course 
 * while do-while로 바꾸기
 * switch문 다중 if문으로 바꾸기
 * 예금/출금 메소드로 뽑아내기
 * @author Hyeonuk
 */ 
public class BankExam2 {
	/**
	 * @param balance
	 * @param money
	 * @return 계산된 잔액 
	 */
	public static int save(int balance, int money) {		
		return balance + money;		
	}
	/**
	 * @param balance
	 * @param money
	 * @return 계산된 잔액
	 */
	public static int withdraw(int balance, int money) {
		return balance - money;
	}
	public static void main(String[] args) {
		// 1) 변수선언
		int balance = 0; //잔액
		boolean flag = true;
		System.out.println("----------------------------------");
		System.out.println("1)예금 | 2)출금 | 3)잔액 | 4)종료 ");
		System.out.println("----------------------------------");
		
		Scanner scanner = new Scanner(System.in);
		do {
			System.out.print("선택> ");
			String tmp = scanner.nextLine();			
			if(tmp.equals("1")){
				System.out.print("예금액>>");
				int money = Integer.parseInt(scanner.nextLine());
				balance = save(balance,money);
			} else if(tmp.equals("2")) {					
				System.out.print("출금액>>");
				int money = Integer.parseInt(scanner.nextLine());
				int result = withdraw(balance, money);
				if(result< 0) {
					System.out.println("잔액이 부족합니다!");
				}else {
					balance = result;
				}
			} else if(tmp.equals("3")) {
				System.out.println("잔액>> "+balance);
			}else if(tmp.equals("4")) {
				flag = false;
			}
		}while(flag); 
			
		System.out.println("프로그램 종료!");
	}
}
