package com.kh.exception.exam1;

public class NullPointExceptionEx {

	public static void main(String[] args) {

		System.setErr(System.out);
		// 1) NullPointException
		// 참조하는 객체가 없은 참조변수를 접근할 때.
		String data = null;
		try {
			System.out.println(data.toString());
		} catch (NullPointerException ne) {
			System.err.println(ne.getMessage());
			ne.printStackTrace();
		}
		System.out.println("====================");
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("====================");
		// 2)
		int x[] = new int[5];
		try {
			System.out.println(x[5]);
		} catch (ArrayIndexOutOfBoundsException aioobe) {
			System.err.println(aioobe.getMessage());
			aioobe.printStackTrace();
		}
		System.out.println("====================");
		String data1 = "100";
		String data2 = "a100";
		int value1 = Integer.parseInt(data1);
		try {
			int value2 = Integer.parseInt(data2);
		} catch (NumberFormatException nfe) {
			System.err.println(nfe.getMessage());
			nfe.printStackTrace();

		}
		System.out.println("====================");
		Animal animal = new Animal();
		try {
			Dog dog = (Dog) animal;
		} catch (ClassCastException cce) {
			System.err.println(cce.getMessage());
			cce.printStackTrace();
			System.out.println("점검중입니다!! 관리자에게 문의하세요!!");
//			return; // finally까지 실행 됨
		} finally {
			System.out.println("예외 발생 유무 없이 실행");
		}
		System.out.println("예외 이후에도 현재 문장 실행");

	}

}

class Animal {
}

class Dog extends Animal {
}

class Cat extends Animal {
}