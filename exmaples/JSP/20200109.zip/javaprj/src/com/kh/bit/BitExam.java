package com.kh.bit;
/**
 * 2019.10.28 Java SW Engineering Course
 * @author Hyeonuk
 *
 */
public class BitExam {

	public static void main(String[] args) {
		int num1 = 10; // 10진수 리터럴	Decimal
		int num2 = 0100; // 8진수 리터럴 1 * 8^2 + 0*8^1 + 0*8^0 = 64 Octal
		int num3 = 0xaf; // 16진수 리터럴 10 * 16^1 + 15 * 16^0 = 175 Binary
		int num4 = 0b101; // 2진수 리터럴 1 * 2^2 + 0 * 2^1 + 1 * 2^0 = 5; Hexadecimal
		
		System.out.println(num1);
		System.out.println(num2);
		System.out.println(num3);
		System.out.println(num4);		
		System.out.println("----------------------------");
		System.out.println("num1 ("+Integer.toBinaryString(num1) +") : "+ toBinaryString(num1));
		System.out.println("num2 ("+Integer.toBinaryString(num2) +") : " + toBinaryString(num2));
		System.out.println("num3 ("+Integer.toBinaryString(num3) +") : " + toBinaryString(num3));
		System.out.println("num4 ("+Integer.toBinaryString(num4) +") : " + BitExam.toBinaryString(num4));
		System.out.println("----------------------------");
		System.out.println("num1 & num2 = "+toBinaryString(num1 & num2));
		System.out.println("num1 | num2 = "+toBinaryString(num1 | num2));
		System.out.println("num1 ^ num2 = "+toBinaryString(num1 ^ num2));
		System.out.println("~num1 = "+toBinaryString(~num1));
		System.out.println("num1 << 2 = "+toBinaryString(num1<<2));
		System.out.println("num1 >> 2 = "+toBinaryString(num1>>2));
		System.out.println("~num1 >> 2 = "+toBinaryString(~num1>>2));
		System.out.println("~num1 >>> 2 = "+toBinaryString(~num1>>>2));

	}
	public static String toBinaryString(int val) {
		String str = Integer.toBinaryString(val);
		while(str.length() < 32) {
			str = "0" + str;
		}
		// 현재 메소드를 종료하고 return 다음의 값을 현제 메소드를 호출한 곳으로 전달한다.
		return str;
	}

}
