package com.kh.operator;
/**
 * 2019.10.25 Java SW Engineering Course
 * 단일부호 연산자( +, - )
 * @author Hyeonuk
 */
public class TypeExam {
	public static boolean isOverflowed(byte num) {
		boolean result = false;
		if(num >= Byte.MAX_VALUE || num <= Byte.MIN_VALUE) {
			System.out.println("오버플로 발생 경고!");
			result = true;
		}
		return result;
	}
	public static void main(String[] args) {
		
		byte num = 125; // -128 ~ 127
		
		// 오버플로우 발생
		for(int i = 0 ; i < 5 ; i++) {			
			System.out.println("num = " + ++num);
		}		
		System.out.println("=-------------=");
		num = -125;
		for(int i = 0 ; i < 5 ; i++) {
			System.out.println("num = " + --num);
		}		
		System.out.println("=-------------=");
		num = 124;
		for(int i = 0 ; i < 5 ; i++) {			
			System.out.println("num = " + ++num);			
			if(isOverflowed(num)) {				
				break;
			} 
		}
	}

}
