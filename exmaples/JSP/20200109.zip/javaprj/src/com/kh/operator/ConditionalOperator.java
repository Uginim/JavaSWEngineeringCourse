package com.kh.operator;
/**
 * 2019.10.25 Java SW Engineering Course 
 * 3항 연산자 (조건식) ? 수식1 : 수식 2 
 * @author Hyeonuk
 * 
 */
public class ConditionalOperator {
	public static void main(String[] args) {
		int score = 95;
//	score = 85;
		score = 75;
		score = 65;
		char grade = (score > 90) ? 'A' : 'B';
		System.out.println("grade="+grade);
		
		grade = (score > 90) ? 'A' : (score > 80)? 'B': 'C';
		System.out.println("grade="+grade);
		
		grade = (score > 90) ? 'A' 
								: (score > 80)? 'B'
								: (score > 70)? 'C'
								: 'D';
		System.out.println("grade="+grade);
	}
}

