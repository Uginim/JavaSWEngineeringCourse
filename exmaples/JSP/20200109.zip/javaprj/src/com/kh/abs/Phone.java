package com.kh.abs;

// 4) abstract method가 클래스 내에 존재하지 않더라도
// 클래스 선언부에 abstract를 사용할 수 있다.
// 이때는 인스턴스 생성불가.
abstract public class Phone {
	
	// 3) abstract class는 abstract method가 
	// 하나라도 존재하면 class선언부에 abstract를 선언해야함.
	abstract public void method1();
	
	public void method2() {}
	public void method3() {}
}
