package com.kh;
/**
 * 2019.10.22 Java SW Engineering Course
 * Draw star pyramid * 
 * @author Hyeonuk
 *
 */

public class Pyramid {
	public static void main(String[] args) {		
		int level = 4;
		
	// pyramid 1
		System.out.println("problem1");
		for(int i=0;i<level;i++) {			
			for(int j=level-1; j>=0 ;j--) {
				if(i<j) {
					System.out.print(" ");
				} else {
					System.out.print("*");
				}
			}
			for(int j=0;j<i;j++) {
				System.out.print("*");
			}
			System.out.println();
		}		
		System.out.println();
		
		
		// pyramid 2
		System.out.println("problem2");
		for(int i=level-1;i>=0;i--) {			
			for(int j=level-1; j>=0 ;j--) {
				if(i<j) {
					System.out.print(" ");
				} else {
					System.out.print("*");
				}
			}
			for(int j=0;j<i;j++) {
				System.out.print("*");
			}
			System.out.println();
		}
		System.out.println();
		
		
		// pyramid 3		
		System.out.println("problem3");
		for(int i=level-1;i>0;i--) {			
			for(int j=level-1; j>=0 ;j--) {
				if(i<j) {
					System.out.print(" ");
				} else {
					System.out.print("*");
				}
			}
			for(int j=0;j<i;j++) {
				System.out.print("*");
			}
			System.out.println();
		}
		for(int i=0;i<level;i++) {			
			for(int j=level-1; j>=0 ;j--) {
				if(i<j) {
					System.out.print(" ");
				} else {
					System.out.print("*");
				}
			}
			for(int j=0;j<i;j++) {
				System.out.print("*");
			}
			System.out.println();
		}
	}
}
