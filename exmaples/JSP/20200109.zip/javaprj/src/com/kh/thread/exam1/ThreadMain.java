package com.kh.thread.exam1;

public class ThreadMain {

	public static void main(String[] args) {
		// 1) Runnable 인터페이스를 구현
		// 1-1) 이름있는 클래스
		Thread thread = new Thread(new Task1());
		thread.start();
		// 1-2) 익명 클래스
		Thread thread2 = new Thread(new Runnable() {			
			@Override
			public void run() {
				for(int i='A'; i<'A'+26; i++) {
					System.out.println(Thread.currentThread().getName() + " : "+(char)i);
					try {
						Thread.sleep(500);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				System.out.println(Thread.currentThread().getName()+" 종료");
				
			}
		});
		thread2.start();
		
		// 1-3) 람다식 : 하나의 추상메소드를 갖고있는 인터페이스는 람다식으로 표현가능하다. 
		Thread thread22 = new Thread( ( ) -> {
			for(int i=200;i<210;i++) {
				System.out.println(Thread.currentThread().getName() + " : "+i);
				try {
					Thread.sleep(100);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
			System.out.println(Thread.currentThread().getName()+" 종료");			
		});
		thread22.start();
		
		// 2) Thread 상속받아서 구현
		// 2-1) 이름 있는 클래스
		Thread_1 thread3 = new Thread_1();
		thread3.start();
		
		// 2-2) 익명 클래스
		Thread thread4 = new Thread() {
			@Override
			public void run() {
				for(int i=200;i<210;i++) {
					System.out.println(Thread.currentThread().getName() + " : "+i);
					try {
						Thread.sleep(100);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
				System.out.println(Thread.currentThread().getName()+" 종료");
			}
		};
		thread4.start();
	
		
		for(int i=0;i<5;i++) {
			System.out.println(Thread.currentThread().getName() + " : "+i);
			try {
				Thread.sleep(500); // 0.5초 지연
			} catch (InterruptedException e) {
//				e.printStackTrace();
				System.out.println("오류발생!");
			}
		}
		
		
		
		// 현재 스레드(task,작업)의 이름 출력
		System.out.println(Thread.currentThread().getName()+" 종료");
		
	}

}
