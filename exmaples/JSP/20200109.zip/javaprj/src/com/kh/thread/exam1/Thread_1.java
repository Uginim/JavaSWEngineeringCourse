package com.kh.thread.exam1;

//2) Thread 상속받아서 구현
public class Thread_1 extends Thread {
	@Override
	public void run() {		
		for(int i=100;i<110;i++) {
			System.out.println(Thread.currentThread().getName() + " : "+i);
			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		System.out.println(Thread.currentThread().getName()+" 종료");
	}
}
