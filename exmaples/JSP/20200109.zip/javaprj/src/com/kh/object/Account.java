package com.kh.object;
/**
 * 2019.11.13 Java SW Engineering Course
 * @author Hyeonuk
 */
public class Account {
	// fields
	private String ownerName;
	private int accountNumber;
	private int balance;
	private final static int LIMIT_BALANCE= 1000_0000;
	private static int accountCount=0;

	{
		accountNumber = accountCount++; 
	}
	
	// constructor 
	public Account(String ownerName) {
		this.ownerName=ownerName;
	}
	
	// methods
	public void deposit(int amount) {
		if(balance+amount>LIMIT_BALANCE) {
			System.out.println("예금 총액 한도 초과");
			return;
		}
		if(amount<=0) {
			System.out.println("음수 금액이나 0원은 예금할 수 없습니다.");
			return;
		}
		System.out.println(amount+ "원이 정상적으로 예금되었습니다.");
		balance+=amount;
	}
	public void withdrow(int amount) {
		if(amount>balance || amount<0) {
			System.out.println("출금할 수 없는 금액입니다.");
			return;
		}
		System.out.println(amount+ "원이 정상적으로 출금되었습니다.");
		balance-=amount;
	}
	public int getBalance() {
		
		return balance;
	}
	public String getOwnerName() {
		return ownerName;
	}
	public void setOwnerName(String ownerName) {
		this.ownerName = ownerName;
	}
	public int getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(int accountNumber) {
		this.accountNumber = accountNumber;
	}
	public void setBalance(int balance) {
		this.balance = balance;
	}
	public static int getAccountCount() {
		return accountCount;
	}
	@Override
	public String toString() {
		return "계좌정보 \n예금주: " + ownerName + "\n계좌번호: " + accountNumber + "\n잔액: " + balance + "";
	}
	
}
