package com.kh.object.exam4;
// 모든 클래스는 java.lang 패키지를 자동 import 한다.
import java.lang.*;
public class Person extends Object {
	// 멤버필드
	private String name; 	// 이름
	private int age;		// 나이
	
	// 기본 생성자(디폴트생성자, default constructor)
	public Person() {	}
	public Person(String name) {
//		this.name = name;
		setName(name);
	}
	public Person(String name, int age) {
//		this.name = name;
//		this.age = age;
//		setName(name);
		this(name);
		setAge(age);
	}
	
	// 멤버 메소드
	public void smile() {
		System.out.println(name + "가 웃다");
	}
	public void sleep() {
		System.out.println(name + "가 잠들다");
	}
	public void cry() {
		System.out.println(name + "가 울다");
	}
	
	// 이름 저장
	public void setName(String name) {
		if(name.length() <= 10) {
			this.name = name;
		}			
	}
	
	// 이름 조회
	public String getName() {
		return this.name;
	}
	
	// 나이 저장
	public void setAge(int age) {
		if( age < 1 || 150 < age) {
			System.out.println("잘못된 값!");
		} else {
			this.age = age;
		}
	}
	
	// 나이 조회
	public int getAge() {
		return this.age;
	}
	
	@Override // 어노테이션: 컴파일러에게 특별한 의미 부여
	public String toString() {
		String str = null;
		str = "이름 : " + this.name;
		str +="\n";
		str += "나이 : " + this.age;
		return str;
	}
}
