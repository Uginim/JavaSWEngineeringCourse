package com.kh.object;

import java.util.Scanner;
/**
 * 2019.11.13 Java SW Engineering Course
 * @author Hyeonuk
 */
public class AccountMain {
	final static int MAX_ACCOUNT_NUMBER = 1000;
	public static void main(String[] args) {
		Scanner scanner = new Scanner (System.in);
		Account[] accounts = new Account[MAX_ACCOUNT_NUMBER ];		
		program: while(true) {
			System.out.println("-------------------------------------------------------------------\r\n" + 
					"1. 계좌개설 | 2.예금 | 3.출금 | 4.잔액 | 5. 개좌 정보 출력 | 6.종료\r\n" + 
					"-------------------------------------------------------------------");
			System.out.print(">>");
			String input = scanner.nextLine();
		
			int accountNum,amount ;
			String numberStr ;
			String amountStr;
			switch(input){
				case "1":
					System.out.println("성명을 입력해 주세요");
					String name = scanner.nextLine();
					Account account = new Account(name);
					accounts[Account.getAccountCount()-1] = account;
					System.out.println("<<개설된 계좌 정보>>");
					System.out.println(account);
					break;
				case "2":
					System.out.println("예금할 계좌 번호를 주세요");
					numberStr = scanner.nextLine();
					accountNum = Integer.parseInt(numberStr);
					if(accountNum>=MAX_ACCOUNT_NUMBER || accounts[accountNum]==null ) {
						System.out.println("존재하지 않는 계좌번호입니다.");
						break;
					}
					System.out.println("예금할 금액을 입력해 주세요");
					amountStr = scanner.nextLine();
					amount = Integer.parseInt(amountStr);
					accounts[accountNum].deposit(amount);
					break;
				case "3":
					System.out.println("출금할 계좌 번호를 주세요");
					numberStr = scanner.nextLine();
					accountNum = Integer.parseInt(numberStr);
					if(accountNum>=MAX_ACCOUNT_NUMBER || accounts[accountNum]==null) {
						System.out.println("존재하지 않는 계좌번호입니다.");
						break;
					}
					System.out.println("출금할 금액을 입력해 주세요");
					amountStr = scanner.nextLine();
					amount = Integer.parseInt(amountStr);
					accounts[accountNum].withdrow(amount);
					break;
				case "4":
					System.out.println("잔액을 확인할 계좌 번호를 주세요");
					numberStr = scanner.nextLine();
					accountNum = Integer.parseInt(numberStr);					
					if(accountNum>=MAX_ACCOUNT_NUMBER || accounts[accountNum]==null) {
						System.out.println("존재하지 않는 계좌번호입니다.");
						break;
					}
					System.out.println("잔액>> "+accounts[accountNum].getBalance()+" 원");
					break;
				case "5":
					System.out.println("계좌정보를 조회할 계좌 번호를 주세요");
					numberStr = scanner.nextLine();
					accountNum = Integer.parseInt(numberStr);
					if(accountNum>=MAX_ACCOUNT_NUMBER || accounts[accountNum]==null) {
						System.out.println("존재하지 않는 계좌번호입니다.");
						break;
					}
					System.out.printf("입력된 계좌번호[%04d]%n%s%n",accountNum,accounts[accountNum]);
					break;
				case "6":
					System.out.println("프로그램을 종료합니다.");
					break program;
				default: 
					System.out.println("1~6 중에서 입력해주세요!");
			}
		}
	}
}
