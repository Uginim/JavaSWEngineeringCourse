package com.kh.object.exam3;

import java.util.Scanner;

public class PersonMain {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		Person p1 = new Person();
		System.out.println(p1);
	}
}
