package com.kh.object.exam1;

public class PersonMain2 {

	public static void main(String[] args) {
		Calculator c1 = new Calculator();
		c1.maker="샤프";
		Person p1 = new Person("홍길동",c1);	
				
		p1.smile();
		p1.doPlus(10, 20);
		
//		p1.doPlus(c1, 10, 20);
//		p1.doPlus(c1, 20, 30);

	}

	
}
