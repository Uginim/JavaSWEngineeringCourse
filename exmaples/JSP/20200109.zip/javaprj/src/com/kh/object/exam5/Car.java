package com.kh.object.exam5;

public class Car {
	private String maker;
	private String cc;
	private String color;

	public Car() {
//		this("현대","1960cc","검정색");
	}
	
	public Car(String maker) {
		setMaker(maker);
	}
	
	public Car(String maker, String cc) {
		this(maker);
		setCc(cc);
	}
	
	public Car(String maker, String cc, String color) {
		this(maker,cc);
		setColor(color);
	}
	
	public void run() {
		System.out.println(color+" "+ maker+"(이)가 달립니다.");
	}
	
	public void stop() {
		System.out.println(color+" "+ maker+"(이)가 멈춥니다.");
	}
	

	public void setMaker(String maker) {
		this.maker = maker;
	}

	public String getMaker() {
		return maker;
	}

	public void setCc(String cc) {
		this.cc = cc;
	}

	public String getCc() {
		return cc;
	}

	public void setColor(String color) {
		for(int i=0;i<color.length();i++) {
			if('0'<=color.charAt(i) && color.charAt(i) <= '9') {
				System.out.println("숫자는 저장할 수 없습니다.");
				return ;
			}
				
		}
		this.color = color;
	}

	public String getColor() {
		return color;
	}
	
	@Override
	public String toString() {
		String str = null;
		str = String.format("제조사 : %s%n색상 : %s%n배기량 : %s",maker,color,cc );		
		return str;
	}
}
