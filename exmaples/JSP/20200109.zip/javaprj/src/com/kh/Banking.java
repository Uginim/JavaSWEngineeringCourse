package com.kh;

import java.util.Scanner;
/**
 * 2019.10.23 Java SW Engineering Course
 * Make Banking service
 * @author Hyeonuk
 *
 */
public class Banking {

	public static void main(String[] args) {
		int menu=-1;
		int balance = 0;int money;
		Scanner scan = new Scanner(System.in);
		System.out.println("------------------------------------\r\n" + 
				"1.예금 | 2.출금 | 3.잔액 | 4.종료\r\n" + 
				"------------------------------------");
		outer: while(true){
			
			System.out.print("선택>");
			String tmp = scan.nextLine();
			menu = Integer.parseInt(tmp);
			switch(menu) {
			case 1:
				System.out.print("예금액>>");
				tmp = scan.nextLine();
				money = Integer.parseInt(tmp);
				balance += money;
				break;
			case 2:
				System.out.print("출금액>>");
				tmp = scan.nextLine();
				money = Integer.parseInt(tmp);
				if(balance<money) {
					System.out.println("잔액부족!");
					break;
				}
				balance -= money;
				break;
			case 3:
				System.out.println("잔액>>"+balance);
				break;
			case 4:
				System.out.println("프로그램종료!");
				break outer;
			default:
				System.out.print("------------------------------------\r\n" + 
						"1.예금 | 2.출금 | 3.잔액 | 4.종료\r\n" + 
						"------------------------------------");
			}
			System.out.println();
			
		}
		

	}

}
