package com.kh.array;

import java.util.Scanner;

public class Array2Exam3 {

	public static void main(String[] args) {		
		String[][] seats = new String[6][10];
		int num = 0;
		for(int i=0 ; i < seats.length ; i++) {
			for(int j=0 ; j < seats[i].length ; j++) {
//				System.out.printf("seats[%d][%d]=%3s%n",i,j,seats[i][j]);
//				seats[i][j] = "" + ++num;
				seats[i][j] = String.valueOf(++num);
			}			
		}
		
		do {
			System.out.printf("%19s%n","<<영화관 좌석 예매 시스템>>");
			System.out.println("==============================");
			for(int i=0 ; i < seats.length ; i++) {
				for(int j=0 ; j < seats[i].length ; j++) {
					System.out.printf("%3s",seats[i][j]);
				}			
				System.out.println();
			}
			System.out.println("==============================");
			System.out.print("영화관 좌석을 선택하세요(1~60) >> ");
			
			Scanner scanner = new Scanner(System.in);
			int mySeat = Integer.parseInt(scanner.nextLine());
			
			
			int myRow = (mySeat % 10 == 0) ? (mySeat/10)-1 : (mySeat/10);
			int myCol = (mySeat % 10 == 0) ? 9 : (mySeat%10)-1;
			
			if(seats[myRow][myCol].equals("X")) {
				System.out.println("이미 예약된 좌석입니다.");
			}else {
				seats[myRow][myCol] = "X";
				System.out.printf("고객님은 %s%s번 좌석을 예매하셨습니다.%n",myRow,(myCol+1));
			}			
		}while(true);
		
	}

}
