package com.kh.array;
/**
 * 2019.10.29 Java SW Engineering Course
 * X 모양으로 별찍기
 * @author Hyeonuk
 */
public class StarPrinter {
	public static void main(String[] args) {
		
		int n=5; // X의 크기
		char [][] starArr = new char[n][n];		
		for(int i=0;i<n;i++) {			 
			for(int j=0;j<n;j++) {
				if(i==j) {
					starArr[i][j] = '*';
				}
				if(n-1 == i+j){
					starArr[i][j] ='*';
				}
					
			}
		}
		// 출력
		for(int i=0;i<n;i++) {
			System.out.println(starArr[i]);
		}
		
	}
}
