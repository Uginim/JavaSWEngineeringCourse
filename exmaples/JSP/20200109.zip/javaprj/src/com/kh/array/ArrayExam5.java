package com.kh.array;
/**
 * 2019.10.29 Java SW Engineering Course
 * 최대값 최소값 구하기
 * @author Hyeonuk
 *
 */
import java.util.Arrays;
public class ArrayExam5 {
 
	/**
	 * 최대값을 구함
	 * @param arr 최대값을 구할 array
	 * @return 구해진 최대값 
	 */
	public static int getMax(int[] arr) {
		int max = Integer.MIN_VALUE;
		for(int i=0;i<arr.length;i++) {
			max = Math.max(max, arr[i]);
		}
		return max;
	}
	/**
	 * 최소값을 구함
	 * @param arr 최소값을 구할 array
	 * @return 구해진 최소값
	 */
	public static int getMin(int[] arr) {
		int min = Integer.MAX_VALUE;
		for(int i=0;i<arr.length;i++) {
			min = Math.min(min, arr[i]);
		}
		return min;
	}
	public static void main(String[] args) {
		int[] array = new int[5];
		int max = Integer.MIN_VALUE;
		int min = Integer.MAX_VALUE;
		// 배열에 정수값 초기화 (랜덤)
		for(int i=0; i<array.length; i++) {
			array[i] = (int) (Math.random()*10)+1;
		}
		// 최대값 구하기
		max = getMax(array);
		// 최소값 구하기
		min = getMin(array);
		
		
		System.out.println(Arrays.toString(array));
		System.out.println("최대값="+max);
		System.out.println("최소값="+min);
		
	}
}
