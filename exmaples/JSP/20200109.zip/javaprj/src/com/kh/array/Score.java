package com.kh.array;

import java.util.Scanner;

public class Score {
	public static void main(String[] args) {
		System.out.println("------------------------------------------------------");
		System.out.println("1.학생수 | 2.점수입력 | 3.점수리스트 | 4.분석 | 5.종료");
		System.out.println("------------------------------------------------------");
		int sum =0 , max=Integer.MIN_VALUE; 
		String input;
		int[] scores=null;
		String temp ;
		Scanner scan = new Scanner(System.in);
		do {
			System.out.print("선택>>");
			input = scan.nextLine();
			switch(input) {
			case"1":
				System.out.print("학생수> ");
				temp = scan.nextLine();
				scores = new int[Integer.parseInt(temp)];
				break;
			case"2":
				if(scores!=null) {
					for(int i=0;i<scores.length;i++) {
						System.out.printf("점수%d> ",i+1);
						temp = scan.nextLine();
						scores[i] = Integer.parseInt(temp);
					}
				}else {
					System.out.println("학생수 부터 입력하세요");
				}
				break;
			case"3":
				if(scores!=null) {
					for(int i=0;i<scores.length;i++) {
						System.out.printf("score[%d] = %d%n",i,scores[i]);
					}
				}else {
					System.out.println("학생수 부터 입력하세요");	
				}
				
				break;
			case"4":
				if(scores!=null) {
					sum = 0;
					max = Integer.MIN_VALUE;
					for(int i=0;i<scores.length;i++) {
							sum += scores[i];						
							max = Math.max(scores[i], max);
					}
					System.out.printf("최고점수 = %d%n",max);
					System.out.printf("평균 = %f%n",(double)sum/scores.length);
				}else {
					System.out.println("학생수 부터 입력하세요");
				}
				break;
			case"5":
				System.out.println("프로그램 종료!");
				break;
			default:
				System.out.println("1~5를 입력하세요");
			}
			
		}while (!input.equals("5"));
		
	}
}
