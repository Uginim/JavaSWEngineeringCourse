package com.kh.array;


/**
 * 애플리케이션 실행 시 실행 매개변수를 전달하여 4칙연산 결과 수행하기!! 
 * ~추가 요구사항~ 
 * 1) 메소드 분리(사칙연산) 
 * 2) 연산자 유효성체크 
 * 3) 피연산자 유효성 체크 
 * @author Hyeonuk
 *
 */
public class Calculator {
	/**
	 * 
	 * @param left 왼쪽 피연산자 
	 * @param right 오른쪽 피연산자
	 * @return 덧셈결과
	 */
	private static int plus(int left, int right) {
		return left + right;
	}
	/**
	 * 
	 * @param left 왼쪽 
	 * @param right 오른쪽
	 * @return 뺄셈 결과
	 */
	private static int minus(int left, int right) {
		return left - right;
	}
	/**
	 * 
	 * @param left 왼쪽 
	 * @param right 오른쪽
	 * @return 곱셈 결과
	 */
	private static int multi(int left, int right) {
		return left * right;
	}
	/**
	 * 
	 * @param left 왼쪽 
	 * @param right 오른쪽
	 * @return 나눗셈 결과
	 */
	private static double divide(int left, int right) {
		return (double) left / right;
	}

	/**
	 * 입력된 문자열을 int형으로 바꿈
	 * @param numStr 바꿀 문자열
	 * @return int숫자
	 */
	private static int parseInt(String numStr) {
		int result = 0;
		for (int i = 0; i < numStr.length(); i++) {
			result *= 10;
			result += numStr.charAt(i) - '0';
		}
		return result;
	}
	/**
	 * 유효성 체크(문자열이 숫자인지 )
	 * @param numStr
	 * @return 숫자이면 true
	 */
	private static boolean checkString(String numStr) {
		for (int i = 0; i < numStr.length(); i++) {
			if (!isDigit(numStr.charAt(i))) {
				return false;
			}
		}
		return true;
	}
	/**
	 * 한 문자가 숫자인지 체크
	 * @param c 체크할 문자
	 * @return 숫자이면 true
	 */
	private static boolean isDigit(char c) {
		if ('0' <= c && c <= '9')
			return true;
		return false;
	}

	public static void main(String[] args) {
		
		if (args.length != 3) {
			System.out.println("매개값 3개가 필요합니다.");
			System.out.println("[숫자] [연산자] [숫자]를 입력하세요!!");
			System.exit(0); // 프로그램 종료
		}
		if (!checkString(args[0]) || !checkString(args[2])) {
			System.out.println("피연산자는 양의 정수만 입력하세요!!");
			System.exit(0); // 프로그램 종료
		}

		int opL = parseInt(args[0]);
		int opR = parseInt(args[2]);

		switch (args[1]) {
		case "/":
			if (opR == 0) {
				System.out.println("0으로 나눌 수 없습니다.");
				System.exit(0);
			}
			double floatingPointResult = 0.0;
			floatingPointResult = divide(opL, opR);			
			System.out.printf("%s %s %s = %f %n", args[0], args[1], args[2], floatingPointResult);
			break;
		case "+":
		case "-":
		case "X":case "x":
			int integerResult = ("+".equals(args[1])) ? plus(opL, opR)
					: ("-".equals(args[1])) ? minus(opL, opR) : multi(opL, opR);
			System.out.printf("%s %s %s = %d %n", args[0], args[1], args[2], integerResult);
			break;
		default:
			System.out.println("연산자는 '+' '-' '/' 'x' 'X'");
			break;
		}

	}
}
