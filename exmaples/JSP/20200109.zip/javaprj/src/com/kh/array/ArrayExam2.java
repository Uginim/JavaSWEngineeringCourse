package com.kh.array;
/**
 * 2019.10.29 Java SW Engineering Course
 * 배열을 사용하여 국영수 합과 평균을 구하시오
 * 아래 3개의 변수 사용
 * int[] score;	// 국영수
 * int sum;			// 합계
 * double ave; 	// 평균
 * @author Hyeonuk
*/
public class ArrayExam2 {
	public static void main(String[] args) {
		int[] score;	// 국영수
		int sum = 0;			// 합계
		double ave = 0.0; 	// 평균
		score = new int[] {90,80,70};
		
		// 합계 구하기
		for(int i=0;i< score.length;i++) {
			sum += score[i];
		}
		
		// 향상된 for문
		sum = 0;
		for(int num : score) {
			sum += num;
		}
		
		// 평균 구하기
		ave = (double)sum/score.length;
		System.out.printf("합계:%d%n평균:%f",sum,ave);
		
	}
}
