package com.kh.inter;
// 3) 인터페이스의 모든 멤버는 public이다.
// 		public을 컴파일러가 자동으로 생성함
public interface RemoteControl {
	// 멤버필드는 상수만 올 수 있다.
	int MAX_VOLUME = 10; // 최대 볼륨
	// static final 예약어가 자동 생성된다.
	int MIN_VOLUME = 0; // 최소 볼륨
	
	
	// 추상 메소드
	abstract void turnOn(); // 키다
	void turnOff(); // 끄다
	void setVolume(int volume);
//	void record(); // 녹화 // 갑자기 추가됨
	default void record() {} // 녹화 
	
	// 디폴트 메소드, 정적메소드 JDK 1.8 이상에서 추가된 기능
	// 디폴트 메소드 : 구현부가 존재함
	default void setMute(boolean mute) {
		if(mute) {
			System.out.println("음소거");
		} else {
			System.out.println("음소거 해제");
		}
	}
	
	// 정적 메소드
	static void changeBattery() {
		System.out.println("건전지 교환");
	}
}
