package com.kh;

import java.util.Scanner;

/**
 * 2019.10.21 Java SW Engineering Course
 * Example
 * 점수를 입력받아 학점 출력하기 (다중 if문 사용)
 * 90학점 이상 A학점, 80이상 B, 70이상 C, 60이상 D, 60미만 과락   
 * @author Hyeonuk
 *
 */
public class Grade {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		String input = scanner.nextLine();
		int score = Integer.parseInt(input);
		
		if(score >=90) {
			System.out.println("A credit");
		} else if(score >=80) {
			System.out.println("B credit");
		} else if(score >=70) {
			System.out.println("C credit");
		} else if(score >=60) {
			System.out.println("D credit");
		} else {
			System.out.println("failed");
		}		
		

	}

}
