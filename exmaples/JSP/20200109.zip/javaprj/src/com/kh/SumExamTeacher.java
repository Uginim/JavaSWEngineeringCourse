package com.kh;

public class SumExamTeacher {
	public static void main(String[] args) {
//		final int TO = 10;
		final int TO; 
		TO = 10;
		//for
		int sum = 0;
		for(int i=1; i<=TO; i++) {
			sum +=i;
		}
		System.out.println("sum=" +sum);
		System.out.println("-----------------");
		
		//while
		int cnt = 0;
		sum = 0;
		while(cnt < TO) {
			cnt++;
			sum += cnt;
		}
		System.out.println("sum=" +sum);
		System.out.println("-----------------");
		
		//do~while
		cnt = 0;
		sum = 0;
		do {
			cnt++;
			sum += cnt;
		} while(cnt < TO);
		System.out.println("sum=" +sum);
		System.out.println("-----------------");
	}
}
