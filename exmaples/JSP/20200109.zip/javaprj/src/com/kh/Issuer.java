package com.kh;

import java.util.Scanner;
/**
 * 2019.10.23 Java SW Engineering Course
 * Distinguish condition of credit card issue 
 * @author Hyeonuk
 *
 */
public class Issuer {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		int annualIncome = 0;
		char creditRating= ' ';
		boolean isExistingCustomer = false;
		String tmp;
		while (true) {
			System.out.println("카드 발급 대상자 판별");
			System.out.println("1) 연봉을 입력하세요(만원) :");
			tmp = scan.nextLine();
			annualIncome = Integer.parseInt(tmp);
			
			System.out.println("2) 신용등급을 입력하세요(A~C) :");
			tmp = scan.nextLine();
			tmp = tmp.toUpperCase();//
			creditRating =  tmp.charAt(0);			
			while(true) {
				System.out.println("3) 기존고객여부(yes, no)");
				tmp = scan.nextLine();
				if(tmp.equalsIgnoreCase("yes")) {
					isExistingCustomer = true;
					break;
				} else if(tmp.equalsIgnoreCase("no")) {
					isExistingCustomer = false;
					break;
				} else {
					System.out.println("yes or no만 입력하세요!");
				}
			}
			if(annualIncome>=5000 && creditRating =='A' && isExistingCustomer) {
				System.out.println("카드발급조건 만족!!");
			} else {
				System.out.println("카드발급조건을 만족하지 않습니다.!!");
			}
			System.out.println("종료시 end입력 계속하려면 아무키나");
			tmp = scan.nextLine();
			if(tmp.equals("end")) {
				System.out.println("종료합니다!");
				break;
			}
		}
	}
}
