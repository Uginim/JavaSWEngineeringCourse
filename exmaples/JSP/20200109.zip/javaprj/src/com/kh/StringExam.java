package com.kh;

public class StringExam {
	public static void main(String[] args) {
		/*
		 * 문자열 비교
		 * 기본타입의 동등비교 ==, !=
		 * 참조타입의 동등비교 
		 * 1) 주소값비교 ==, !=
		 * 2) 문자열비교 String.equals()사용
		 */
		int num1 = 10;
		int num2 = 10;
		
		String name1 = "홍길동";
		String name2 = "홍길동";
		String name3 = new String("홍길동");
		String name4 = new String("홍길동");
		
		System.out.println(name1);
		System.out.println(name2);
		System.out.println(name3);
		
		if(name1 == name2) {
			System.out.println("같다");
		}else {
			System.out.println("다르다");
		}
		
		// 문자열이 저장되어있는 주소값 비교
		if( name2 == name3) {
			System.out.println("같다");
		}else {
			System.out.println("다르다");
		}
		
		// 문자열 자체 비교
		if( name2.equals(name3)) {
			System.out.println("같다");
		} else {
			System.out.println("다르다");
		}
		
	}
}
