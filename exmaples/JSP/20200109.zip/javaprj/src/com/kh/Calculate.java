package com.kh;

public class Calculate {
	public static void main(String[] args) {
		int num1 = 2;
		int num2 = 10;
		
		// 정수와 정수의 산술연산
		int result = num1 / num2 ;
		
//		double result2 = num1 / num2; // 0.0
		double result2 = num1 / (double)num2; // 0.2
		
		double result3 = (double)num1 / num2;
		double result4 = num1 / (double)num2;
		
		int result5 = (int)(num1 / (double)num2);
		
		double result6 = num1 / ((num2*0.1)*10);
		double result7 = ((num1*0.1)*10) / num2;
		
		System.out.println(result);
		System.out.println(result2);
		System.out.println(result3);
		System.out.println(result4);
		System.out.println(result5);
		System.out.println(result6);
		System.out.println(result7);
		
	}
}
