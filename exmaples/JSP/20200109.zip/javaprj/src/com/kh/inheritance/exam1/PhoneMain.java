package com.kh.inheritance.exam1;
/**
 * 2019.11.13 Java SW Engineering Course
 * @author Hyeonuk
 */
public class PhoneMain {
	
	public static void main(String[] args) {
		DmbCellPhone dmbCellPhone = new DmbCellPhone();
		
		DmbCellPhone dmbCellPhone2 = new DmbCellPhone("삼성폰","검정",10);
		
		// CellPhone으로부터 상속받은 멤버필드
		System.out.println("모델 : " + dmbCellPhone2.model);
		System.out.println("색상 : " + dmbCellPhone2.color);
		
		System.out.println("채널 : " + dmbCellPhone2.channel);
		
		dmbCellPhone2.powerOn();
		dmbCellPhone2.bell();;
		dmbCellPhone2.sendVoice("여보세요~");
		dmbCellPhone2.receiveVoid("누구세요??");
		dmbCellPhone2.sendVoice("홍길동이라고 합니다.");
		dmbCellPhone2.hangUp();
		
		// DmbCellPhone 자신의 메소드 사용
		dmbCellPhone2.turnOnDmb();
		dmbCellPhone2.changeChannelDmb(20);
		dmbCellPhone2.turnOffDmb();
		
		System.out.println(dmbCellPhone2);
	}
}
