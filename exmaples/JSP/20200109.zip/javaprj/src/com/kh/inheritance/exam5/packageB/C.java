package com.kh.inheritance.exam5.packageB;

import com.kh.inheritance.exam5.packageA.A;

public class C {
	public void method() {
//		A a = new A();
	}
}
