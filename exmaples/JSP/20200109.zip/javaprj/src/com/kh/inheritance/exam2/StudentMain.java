package com.kh.inheritance.exam2;

public class StudentMain {

	public static void main(String[] args) {
		People p1 = new People("홍길순","222222-2222222");
		System.out.println("이름 :" + p1.name);
		System.out.println("주민번호 :" + p1.ssn);
		
		
		Student s1 = new Student("홍길동","123456-1234567",1001);
		System.out.println("이름 :" + s1.name);
		System.out.println("주민번호 :" + s1.ssn);
		System.out.println("학번 :" + s1.studentNo);
		
	}

}
