
package com.kh;

import java.util.Scanner;
/**
 * 2019.10.21 Java SW Engineering Course
 * Example  
 * 정수를 입력받아서 짝수 홀수 판단
 * @author Hyeonuk
 *
 */
public class EvenOdd {

	public static void main(String[] args) {		
		// 1) 정수형 변수
		int number;
		// 2) 키보드로부터 값을 입력
		System.out.println("Type a number");
//		number = Integer.parseInt(new Scanner(System.in).nextLine());
		Scanner scanner = new Scanner(System.in);
		String strInput = scanner.nextLine();
		number = Integer.parseInt(strInput);
		// 3) 입력받은 값이 홀수/짝수 판단하여 출력하기 
		if(number%2 == 0)
			System.out.println("It is Even");
		else 
			System.out.println("It is Odd");
		
		
	}

}
