package com.kh.control;
/**
 * 2019.10.21 Java SW Engineering Course
 * Conditional Expression Example  
 * @author Hyeonuk
 *
 */
public class IfExam {

	public static void main(String[] args) {
		int score; // Declare integer variable
		
		score = 60; //console> Passed!
//		score = 59; // console> You have failed.
		
		// if statement
//		if(score >= 60) { // conditional expression
//			System.out.println("Passed!");
//		}
//		if(score < 60) {
//			System.out.println("You have failed.");
//		}
		
		// if~else
		if(score >= 60) {
			System.out.println("Passed!");
		} else {
			System.out.println("You have failed.");
		}
		
		// Multiple if statement
		if(score >= 90) {
			System.out.println("A credit");
			
		} else if(score >= 80) {
			System.out.println("B credit");
			
		} else if(score >= 70) {
			System.out.println("C credit");
			
		} else {
			System.out.println("Failed");
			
		}				
		
	}

}
