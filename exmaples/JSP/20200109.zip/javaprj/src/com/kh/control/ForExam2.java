package com.kh.control;
/**
 * 2019.10.21 Java SW Engineering Course
 * Example of "for" loop 
 * print multiplication table
 * @author Hyeonuk
 *
 */
public class ForExam2 {
	public static void main(String[] args) {
		for(int i=2 ; i<=9 ; i++) {
			System.out.println("=============");
			System.out.println(i+"X");
			System.out.println("=============");
			for(int j=1 ; j<=9 ; j++) {
				System.out.println(i + " x " + j +" = " + (i * j));
			}
		}
	}
}
