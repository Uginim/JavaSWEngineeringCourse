package com.kh.control;
/**
 * 2019.10.21 Java SW Engineering Course
 * Example of "for" loop
 * print number from 1 to 10
 * @author Hyeonuk
 *
 */
public class ForExam1 {

	public static void main(String[] args) {
		// print number from 1 to 10
		
		System.out.println("print number from 1 to 10");
		// for loop
		for(int i = 1 ; i<=10 ; i++) {
			System.out.print(i);
			System.out.print(" ");
		}
		System.out.println("print number from 10 to 1");
		for(int i = 10 ; i>=1 ; i--) {
			System.out.print(i);
			System.out.print(" ");
		}
		System.out.println("====================");
		System.out.println("Sum all numbers from 1 to 10");
		System.out.println("====================");
		
		int sum=0;
		for(int i = 1 ; i<=10 ; i++) {
			sum += i;
		}
		System.out.println("sum ="+sum);
		
		System.out.println("====================");
		System.out.println("Sum odd numbers between 1 and 10");
		System.out.println("====================");
		
		sum=0;
		for(int i = 1 ; i<=10 ; i+=2) {
			sum += i;
		}
		System.out.println("sum ="+sum);
	}

}
