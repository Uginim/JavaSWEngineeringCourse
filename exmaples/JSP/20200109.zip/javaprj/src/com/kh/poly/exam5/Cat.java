package com.kh.poly.exam5;

public class Cat extends Animal {

	@Override
	void cry() {
		System.out.println("야옹!");
	}
	
}
