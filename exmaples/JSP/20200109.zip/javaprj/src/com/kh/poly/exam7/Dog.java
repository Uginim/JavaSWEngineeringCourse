package com.kh.poly.exam7;

public class Dog extends Animal {
	@Override
	void cry() {
		System.out.println("멍멍!");
	}
}
