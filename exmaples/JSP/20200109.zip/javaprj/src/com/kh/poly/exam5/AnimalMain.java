package com.kh.poly.exam5;

public class AnimalMain {
	public static void main(String[] args) {
		Animal animal1 = new Dog();
		Animal animal2 = new Cat();
		Animal animal3 = new Pig();
		
		
		System.out.println(animal1);
	}
}
