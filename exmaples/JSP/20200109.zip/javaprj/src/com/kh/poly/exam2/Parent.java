package com.kh.poly.exam2;

public class Parent {
	int field = 10;
	public void method1() {
		System.out.println("Parent-method1()");
	}
	public void method2() {
		System.out.println("Parent-method2()");
	}
}
