package com.kh.poly.exam6;

public class Child extends Parent {
	String ChildField1;
	String ChildField2;
	
	@Override
	void method2() {
		System.out.println("Child-method2()");
	}
	void method3() {
		System.out.println("Child-method2()");
	}
	void method4() {
		System.out.println("Child-method2()");
	}

}
