package com.kh.poly.exam3;

public class BuyerMain {
	
	public static void main(String[] args) {
		
		Tv tv = new Tv();
		Computer computer = new Computer();
		Audio audio = new Audio();
		
		
		//필드의 다형성
		Product p1 = new Tv();
		Product p2 = new Computer();
		Product p3 = new Audio();
		
		Buyer buyer = new Buyer();
		buyer.buy(tv);
	}

}
