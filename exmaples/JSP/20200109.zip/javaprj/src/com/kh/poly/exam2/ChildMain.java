package com.kh.poly.exam2;
/*
 * 자식의 인스턴스를 부모타입에 대입할 경우
 * 메소드는 자식클래스의 인스턴스 메소드가 호출되며
 * 멤버필드는 부모타입의 멤버필드를 접근한다.
 */
public class ChildMain {
	public static void main(String[] args) {
		Child child = new Child();
		child.method1();
		child.method2();
		child.method3();
		
    // 부모 타입에 자식타입의 객체를 대입
		Parent parent = child;
		parent.method1();
		((Child)parent).method3();
		
		// 부모타입의 메소드가 자식객체에서 재정의 되었으면 
		// 중요!! -부모 메소드가 아닌 자식객체의 메소드가 호출된다.
		parent.method2(); // 재정의 된 녀석이 호출됨
		child.method2();
		
		// 참조타입의 멤버필드를 접근함. 
		System.out.println(parent.field);
		System.out.println(child.field);
		
	}
}
