package com.kh.poly.exam4;

public class Audio extends Product{

	public Audio() {
		super(200);
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Audio ";
	}
	
}
