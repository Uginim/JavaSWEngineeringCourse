package com.kh.poly.exam4;

import java.util.Arrays;

public class Buyer {

	final int MAX_ITEM = 100; // 카트 최대용량
	int money = 1000; // 소지한 금액
	int bonusPoint = 0; // 보너스

	Product[] p = new Product[MAX_ITEM];

	// 매개 변수의 다형성
	void buy(Product product) {
		// 구매자가 가진 돈보다 제품의 가격이 비싼 경우
		if(product.price > money) {
			System.out.println("잔액부족");
			return;
		}
		// 카트에 담기
		for (int i = 0; i < this.p.length; i++) {
			if (this.p[i] == null) {
				this.p[i] = product;
				break;
			}
		}
		money -= product.price;
		bonusPoint += product.bonusPoint;
	}
	
	// 구매 목록
	void getItemList() {
		int cnt1 = 0;
		int cnt2 = 0;
		int cnt3 = 0;
		
		for(int i=0; i < this.p.length; i++) {
			if(p[i] instanceof Tv) {
				cnt1++;
			}else if (p[i] instanceof Computer) {
				cnt2++;
			}else if(p[i] instanceof Audio) {
				cnt3++;
			}
			
			if(p[i]!=null) {
				System.out.println(p[i].getClass().getName());
				System.out.println(p[i]);
			}
			
		}
		
		
		System.out.println("총구매 내용");
		System.out.println("TV : " + cnt1);
		System.out.println("Computer : " + cnt2);
		System.out.println("Audio : " + cnt3);
	}

	@Override
	public String toString() {
		return "Buyer [MAX_ITEM=" + MAX_ITEM + ", money=" + money + ", bonusPoint=" + bonusPoint + "]";
	}
	
	
}
