package com.kh.poly.exam1;

public class B extends A{

}
