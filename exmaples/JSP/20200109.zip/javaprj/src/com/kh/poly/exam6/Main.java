package com.kh.poly.exam6;

public class Main {
	public static void main(String[] args) {
		Child c = new Child();
		
		Parent p1 = new Parent();
		Parent p2 = new Child();
		
		p1.method2();
		p2.method2();
		
//		 p2. method3();
		((Child)p2).method3();
		((Child)p2).method4();
		
		Parent p3 = (Parent)c;
		// 자식 타입의 인스턴스를 부모타입의 변수가 참조하고 있을 대
		// 다시 자식타입으로 강제 형변환이 가능하다.!!
//		Child c2 = (Child)p1; // 컴파일 오류는 없지만, 실행시점에서 형변환 Exception 발생
		
		// instanceof : 인스턴스의 실제 타입을 체크 하는데 사용!!
		// 결과가 boolean타입을 반환함
		
		if(p2 instanceof Child) {
			System.out.println("OK");
		}else {
			System.out.println("No");
		}
	}
}
