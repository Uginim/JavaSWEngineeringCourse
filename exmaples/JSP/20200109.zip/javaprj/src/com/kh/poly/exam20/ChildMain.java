package com.kh.poly.exam20;

public class ChildMain {
	public static void main(String[] args) {
		Child child = new Child();
		child.method1();
		child.method2();
		child.method3();
		
		Parent parent = child;
		parent.method1();
		((Child)parent).method3();
		
		parent.method2(); 
		child.method2();
		
		System.out.println(parent.field);
		System.out.println(child.field);
		
	}
}
