package com.kh.poly.exam5;

public class Pig extends Animal {
	@Override
	void cry() {
		System.out.println("꿀꿀!");
	}
}
