package com.kh.db;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.Servlet;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class InsertServlet
 */
@WebServlet(name = "insert", description = "새로운 도서 등록", urlPatterns = { "/insert" })
public class InsertServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	Connection conn = null;
	private String URL = "jdbc:oracle:thin:@127.0.0.1:1521:xe";
	private String ID = "madang";
	private String PW = "madang";

	public InsertServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	public void init(ServletConfig config) throws ServletException {
		super.init();
		System.out.println("멤버변수 초기화:DB연결");
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection(URL, ID, PW);
			System.out.println("	");
		} catch (Exception e) {
			System.out.println("연결실패!");
		}
	}

	/**
	 * @see Servlet#destroy()
	 */
	public void destroy() {
		try {
			if (conn != null) {
				conn.close();
				System.out.println("연결종료");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doAction(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doAction(request, response);
	}

	private void doAction(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf8");
		String bookid = request.getParameter("bookid");
		String bookname = request.getParameter("bookname");
		String publisher = request.getParameter("publisher");
		String price = request.getParameter("price");
		System.out.println(bookid + " " + bookname + " " + publisher + " " + price);

		PreparedStatement pstmt;
		try {
			pstmt = conn
					.prepareStatement("insert into book(bookid,bookname,publisher,price) values(?,?,?,?)");
			pstmt.setInt(1, Integer.parseInt(bookid));
			pstmt.setString(2, bookname);
			pstmt.setString(3, publisher);
			pstmt.setInt(4, Integer.parseInt(price));
			int r = pstmt.executeUpdate();
			System.out.println("r :" + r);			
			request.getRequestDispatcher("select").forward(request, response);
		} catch (SQLException e) {
			response.setContentType("text/html;charset=utf8;");
			e.printStackTrace();
			PrintWriter out = response.getWriter();
			out.append("<script>");
			out.append(" alert('도서등록 오류발생');");
			out.append(" history.go(-1);");
			out.append("</script>");			
		}


	}

}
