package com.kh.db;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.kh.dto.Book;

/**
 * Servlet implementation class SelectOneServlet
 */
@WebServlet(name = "selectone", urlPatterns = { "/selectone" })
public class SelectOneServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	Connection conn = null;
	private String URL = "jdbc:oracle:thin:@127.0.0.1:1521:xe";
	private String ID = "madang";
	private String PW = "madang";

	public SelectOneServlet() {
		super();
	}

	public void init(ServletConfig config) throws ServletException {
		System.out.println("멤버변수 초기화:DB연결");
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection(URL, ID, PW);
			System.out.println("	");
		} catch (Exception e) {
			System.out.println("연결실패!");
		}
	}

	public void destroy() {
		try {
			if (conn != null) {
				conn.close();
				System.out.println("연결종료");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		String bookid = request.getParameter("bookid");
		request.setAttribute("bookid", bookid);
		String sql = "select bookname, publisher, price from book where bookid=?";
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, Integer.parseInt(bookid));
			rs = pstmt.executeQuery();

			// 결과셋에 레코드가 존재하면
			if (rs.next()) {
				Book book = new Book();
				String bookname = rs.getString("bookname");
				String publisher = rs.getString("publisher");
				int price = rs.getInt("price");
				request.setAttribute("bookname", bookname);
				request.setAttribute("publisher", publisher);
				request.setAttribute("price", price);
//				System.out.println(bookid +"," + bookname + "," +publisher+","+price);
			}
//			System.out.println(list);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		RequestDispatcher rd = request.getRequestDispatcher("update.jsp");
		rd.forward(request, response);

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
