package com.kh;

public class AddDAO {
	public int add(int param1, int param2) {
		return param1+param2;
	}	
}
