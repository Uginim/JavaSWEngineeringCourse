package com.kh;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class AddServlet
 */
@WebServlet("/calculator/add.do")
public class AddServletOrigin extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public AddServletOrigin() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		// 1) 파라미터 조회
		String num1 = request.getParameter("num1");
		String num2 = request.getParameter("num2");
		
		// 2) 파라미터값 처리를 위해 적합한 타입으로 형변환
		int op1 = Integer.parseInt(num1);
		int op2 = Integer.parseInt(num2);
		
		// 3) Model의 Biz()로직을 호출해서 작업을 처리
		AddDAO dao = new AddDAO();
		int result = dao.add(op1, op2);;
		
		// 4) 처리결과를 객체에 저장
		request.setAttribute("result", result);
		
		// 5) 결과를 보여주는 view 페이지로 이동(forward)
		RequestDispatcher disp = request.getRequestDispatcher("/addResult.jsp");
		disp.forward(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

	}

}
