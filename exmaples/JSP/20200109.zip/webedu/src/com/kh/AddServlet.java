package com.kh;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class AddServlet
 */
@WebServlet("/calculator/add")
public class AddServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public AddServlet() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		//1) 파라미터 조회
		String num1 = request.getParameter("num1");
		String num2 = request.getParameter("num2");
		String action = request.getParameter("action");
//		System.out.println("action:"+action);
		
		//2) 파라미터값 처리를 위해 적합한 타입으로 형변환
		int op1 = Integer.parseInt(num1);
		int op2 = Integer.parseInt(num2);

		//3) Model의 Biz()로직을 호출해서 작업을 처리
		double result = 0.0;
		switch (action) {
		case "plus":
			AddDAO addDao = new AddDAO();
			result = addDao.add(op1,op2);			
			break;
		case "minus":
			MinusDAO minusDao = new MinusDAO();
			result = minusDao.minus(op1, op2);
			break;
		case "multiply":
			Multiply multiply = new Multiply();
			result = multiply.multiply(op1, op2);
			break;
		case "devide":
			Devide devide = new Devide();
			result = devide.devide(op1, op2);
			break;

		default:
			break;
		}
		
		//4) 처리결과를 	 객체에 저장
		request.setAttribute("result", result);
		
		//5) 결과를 보여주는 view 페이지로 이동(forward)
//		String path = getServletContext().getContextPath();
//		System.out.println("path:"+path);
		RequestDispatcher disp = request.getRequestDispatcher("/addResult.jsp");
		disp.forward(request, response);
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	}

}










