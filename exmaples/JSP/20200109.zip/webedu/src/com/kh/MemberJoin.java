package com.kh;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(description = "회원가입", urlPatterns = { "/Form.do" })
public class MemberJoin extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public MemberJoin() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//1) 사용자 요청정보 수집
		request.setCharacterEncoding("utf-8"); //요청데이터 한글깨짐 방지
		String id = request.getParameter("id");
		String pw = request.getParameter("pw");
		System.out.println("id:" + id);
		System.out.println("pw:" + pw);
		String fruits[] = request.getParameterValues("fruit");
		for(String fruit : fruits) {
			System.out.println("fruit :" + fruit);
			
		}
		String sex = request.getParameter("sex");
		System.out.println("sex:"+sex);
		String job = request.getParameter("job");
		System.out.println("job:"+job);
		String data = request.getParameter("data");
		System.out.println("data:" + data);
		String file = request.getParameter("file");
		System.out.println("file:" + file);
		//2) 사용자 요청정보를 이용하여 연산처리
		
		//3) 처리결과를 응답
		response.setContentType("text/html; charset=utf-8"); 
		PrintWriter out = response.getWriter();
		out.println("아이디 : " + id + "<br>");
		out.println("비밀번호 : " + pw + "<br>");
		out.print("좋아하는 과일 : ");
		for(String fruit : fruits) {
			out.print(fruit + " ");
		}		
		out.println("<br>");
		out.println("성별 : " + sex + "<br>");
		out.println("직업 : " + job + "<br>");
		out.println("텍스트 :" + data + "<br>");
		out.println("파일명 :" + file + "<br>");
	}

}














