package com.kh;

public class Devide {
	public double devide(int num1, int num2) {
		return num1 / (double)num2;
	}
}
