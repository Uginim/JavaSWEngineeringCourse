package com.kh;

public class MinusDAO {
	public int minus(int num1, int num2) {
		return num1 - num2;
	}
}
