package com.kh;

public class AddDAO {
	public int add(int num1, int num2) {
		return num1 + num2;
	}
}
