package com.kh;

public class Multiply {
	public int multiply(int num1, int num2) {
		return num1 * num2;
	}
}
