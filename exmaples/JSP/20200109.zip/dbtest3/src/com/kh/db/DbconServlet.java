package com.kh.db;

import java.io.IOException;
import java.sql.*;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name = "dbcon", description = "데이터베이스 연결 테스트", urlPatterns = { "/dbcon" })
public class DbconServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	Connection conn = null;
	private final String  URL = "jdbc:oracle:thin:@127.0.0.1:1521:xe";
	private final String  ID 	= "madang";
	private final String  PW 	= "madang";
	
  public DbconServlet() {
      super();
  }

	public void init(ServletConfig config) throws ServletException {
		System.out.println("멤버변수 초기화 : DB연결");
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection(URL,ID,PW);
			System.out.println("연결성공!");
		}catch(Exception e){
			System.out.println("연결실패!");
		}
	}

	public void destroy() {
		try{
			if(conn != null){
				conn.close();
				System.out.println("연결 종료!!");
			}
		}catch(Exception e){
			System.out.println("연결 종료 실패!!");
		}
		System.out.println("멤버변수 해제 : DB연결 종료!!");
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doAction(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doAction(request, response);
	}
	private void doAction(HttpServletRequest request, HttpServletResponse response) {
		/* insert */
		String sql = "insert into book values(21,'데이터베이스','한빛',30000)";
	  PreparedStatement pstmt;
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.execute();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}






