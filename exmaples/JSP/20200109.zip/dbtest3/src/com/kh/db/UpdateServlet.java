package com.kh.db;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name = "update", description = "도서정보 수정", urlPatterns = { "/update" })
public class UpdateServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
     
	Connection conn = null;
//	private final String  URL = "jdbc:oracle:thin:@127.0.0.1:1521:orcl";
	private final String  URL = "jdbc:oracle:thin:@127.0.0.1:1521:xe";
	private final String  ID 	= "madang";
	private final String  PW 	= "madang";	
	
  public UpdateServlet() {
      super();
  }

	public void init(ServletConfig config) throws ServletException {
		System.out.println("멤버변수 초기화 : DB연결");
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection(URL,ID,PW);
			System.out.println("연결성공!");
		}catch(Exception e){
			System.out.println("연결실패!");
		}			
	}

	public void destroy() {
		try{
			if(conn != null){
				conn.close();
				System.out.println("연결 종료!!");
			}
		}catch(Exception e){
			System.out.println("연결 종료 실패!!");
		}
		System.out.println("멤버변수 해제 : DB연결 종료!!");
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doAction(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doAction(request, response);
	}

	private void doAction(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// 한글 깨짐 방지 ************************************** 
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		//**************************************************		
		
		//1) 파라미터 정보 읽기 bookid,bookname,publisher,price
		String bookid 		= request.getParameter("bookid");
		String bookname 	= request.getParameter("bookname");
		String publisher 	= request.getParameter("publisher");
		String price 			=	request.getParameter("price");
		
		//2) SQL 생성
		StringBuffer sql = new StringBuffer();
		sql.append("update book ")
		   .append("set bookname = ?, publisher=?, price=? ")
		   .append("where bookid = ? ");
		
		try {
			PreparedStatement pstmt = conn.prepareStatement(sql.toString());
			pstmt.setString(1, bookname);
			pstmt.setString(2, publisher);
			pstmt.setInt(3, Integer.parseInt(price));
			pstmt.setInt(4, Integer.parseInt(bookid));
				
			//3) SQL 실행
			int cnt = pstmt.executeUpdate();
			if(cnt == 1) {
				System.out.println("업데이트 성공!! bookid:" + bookid);
			}
			//4) 페이지이동 -> select 서블릿 
//			RequestDispatcher rd = request.getRequestDispatcher("select");
//			rd.forward(request, response);
			response.sendRedirect("select");

		} catch (SQLException e) {
			request.setAttribute("errmsg", "수정오류!!");
//			RequestDispatcher rd = request.getRequestDispatcher("select");
//			rd.forward(request, response);	
			response.sendRedirect("select");
			e.printStackTrace();
		}
	}
}
















