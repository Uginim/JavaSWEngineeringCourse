package com.kh.member;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.kh.common.Dbcon;
import com.kh.common.PasswordDigest;
import com.kh.dto.MemberDTO;

/**
 * Servlet implementation class MemberJoinServlet
 */
@WebServlet(name = "join", urlPatterns = { "/member/join" }, description = "회원가입")
public class MemberJoinServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public MemberJoinServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doAction(request, response);
	}

	protected void doAction(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// 1) 한글처리
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		// 2) 피라미터 읽어오기 => MemberDTO
		String pwDigest = PasswordDigest.getSha512(request.getParameter("pw"));
		MemberDTO memberDTO = new MemberDTO();
		memberDTO.setId(request.getParameter("id"));
		memberDTO.setPw(pwDigest);
		memberDTO.setTel(request.getParameter("tel"));
		memberDTO.setNickname(request.getParameter("nickname"));
		memberDTO.setGender(request.getParameter("gender"));
		memberDTO.setRegion(request.getParameter("region"));
		// String => Date
		SimpleDateFormat transFormat = new SimpleDateFormat("yyyy-MM-dd");
		try {
			memberDTO.setBirth(transFormat.parse(request.getParameter("birth")));
		} catch (ParseException e1) {
			e1.printStackTrace();
		}

		// 3) db커낵션 가져오기
		Connection conn = Dbcon.getConnection();

		// 4) 회원등록
		StringBuffer sb = new StringBuffer();
		sb.append("INSERT INTO member (id, pw, tel, nickname, gender, region, birth, cdate) ");
		sb.append("VALUES (?,?,?,?,?,?,?,sysdate)");
		try {

			PreparedStatement pstmt = conn.prepareStatement(sb.toString());
			pstmt.setString(1, memberDTO.getId());
			pstmt.setString(2, memberDTO.getPw());
			pstmt.setString(3, memberDTO.getTel());
			pstmt.setString(4, memberDTO.getNickname());
			pstmt.setString(5, memberDTO.getGender());
			pstmt.setString(6, memberDTO.getRegion());
			pstmt.setDate(7, new java.sql.Date(memberDTO.getBirth().getTime()));
			int cnt = pstmt.executeUpdate();
			if (cnt != 0) {
				// 5) db커넥션 반납
				Dbcon.close();
				System.out.println("커넥션 반납");
				// 6) 화면전환(로그인 화면으로 이동)
				response.sendRedirect(request.getContextPath() + "/guest/signin.jsp");
				System.out.println("redirect: " + request.getContextPath() + "/guest/signin.jsp");
			}
		} catch (SQLException e) {
			e.printStackTrace();
			response.sendRedirect(request.getContextPath() + "/guest/signiup.jsp");
		}

	}

	
}
