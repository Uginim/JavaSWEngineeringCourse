package com.kh.member.svc;

import java.util.List;

import com.kh.dto.MemberDTO;

public interface MemberSVC {
//	void execute(HttpServletRequest req, HttpServletResponse res);
	//회원가입
	int memberJoin();
	// 회원 조회(1명)
	MemberDTO memberSelect();
	// 회원목록조회(전체)
	List<MemberDTO> memberList();
	// 회원수정
	int memberModify();
	// 회원탈퇴
	int memberOut();
	// 로그인
	MemberDTO memberLogin();
}
