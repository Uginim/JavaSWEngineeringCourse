package com.kh.member.svc;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.kh.common.PasswordDigest;
import com.kh.dto.MemberDTO;
import com.kh.member.dao.MemberDAO;
import com.kh.member.dao.MemberDAOImpl;

public class MemberSVCImpl implements MemberSVC{
	private HttpServletRequest req;
	private HttpServletResponse res;

	
	
	public MemberSVCImpl(HttpServletRequest req, HttpServletResponse res) {		
		this.req = req;
		this.res = res;
	}



	//회원가입
	@Override
	public int memberJoin()  {
		// 파라미터 정보 읽기
		MemberDTO memberDTO = new MemberDTO();
		memberDTO.setId(req.getParameter("id"));
		String pwDigest = PasswordDigest.getSha512(req.getParameter("pw"));
		memberDTO.setPw(pwDigest);
		memberDTO.setTel(req.getParameter("tel"));
		memberDTO.setNickname(req.getParameter("nickname"));
		memberDTO.setGender(req.getParameter("gender"));
		memberDTO.setRegion(req.getParameter("region"));
		SimpleDateFormat transFormat = new SimpleDateFormat("yyyy-MM-dd");
		try {
			memberDTO.setBirth(transFormat.parse(req.getParameter("birth")));
		} catch (ParseException e1) {
			e1.printStackTrace();
		}
		
		// DAO에 전달
		MemberDAO memberDAO = new MemberDAOImpl();
		int cnt = memberDAO.memberJoin(memberDTO);

		// 6) 화면전환(로그인 화면으로 이동)
		if(cnt==1) {
			try {
				res.sendRedirect(req.getContextPath() + "/guest/signin.jsp");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
//		System.out.println("redirect: " + req .getContextPath() + "/guest/signin.jsp");
		}
		else { 
			try {
				res.sendRedirect(req.getContextPath() + "/guest/signiup.jsp");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return 0;
	}


	// 회원 조회(1명)
	@Override
	public MemberDTO memberSelect() {
		// TODO Auto-generated method stub
		return null;
	}


//회원목록조회(전체)
	@Override
	public List<MemberDTO> memberList() {
		// TODO Auto-generated method stub
		return null;
	}


	// 회원수정

	@Override
	public int memberModify() {
		// TODO Auto-generated method stub
		return 0;
	}


	// 회원탈퇴
	@Override
	public int memberOut() {
		// TODO Auto-generated method stub
		return 0;
	}

	// 로그인
	@Override
	public MemberDTO memberLogin() {
		String id = req.getParameter("id");
		String pw = req.getParameter("pw");
		pw= PasswordDigest.getSha512(pw); // 다이제스트
		MemberDAO memberDAO = new MemberDAOImpl();
		MemberDTO logedInUser = memberDAO.memberLogin(id, pw);		
		
		if( logedInUser != null) {
			HttpSession session = req.getSession();
			session.setAttribute("id", id);
			session.setAttribute("nickname", "관리자");
			
			//메인화면으로 이동
			RequestDispatcher dispatcher = req.getRequestDispatcher("/note");
			try {
				dispatcher .forward(req, res);
			} catch (ServletException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
		} else {
			res.setContentType("text/html;charset=utf-8"); // 아래 response.getWriter()보다 위에 와야함
			PrintWriter out;
			try {
				out = res.getWriter();
				out.println("<script>");
				out.println("alert('아이디 또는 비밀번호가 잘못되었습니다.')");
				out.println("history.go(-1)");
				out.println("</script>");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return null;
	}

	
}
