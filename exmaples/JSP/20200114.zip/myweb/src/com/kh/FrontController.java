package com.kh;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.kh.dto.MemberDTO;
import com.kh.member.svc.MemberSVC;
import com.kh.member.svc.MemberSVCImpl;

/**
 * Servlet implementation class FrontController
 */
@WebServlet("*.do")
public class FrontController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public FrontController() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("doGet호출");
		doAction(request,response);
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("doPost호출");
		doAction(request,response);
	}

	private void doAction(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("doAction호출");
		// 한글처리
		request.setCharacterEncoding("utf-8");		
		response.setContentType("text/html;charset=utf-8");
		
		// URL 분석
		String uri = request.getRequestURI();
		String contextPath = request.getContextPath();
		String command 	= uri.substring(contextPath.length());
//		String url = request.getRequestURL().toString();
		System.out.println("uri = " + uri);
		System.out.println("contextPath = " + contextPath);
		System.out.println("command = " + command);
//		System.out.println("url = " + url);
		String viewPage = null;
		
		
		switch(command) {
		//회원가입	    
		case "/member/joinForm.do":
			viewPage = "/member/joinForm.jsp";
//			viewPage = "/guest/signup.jsp";
			break;
		//회원가입처리	
		case "/member/join.do": 
			MemberSVC memberSVC = new MemberSVCImpl(request,response);
			memberSVC.memberJoin();
			viewPage="/member/loginForm.do";
			break;
		//회원목록	    
		case "/admin/memberList.do": 
			break;
		//회원수정	    
		case "/member/modifyForm.do": 
			break;
		//회원수정처리	
		case "/member/modify.do": 
			break;
		//회원탈퇴	    
		case "/member/outForm.do": 
			break;
		//회원탈퇴처리	
		case "/member/out.do": 
			break;
		//회원조회	    
		case "/member/select.do": 
			break;
		//로그인	    
		case "/member/loginForm.do":			 
			viewPage = "/guest/signin.jsp";
			break;
		//로그인처리	
		case "/member/login.do": 
			MemberDTO logedInUser = new MemberSVCImpl(request,response).memberLogin();
			if(logedInUser!=null) {
				
			}
			viewPage = "/";
			break;
		//로그아웃	    
		case "/member/logout.do": 
			break;
		default:
//			viewPage="";
			System.out.println("제공되지 않는 서비스 요청!!");
			break;
		}
		
		//forward
		if(viewPage !=null) {
			request.getRequestDispatcher(viewPage).forward(request, response);			
		}
		//
	}

}
