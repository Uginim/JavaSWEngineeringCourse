package com.kh.test;

import org.json.JSONObject;

import com.google.gson.Gson;
import com.kh.dto.MemberDTO;

public class JsonTest {

	public static void main(String[] args) {
		String jsonString = "{'name':'hong', 'age':30}";
		String [] hobby= {"music","game","exercise","movie"};
		JSONObject json = new JSONObject(jsonString);
//		System.out.println(json);
		System.out.println(json.get("name"));
		json.put("gender", "남자");
		System.out.println(json);
		json.put("hobby", hobby);
//		System.out.println(json);
		MemberDTO memberDTO = new MemberDTO();
		memberDTO.setId("test");
		memberDTO.setPw("1234");
		memberDTO.setNickname("별칭");
		
		// java object => json object
		Gson gson = new Gson();
		String jsonString2 = gson.toJson(memberDTO);
		json.put("member", jsonString2);		
		System.out.println(jsonString2);
//		System.out.println(json);
		
		json.put("member", memberDTO);
		System.out.println(json);
	}

}
