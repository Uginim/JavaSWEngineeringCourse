package com.kh.member.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLPermission;
import java.util.ArrayList;
import java.util.List;

import com.kh.common.Dbcon;
import com.kh.dto.MemberDTO;

public class MemberDAOImpl implements MemberDAO {

	private static MemberDAOImpl memberDAOImpl = new MemberDAOImpl();
	Connection conn;

	private MemberDAOImpl() {

	}

	public static MemberDAOImpl getMemberDAO() {
		return memberDAOImpl;
	}

	@Override
	public int memberJoin(MemberDTO memberDTO) {
		int cnt = 0;

		// 회원등록
		StringBuffer sb = new StringBuffer();
		sb.append("INSERT INTO member (id, pw, tel, nickname, gender, region, birth, cdate) ");
		sb.append("VALUES (?,?,?,?,?,?,?,sysdate)");
		try {
			// db커낵션 가져오기
			conn = Dbcon.getConnection();

			PreparedStatement pstmt = conn.prepareStatement(sb.toString());
			pstmt.setString(1, memberDTO.getId());
			pstmt.setString(2, memberDTO.getPw());
			pstmt.setString(3, memberDTO.getTel());
			pstmt.setString(4, memberDTO.getNickname());
			pstmt.setString(5, memberDTO.getGender());
			pstmt.setString(6, memberDTO.getRegion());
			pstmt.setDate(7, new java.sql.Date(memberDTO.getBirth().getTime()));
			cnt = pstmt.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			// db커넥션 반납
			Dbcon.close();

		}
		return cnt;
	}

	@Override
	public MemberDTO memberSelect(String id) {
		MemberDTO memberDTO = null;

		StringBuffer sql = new StringBuffer();
		sql.append("SELECT id,pw,tel,nickname,region,gender,birth,cdate,udate ");
		sql.append("FROM Member ");
		sql.append("WHERE id=?");

		try {
			conn = Dbcon.getConnection();
			PreparedStatement pstmt = conn.prepareStatement(sql.toString());
			pstmt.setString(1, id);
			ResultSet rs = pstmt.executeQuery();
			if (rs.next()) {
				memberDTO = new MemberDTO();
				memberDTO.setId(rs.getString("id"));
				memberDTO.setPw(rs.getString("pw"));
				memberDTO.setTel(rs.getString("tel"));
				memberDTO.setNickname(rs.getString("nickname"));
				memberDTO.setRegion(rs.getString("region"));
				memberDTO.setGender(rs.getString("gender"));
				memberDTO.setBirth(rs.getDate("birth"));
				memberDTO.setcDate(rs.getDate("cdate"));
				memberDTO.setuDate(rs.getDate("udate"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			// db커넥션 반납
			Dbcon.close();

		}
		return memberDTO;
	}

	@Override
	public List<MemberDTO> memberList() {
		// sql작성
		StringBuffer sqlBuf = new StringBuffer("Select * from member");
		List<MemberDTO> list = new ArrayList<MemberDTO>();
		// 커넥션 획득
		conn = Dbcon.getConnection();
		try {
			PreparedStatement pstmt = conn.prepareStatement(sqlBuf.toString());
			// sql실행
			ResultSet rs = pstmt.executeQuery();
			MemberDTO memberDTO;
			while (rs.next()) {
				memberDTO = new MemberDTO();
				memberDTO.setId(rs.getString("id"));
				memberDTO.setPw(rs.getString("pw"));
				memberDTO.setTel(rs.getString("tel"));
				memberDTO.setNickname(rs.getString("nickname"));
				memberDTO.setRegion(rs.getString("region"));
				memberDTO.setGender(rs.getString("gender"));
				memberDTO.setBirth(rs.getDate("birth"));
				memberDTO.setcDate(rs.getDate("cdate"));
				memberDTO.setuDate(rs.getDate("udate"));
				list .add(memberDTO);
			}
			System.out.println(list.toString());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			Dbcon.close();
		}
		return list ;
	}

	@Override
	public int memberModify(MemberDTO memberDTO) {
		// TODO Auto-generated method stub
		int cnt = 0;
		StringBuffer sqlBuf = new StringBuffer("UPDATE Member SET ");
		sqlBuf.append("nickname = ?, ");
		sqlBuf.append("tel= ?, ");
		sqlBuf.append("gender = ?, ");
		sqlBuf.append("region = ?, ");
		sqlBuf.append("birth = ?, ");
		sqlBuf.append("udate = sysdate ");
		sqlBuf.append("WHERE id = ? ");
		sqlBuf.append("AND pw = ? ");
		try {
			conn = Dbcon.getConnection();
			PreparedStatement pstmt = conn.prepareStatement(sqlBuf.toString());
			pstmt.setString(1, memberDTO.getNickname());
			pstmt.setString(2, memberDTO.getTel());
			pstmt.setString(3, memberDTO.getGender());
			pstmt.setString(4, memberDTO.getRegion());
			pstmt.setDate(5, new java.sql.Date(memberDTO.getBirth().getTime()));
			pstmt.setString(6, memberDTO.getId());
			pstmt.setString(7, memberDTO.getPw());
			cnt = pstmt.executeUpdate();
			boolean commitResult = conn.createStatement().execute("commit ");
			System.out.println("commit result:"+commitResult);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			Dbcon.close();
		}

		return cnt;
	}

	@Override
	public int memberOut(String id, String pw) {
		StringBuffer sqlBuf = new StringBuffer();
		sqlBuf.append("DELETE FROM Member ");
		sqlBuf.append("WHERE id = ? ");
		sqlBuf.append("AND pw = ? ");
		Connection conn = Dbcon.getConnection();
		int cnt = 0;
		try {
			PreparedStatement pstmt = conn.prepareStatement(sqlBuf.toString());
			pstmt.setString(1, id);
			pstmt.setString(2, pw);
			cnt = pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			Dbcon.close();
		}
		return cnt;
	}

	@Override
	public MemberDTO memberLogin(String id, String pw) {
		MemberDTO result = null;
		String sql = "SELECT id, tel, nickname, gender, region, birth, cdate, udate from Member where id=? AND pw=?";
		Connection conn = Dbcon.getConnection();
		PreparedStatement pstmt;
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, id);
			pstmt.setString(2, pw);
			ResultSet rs = pstmt.executeQuery();

			if (rs.next()) {
				result = new MemberDTO();
				result.setId(rs.getString("id"));
				result.setTel(rs.getString("tel"));
				result.setNickname(rs.getString("nickname"));
				result.setGender(rs.getString("gender"));
				result.setRegion(rs.getString("region"));
				result.setBirth(rs.getDate("birth"));
				result.setcDate(rs.getDate("cdate"));
				result.setuDate(rs.getDate("udate"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			Dbcon.close();
		}
		return result;
	}

	@Override
	public String findID(String tel, String birth) {
		String id = null;
		
		StringBuffer sql = new StringBuffer();
		sql.append("select id from member where tel=? and birth=? ");
		
		conn = Dbcon.getConnection();
		try {
			PreparedStatement pstmt = conn.prepareStatement(sql.toString());
			pstmt.setString(1, tel);
			pstmt.setString(2, birth);
			ResultSet rs = pstmt.executeQuery();
			if(rs.next()) {
//				return id;
				id = rs.getString("id");
			}
			System.out.println("size="+ rs.getFetchSize());
//			while(rs.next()) {
//				rs.getString("id");
//			}
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			Dbcon.close();
		}
		return id;
	}


	// 계정 찾기
	@Override
	public boolean findAccount(String id, String tel, String birth) {
		
		boolean result= false;
		StringBuffer sql = new StringBuffer();
		sql.append("select * from member where id=? and tel=? and birth=? ");
		
		conn = Dbcon.getConnection();
		try {
			PreparedStatement pstmt = conn.prepareStatement(sql.toString());
			pstmt.setString(1, id);
			pstmt.setString(2, tel);
			pstmt.setString(3, birth);
			ResultSet rs = pstmt.executeQuery();
			result = rs.next();
			System.out.println("size="+ rs.getFetchSize());
//			while(rs.next()) {
//				rs.getString("id");
//			}
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			Dbcon.close();
		}
		return result;
	}

	// 비밀번호 변경
	@Override
	public boolean changePW(String id, String pw) {

		boolean result =false;
		StringBuffer sqlBuf = new StringBuffer("UPDATE Member SET ");
		sqlBuf.append("pw = ?, ");
		sqlBuf.append("udate = sysdate ");
		sqlBuf.append("WHERE id = ? ");
		System.out.println("sqlBUf="+sqlBuf);
		System.out.println("id="+id+" pw="+pw);
		try {
			conn = Dbcon.getConnection();
			PreparedStatement pstmt = conn.prepareStatement(sqlBuf.toString());
			pstmt.setString(1, pw);
			pstmt.setString(2, id);
			System.out.println("before executeUpdate()");
			int cnt = pstmt.executeUpdate();			
			System.out.println("cnt="+cnt);
			boolean commitResult = conn.createStatement().execute("commit ");
			System.out.println("commit result:"+commitResult);
			if(cnt!=0) {
				result = true;
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			Dbcon.close();
		}
		return result;
	}

}
