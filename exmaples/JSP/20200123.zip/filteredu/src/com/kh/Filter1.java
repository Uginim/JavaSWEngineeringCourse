package com.kh;

import java.io.IOException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;

//@WebFilter("/admin/*")
public class Filter1 implements Filter {

	public Filter1() {
		System.out.println("Filter1() 생성자");
	}

	public void destroy() {
		System.out.println("destroy()호출됨!");
	}


	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {
		System.out.println("doFilter()호출됨-before");
		chain.doFilter(request, response);
		System.out.println("doFilter()호출됨-after");
		
	}

	public void init(FilterConfig fConfig) throws ServletException {
		System.out.println("init()호출됨");
	}

}
