package com.kh;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;

@WebFilter(
		description = "Servlet1, Servlet2의 필터", 
		servletNames = { "servlet1", "servlet2" })
public class FilterS12 implements Filter {

	public FilterS12() {

	}

	public void destroy() {
	
	}

	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {
		// 전처리("servlet1","servlet2") 실행 전
		HttpServletRequest req = (HttpServletRequest)request;
		String name = req.getParameter("name");
		int age = Integer.parseInt(req.getParameter("age"));
		
		String uri = req.getRequestURI();
		String url = req.getRequestURL().toString();
		String qstr = req.getQueryString();
		
		
		System.out.println("uri="+uri);
		System.out.println("url="+url);
		System.out.println("qstr="+qstr);
		System.out.println("name="+name);
		System.out.println("age="+age);
		
		req.setAttribute("name", "홍길순");
		req.setAttribute("age", 20);
		
		req.setAttribute("name2", "홍길순");
		req.setAttribute("age2", 20);
		
		chain.doFilter(request, response);
		// 후처리("servlet1","servlet2") 실행 후 
	}

	public void init(FilterConfig fConfig) throws ServletException {
		// TODO Auto-generated method stub
	}

}
