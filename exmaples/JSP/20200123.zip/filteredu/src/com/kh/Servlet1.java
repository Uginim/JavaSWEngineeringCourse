package com.kh;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name = "servlet1", urlPatterns = { "/s1.do" })
public class Servlet1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public Servlet1() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doAction(request,response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doAction(request,response);
	}

	private void doAction(HttpServletRequest request, HttpServletResponse response) {
		System.out.println("servlet1 호출됨!");
		System.out.println(request.getAttribute("name"));
		System.out.println(request.getAttribute("age"));
		System.out.println(request.getAttribute("name2"));
		System.out.println(request.getAttribute("age2"));
		System.out.println("-------------------------------");
		System.out.println(request.getAttribute("name"));
		System.out.println(request.getAttribute("age"));
		System.out.println(request.getAttribute("name2"));
		System.out.println(request.getAttribute("age2"));
		
		
	}

}
