package com.kh.filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.kh.dto.MemberDTO;

@WebFilter(description = "관리자페이지 인증필터링", urlPatterns = { "/admin/*" })
public class AdminFilter implements Filter {

	public AdminFilter() {
		System.out.println("AdminFilter()생성됨!");
	}

	public void destroy() {
		System.out.println("destroy()호출됨!");
	}

	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {
		// 전처리
		// url분석후 /admin/* 요청에 대해 인증 요구
		HttpServletRequest req = (HttpServletRequest) request;
		String uri = req.getRequestURI();
		String contextPath = req.getContextPath();
//		String command = uri.substring(contextPath.length(),6);
		
		String command = uri.substring(contextPath.length(),contextPath.length()+7);
		
		System.out.println("Filter uri=" + uri);
		System.out.println("Filter contextPath=" + contextPath);
		System.out.println("Filter command=" + command);
		// 관리자 서비스 경로 요청하면
		if(command.equalsIgnoreCase("/admin/")) {
			HttpSession session = req.getSession(false);//없으면 null
			
			// 세션이 있으면
			if(session != null) {
				MemberDTO memberDTO = (MemberDTO)session.getAttribute("member");
				
				// 세션정보가 관리자인 경우
				if(memberDTO !=null && memberDTO.getId().equalsIgnoreCase("admin@kh.com")) {
					chain.doFilter(request, response);
				}
				// 세션 정보가 관리자가 아닌경우
				else {
					System.out.println("관리자 아닌사용자가 요청함");
					((HttpServletResponse)response).sendRedirect(contextPath+"/");
					return;
				}
			}
			
		}
		
//		chain.doFilter(request, response);
		// 후처리
	}

	public void init(FilterConfig fConfig) throws ServletException {
		System.out.println("init() 호출됨!");
	}

}
