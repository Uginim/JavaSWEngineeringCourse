package com.kh;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.json.JSONObject;

import com.kh.member.svc.MemberSVC;
import com.kh.member.svc.MemberSVCImpl;

/**
 * Servlet implementation class FrontController
 */
@WebServlet("*.do")
public class FrontController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public FrontController() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("doGet호출");
		doAction(request,response);
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("doPost호출");
		doAction(request,response);
	}

	private void doAction(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("doAction호출");
		// 한글처리
		request.setCharacterEncoding("utf-8");		
		response.setContentType("text/html;charset=utf-8");
		
		// URL 분석
		String uri = request.getRequestURI();
		String contextPath = request.getContextPath();
		String command 	= uri.substring(contextPath.length());
//		String url = request.getRequestURL().toString();
		System.out.println("uri = " + uri);
		System.out.println("contextPath = " + contextPath);
		System.out.println("command = " + command);
//		System.out.println("url = " + url);
		String viewPage = null;
		
		MemberSVC memberSVC = MemberSVCImpl.getMemberSVC();
		switch(command) {
		//회원가입	    
		case "/member/joinForm.do":
			viewPage = "/member/joinForm.jsp";
//			viewPage = "/guest/signup.jsp";
			break;
		//회원가입처리	
		case "/member/join.do": 						
			memberSVC.memberJoin(request,response);
			if(request.getAttribute("error")==null)
				viewPage="/member/loginForm.do";
			else 
				viewPage="/member/joinForm.do";
			break;
		//회원목록	    
		case "/admin/memberList.do": 
			memberSVC.memberList(request, response);
			viewPage = "/admin/memberList.jsp";
			break;
		//회원수정	    
		case "/member/modifyForm.do":
			memberSVC.memberSelect(request, response);			
			viewPage = "/member/modifyForm.jsp";
			break;
		//회원수정처리	
		case "/member/modify.do": 
			memberSVC.memberModify(request, response);
			viewPage = "/member/modifyForm.do";
			break;
		//회원탈퇴	    
		case "/member/outForm.do": 
			
			viewPage ="/member/withdrawal.jsp";
			break;
		//회원탈퇴처리	
		case "/member/out.do": 
			memberSVC.memberOut(request, response);
			HttpSession session = request.getSession(false);
			if(session==null) {
				viewPage="/";
			}else {
				viewPage = "/member/outForm.do";
			}
			break;
		//회원조회	    
		case "/member/select.do": 
			break;
		//로그인	    
		case "/member/loginForm.do":			 
			viewPage = "/guest/signin.jsp";
			break;
		//로그인처리	
		case "/member/login.do": 
			
			memberSVC.memberLogin(request,response);
			HttpSession logedInsession = request.getSession();
			if(logedInsession.getAttribute("member")!=null) {
				viewPage = "/note";
			}else {
				request.setAttribute("error", "로그인 정보가 없습니다.");
				viewPage = "/guest/signin.jsp";
			}
			/*
			if(logedInUser!=null) {
				viewPage = "/";				
			}
			*/
			
			break;
		//로그아웃	    
		case "/member/logout.do": 
			memberSVC.memberlogout(request,response);
			/*
			HttpSession session = request.getSession(false);
			if(session != null) {
				session.invalidate(); // 세션 제거
			} else {
				// 접속 상태 아님
				System.out.println("접속상태 아님");
			}
			*/
			viewPage="/";
			break;
		// 아이디찾기(화면)
		case "/member/findIDForm.do":
			viewPage = "/member/findIDForm.jsp";
			break;
			// 아이디찾기(Restful)
		case "/member/findID.do":
			memberSVC.findID(request, response);
//			viewPage ="/member/findID.jsp";
			
			break;
		// 비밀번호찾기
		case "/member/findPWForm.do":
			viewPage = "/member/findPWForm.jsp";
			break;
		case "/member/findAccount.do":
			memberSVC = MemberSVCImpl.getMemberSVC();
			memberSVC.findAccount(request, response);			
			break;
		case "/member/changePW.do":
			memberSVC = MemberSVCImpl.getMemberSVC();
			memberSVC.changePW(request, response);
			String resMsg = (String)request.getAttribute("resMsg");
			System.out.println("resMsg:"+resMsg);
			JSONObject resMsgJson = new JSONObject(resMsg);
			response.getWriter().append(resMsgJson.toString());
			break;
		
		default:
//			viewPage="";
			System.out.println("제공되지 않는 서비스 요청!!");
			break;
		}
		
		//forward
		if(viewPage !=null) {
			System.out.println("viewPage="+viewPage);
			request.getRequestDispatcher(viewPage).forward(request, response);			
		}
		//
	}

}
