package com.kh.common;

import java.sql.Connection;
import java.sql.SQLClientInfoException;
import java.sql.SQLException;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

public class Dbcon {
	private static Connection conn ;
	private static Context initCtx ;
	private static Context envCtx ;
	private static DataSource ds;
	public static Connection getConnection() {
		try {
			initCtx = new InitialContext();
			envCtx = (Context)initCtx.lookup("java:comp/env");
			ds = (DataSource)envCtx.lookup("jdbc/java");
			conn = ds.getConnection();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return conn;
	}
	
	// db 커넥션 반납
	public static void close() {
		try {
			conn.close();
		} catch(SQLException e) {
			e.printStackTrace();
		}
	}
}
