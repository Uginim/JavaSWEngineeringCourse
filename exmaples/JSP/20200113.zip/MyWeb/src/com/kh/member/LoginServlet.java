package com.kh.member;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.kh.common.Dbcon;
import com.kh.common.PasswordDigest;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet(name = "login", urlPatterns = { "/login" })
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String id = request.getParameter("id");
		String pw = request.getParameter("pw");
		pw= PasswordDigest.getSha512(pw); // ��������Ʈ
		String sql = "SELECT id, pw from Member where id=? AND pw=?";
		Connection conn = Dbcon.getConnection();
		PreparedStatement pstmt;
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, id);
			pstmt.setString(2, pw);
			ResultSet rs = pstmt.executeQuery();
			
//		id.contentEquals(ID) &&
//		final String ID = "admin@test.com";
//		final String PW = "test";
			
			System.out.println("id :" +id);
			System.out.println("pw :" +pw);
			if( rs.next()) {
				HttpSession session = request.getSession();
				session.setAttribute("id", id);
				session.setAttribute("nickname", "������");
				
				//����ȭ������ �̵�
				RequestDispatcher dispatcher = request.getRequestDispatcher("/note");
				dispatcher .forward(request, response);
				
				
			} else {
				response.setContentType("text/html;charset=utf-8"); // �Ʒ� response.getWriter()���� ���� �;���
				PrintWriter out = response.getWriter();
				out.println("<script>");
				out.println("alert('���̵� �Ǵ� ��й�ȣ�� �߸��Ǿ����ϴ�.')");
				out.println("history.go(-1)");
				out.println("</script>");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
