package com.kh.portfolio.board;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.List;

import javax.inject.Inject;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.kh.portfolio.board.dao.BoardDAO;
import com.kh.portfolio.board.vo.BoardFileVO;
import com.kh.portfolio.board.vo.BoardVO;
@ExtendWith(SpringExtension.class)
@ContextConfiguration(locations = "file:src/main/webapp/WEB-INF/spring/root-context.xml")
public class BoardDAOImplXMLTest {
	Logger logger = LoggerFactory.getLogger(BoardDAOImplXMLTest.class);
	
	@Inject
	BoardDAO boardDAO;
	
	@Test
	public void getBoardList() {
		List<BoardVO> list = boardDAO.list();
		logger.info(""+list.size());
		assertNotNull(list);
		logger.info(list.toString());
	}
	
	@Test
	public void getFile() {
		
		List<BoardFileVO> list = boardDAO.fileViews("29");
		logger.info(list.toString());
	}
}
