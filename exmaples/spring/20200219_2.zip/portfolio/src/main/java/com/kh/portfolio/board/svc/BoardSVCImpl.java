package com.kh.portfolio.board.svc;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;
import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.kh.portfolio.board.dao.BoardDAO;
import com.kh.portfolio.board.vo.BoardCategoryVO;
import com.kh.portfolio.board.vo.BoardFileVO;
import com.kh.portfolio.board.vo.BoardVO;


@Service
public class BoardSVCImpl implements BoardSVC {
	public static final Logger logger = LoggerFactory.getLogger(BoardSVCImpl.class);
//	@Inject
//	@Qualifier("memberDAOImplXML")
//	MemberDAO memberDAO;
	
	@Inject
	BoardDAO boardDAO;
	
	// 카데고리 읽어오기
	@Override
	public List<BoardCategoryVO> getCategory() {
		return boardDAO.getCategory();
	}
	
	// 게시글 작성
	@Transactional
	@Override
	public int write(BoardVO boardVO) {
		long bnum = 0;
		// 1) 게시글 작성
		int cnt = boardDAO.write(boardVO);
		
		// 2) bnum 가져오기
		bnum = boardVO.getBnum(); // mapper에 selectKey태그로 '새로 생성된 key'값을 가져옴 
		
		// 3) 첨부파일 있는 경우
		if(boardVO.getFiles() != null && boardVO.getFiles().size() > 0) {			
			fileWrite(boardVO.getFiles(),bnum);
		}
		return cnt;
	}
	
	private void fileWrite(List<MultipartFile> files, long bnum) {
		for(MultipartFile multipartfile : files) {
			
			try {
				logger.info("file name length" +multipartfile.getOriginalFilename().length());
//				if(multipartfile.getOriginalFilename().length()==0)
				if(multipartfile.getSize()==0)
					continue;
				logger.info("파일 첨부 : "+multipartfile.getOriginalFilename());
				
				BoardFileVO boardFileVO =  new BoardFileVO();
				// 게시글 번호
				boardFileVO.setBnum(bnum);
				// 첨부파일 명
				boardFileVO.setFname(multipartfile.getOriginalFilename());
				// 첨부파일 크기
				boardFileVO.setFsize(multipartfile.getSize());
				// 첨부파일 타입
				boardFileVO.setFtype(multipartfile.getContentType());
				// 첨부파일 데이터
				boardFileVO.setFdata(multipartfile.getBytes());
				logger.info("input file:"+multipartfile.toString());
				// 첨부파일 저장
				boardDAO.fileWrite(boardFileVO);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
	// 게시글 수정
	@Override
	public int modify(BoardVO boardVO) {
		// TODO Auto-generated method stub
		return 0;
	}

	// 게시글 삭제
	@Transactional // 과정 중 하나가 잘못되면 rollback
	@Override
	public int delete(String bnum) {
		int cnt = 0;
		boardDAO.filesDelete(bnum);
		cnt = boardDAO.delete(bnum);
		return cnt;
	}

	// 첨부파일 삭제
	@Override
	public int fileDelete(String fid) {
		return 0;
	}

	// 게시글 첨부파일 전체 삭제
	@Override
	public int fileDeleteAll(String bnum) {
		return 0;
	}

	// 게시글 보기
	@Transactional
	@Override
	public Map<String,Object> view(String bnum) {
		// 1) 게시글 가죠오기
		BoardVO boardVO = boardDAO.view(bnum);
		// 2) 첨부파일 가져오기
		List<BoardFileVO> files = boardDAO.fileViews(bnum);
		// 3) 조회수 +1 증가
		boardDAO.updateHit(bnum);
		
		Map<String,Object> map = new HashMap<>();
		map.put("board",boardVO);
		if(files != null && files.size() > 0) {
			map.put("files",files);
		}
		return map;
	}

	// 게시글 목록
	// 1) 전체
//	@Override
	public List<BoardFileVO> fileViews(String bnum) {
		// TODO Auto-generated method stub
		return null;
	}

	// 2) 검색어 없는 게시글 페이징
	@Override
	public List<BoardVO> list() {
		// TODO Auto-generated method stub
		return boardDAO.list();
	}

	// 3) 검색어 잇는 게시글 검색(전체,작성자id, 별칭, 제목, 내용)
	@Override
	public List<BoardVO> list(int startRec, int endRec) { 
		return null;
	}

	@Override
	public List<BoardVO> list(int startRec, int endRec, String keyword, String SearchType) {
		// TODO Auto-generated method stub
		return null;
	}

	// 게시글답글 작성
	@Override
	public int reply(BoardVO boardVO) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public BoardFileVO fileView(String fid) { 
		return boardDAO.fileView(fid);
	}

}
