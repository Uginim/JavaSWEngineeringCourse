package com.kh.portfolio.board.vo;

import javax.persistence.Entity;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import lombok.Data;

@Entity
@Data
public class BoardCategoryVO {	
	@Pattern(regexp="^[^0]+$", message="선택하세요!")
	@NotNull(message="분류를 선택하세요")
	private long cid;	// 분류코드
	private String cname; // 분류명
}
