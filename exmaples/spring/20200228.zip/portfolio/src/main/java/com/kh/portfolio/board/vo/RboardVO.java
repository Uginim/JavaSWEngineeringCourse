package com.kh.portfolio.board.vo;

import java.sql.Timestamp;

public class RboardVO {
   private long rnum;                              //RNUM   NUMBER(10,0)   No      1   댓글번호
   private long bnum;                              //BNUM   NUMBER(10,0)   No      2   게시글번호
   private String rid;                              //RID   VARCHAR2(40 BYTE)   No      3   작성자ID(e-mail)
   private String rnickname;                     //RNICKNAME   VARCHAR2(30 BYTE)   No      4   별칭
   private Timestamp rcdate;                     //RCDATE   TIMESTAMP(6)   No   systimestamp    5   작성일
   private Timestamp rudate;                     //RUDATE   TIMESTAMP(6)   Yes   systimestamp   6   수정일
   private String rcontent;                     //RCONTENT   CLOB   No      7   본문내용
   private int rgroup;                              //RGROUP   NUMBER(10,0)   No   0    8   답글그룹
   private int rstep;                               //RSTEP   NUMBER(5,0)   No   0    9   답변글의 단계
   private int rindent;                            //RINDENT   NUMBER(5,0)   No   0    10   답변글의 들여쓰기
}