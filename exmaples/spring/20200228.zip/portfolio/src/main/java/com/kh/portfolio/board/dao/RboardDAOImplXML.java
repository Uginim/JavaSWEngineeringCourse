package com.kh.portfolio.board.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.mybatis.spring.SqlSessionTemplate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kh.portfolio.board.vo.RboardVO;
import com.kh.portfolio.board.vo.VoteVO;

public class RboardDAOImplXML implements RboardDAO {

	final private static Logger logger = LoggerFactory.getLogger(RboardDAOImplXML.class);
	
	@Inject 
	SqlSessionTemplate sqlSession;
	
	@Override
	public int write(RboardVO rboardVO) {
		return sqlSession.insert("mappers.RboardDAO-mapper.write",rboardVO);
	}

	@Override
	public List<RboardVO> list(long bnum, long startRec, long endRec) {
		return sqlSession.selectList("mappers.RboardDAO-mapper.list",bnum);
	}

	@Override
	public int modify(RboardVO rboardVO) {
		return sqlSession.update("mappers.RboardDAO-mapper.modify",rboardVO);
	}

	@Override
	public int delete(String rnum) {
		return sqlSession.delete("mappers.RboardDAO-mapper.delete",rnum);
	}

	@Override
	public int reply(RboardVO rboardVO) {

		return sqlSession.insert("mappers.RboardDAO-mapper.reply",rboardVO);
	}

	// 이전 댓글 step 업데이트
	private int update(long rgroup, int rstep) {		
		Map<String,Object> map = new HashMap<String,Object>();
		map.put("rgroup",rgroup);
		map.put("rstep", rstep);
		return sqlSession.update("mappers.RboardDAO-mapper.updatedStep",map);
	}
	

	@Override
	public int replyTotalRec(String bnum) {
		// TODO Auto-generated method stub
		return 0;
	}
	

	@Override
	public int checkVote(VoteVO voteVO) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int insertVote(VoteVO voteVO) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int updateVote(VoteVO voteVO) {
		// TODO Auto-generated method stub
		return 0;
	}

}
