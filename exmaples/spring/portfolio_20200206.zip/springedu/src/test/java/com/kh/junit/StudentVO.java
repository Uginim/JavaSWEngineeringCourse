package com.kh.junit;

import lombok.Data;

@Data
public class StudentVO {
	private String id;
	private String name;
	private int kor;
	private int eng;
	private int mat;
}
