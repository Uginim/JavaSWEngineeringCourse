package com.kh.portfolio.controller;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

class Abc{
	String a;
	String b;

	public String getA() {
		return a;
	}
	public void setA(String a) {
		this.a = a;
	}
	public String getB() {
		return b;
	}
	public void setB(String b) {
		this.b = b;
	}
	
}
@Controller
public class TestController {
	private static final Logger logger =
			LoggerFactory.getLogger("TestController.class");
	

	@RequestMapping("/temp")
	String tmp(HttpServletRequest request) {
		String a = request.getParameter("a");
		String b = request.getParameter("b");
		
		System.out.println("a : " + a);
		System.out.println("b : " + b);

		return "none";
	}
	
	@GetMapping("/temp2")
	String temp2(@RequestParam Map<String, String> param)
	{
		String a = param.get("a");
		String b = param.get("b");

		System.out.println("a : " + a);
		System.out.println("b : " + b);

		return "none";
	}	
	
	@GetMapping( "/temp3")
	String temp(@RequestParam("a") String a, @RequestParam("b") int b)
	{
		System.out.println("a : " + a);
		// Integer.parseInt() 과정이 필요없다!
		System.out.println("b : " + b);

		return "none";
	}	
	
	@GetMapping("/temp4")
	String temp(@RequestParam("a") String a, @RequestParam("b") int b, Model model)
	{
		System.out.println("모델 스캔 - 시작");
		Map<String, Object> map = model.asMap();
		for (String key : map.keySet())
		{
			System.out.println(key + " : " + map.get(key).toString());
		}
		System.out.println("모델 스캔 - 종료");
		return "none";
	}	
	
	@GetMapping("/temp5")
	String temp(Abc abc, Model model)
	{
		System.out.println("모델 스캔 - 시작"+abc.toString());
		Map<String, Object> map = model.asMap();
		for (String key : map.keySet())
		{
			System.out.println(key + " : " + map.get(key).toString());
		}
		System.out.println("모델 스캔 - 종료");
		return "none";
	}	
}
