package com.kh.portfolio.member.dao;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.List;

import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.kh.portfolio.member.vo.MemberVO;
@Repository
public class MemberDAOImplJDBC implements MemberDAO {
	
	private static final Logger logger = LoggerFactory.getLogger(MemberDAOImplJDBC.class);
	RowMapper<MemberVO> memberVORowMapper = new RowMapper<MemberVO>() {

		@Override
		public MemberVO mapRow(ResultSet rs, int rowNum) throws SQLException {
			MemberVO memberVO = new MemberVO();
			memberVO.setId(rs.getString("id"));
			memberVO.setBirth(rs.getDate("birth"));
			memberVO.setTel(rs.getString("tel"));
			memberVO.setNickname(rs.getString("nickname"));
			memberVO.setGender(rs.getString("gender"));
			memberVO.setRegion(rs.getString("region"));
			return memberVO;
		}
		
	};
	
	@Inject
	JdbcTemplate jdbcTemplate; // 참조로 얻어옴 이후 이것으로 CRUD를 함
	
	// 회원등록
	@Override
	public int joinMember(MemberVO memberVO) {
		logger.info("public int insert(MemberVO memberVO) 호출됨!!");
		logger.info(memberVO.toString());
		int cnt = 0;
		
		// sql문 작성
		StringBuffer sql = new StringBuffer();
		sql.append("INSERT INTO member (id, pw, tel, nickname, gender, region, birth, cdate) ");
		sql.append("VALUES (?,?,?,?,?,?,?,systimestamp)");
		
		// sql 실행
		cnt = jdbcTemplate.update(
				sql.toString(),
				memberVO.getId(),
				memberVO.getPw(),
				memberVO.getTel(),
				memberVO.getNickname(),
				memberVO.getGender(),
				memberVO.getRegion(),
				memberVO.getBirth()				
				);
		
		return cnt;
	}

	// 회원 수정
	@Override
	public int modifyMember(MemberVO memberVO) {
		int cnt = 0;
		StringBuffer sql = new StringBuffer("UPDATE Member SET ");
		sql.append("nickname = ?, ");
		sql.append("tel= ?, ");
		sql.append("gender = ?, ");
		sql.append("region = ?, ");
		sql.append("birth = ?, ");
		sql.append("udate = systimestamp ");
		sql.append("WHERE id = ? ");
		
		cnt = jdbcTemplate.update(
				sql.toString(),
				memberVO.getNickname(),
				memberVO.getTel(),
				memberVO.getGender(),
				memberVO.getRegion(),
				memberVO.getBirth(),
				memberVO.getId());
		return cnt;
	}

	@Override
	public List<MemberVO> selectAllMember() {
		List<MemberVO> list = null;
		StringBuffer sql = new StringBuffer("SELECT * ");
		sql.append("FROM ");
		sql.append("Member ");
		
		list = jdbcTemplate.query(sql.toString(),memberVORowMapper);
		return list;
	}

	@Override
	public MemberVO selectMember(String id) {
		MemberVO memberVO = null;
		StringBuffer sql = new StringBuffer("SELECT * ");
		sql.append("FROM Member ");
		sql.append("WHERE id = ?");
		memberVO = (MemberVO) jdbcTemplate.queryForObject(sql.toString(),new Object[] {id}, memberVORowMapper);
		return memberVO;
	}

	@Override
	public int outMember(String id, String pw) {
		int cnt = 0;
		StringBuffer sql = new StringBuffer("DELETE FROM Member ");
		sql.append("WHERE ");
		sql.append("id = ? ");
		sql.append("AND ");
		sql.append("pw = ? ");
		
		cnt = jdbcTemplate.update(
				sql.toString(),
				id,
				pw);
		return cnt;
	}
	
	// 로그인
	@Override
	public MemberVO loginMember(String id, String pw) {
		MemberVO memberVO = null;
		StringBuffer sql = new StringBuffer("SELECT * ");
		sql.append("FROM Member ");
		sql.append("WHERE id = ? ");
		sql.append("AND pw = ? ");
		memberVO = (MemberVO) jdbcTemplate.queryForObject(sql.toString(),new Object[] {id, pw}, memberVORowMapper);
		return memberVO;
	}

	// 아이디 찾기
	@Override
	public String findID(String tel, Date birth) {
		String id;
		StringBuffer sql = new StringBuffer("SELECT id ");
		sql.append("FROM Member ");
		sql.append("WHERE tel = ? ");
		sql.append("AND birth = ? ");
		id = jdbcTemplate.queryForObject(sql.toString(),new Object[] {tel, birth},new int[] {Types.VARCHAR,Types.DATE},String.class );		
		return id;
	}
	
	// 비밀번호 변경 대상 찾기
	@Override
	public int findPW(MemberVO memberVO) {
		logger.info("MemberDAOImpl.findPW(Member memverVO) 호출됨!");
		int cnt;
		boolean result= false;
		StringBuffer sql = new StringBuffer();
		sql.append("select count(id) from member where id=? and tel=? and birth=? ");
		cnt = jdbcTemplate.queryForObject(
				sql.toString(), 
				Integer.class, 
				memberVO.getId(),
				memberVO.getTel(),
				memberVO.getBirth());
				
		return cnt;
	}

	// 비밀번호 변경
	@Override
	public int changePW(String id, String pw) {
		int cnt;
		StringBuffer sql = new StringBuffer("UPDATE Member ");
		sql.append("SET ");
		sql.append("pw = ? ");
		sql.append("WHERE id = ? ");
		cnt = jdbcTemplate.update(sql.toString(),pw,id);
		return cnt;
	}
	

}
