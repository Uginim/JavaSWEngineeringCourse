package com.kh.portfolio;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.sql.Connection;
import java.sql.SQLException;

import javax.inject.Inject;
import javax.sql.DataSource;

import org.apache.ibatis.session.SqlSessionFactory;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mybatis.spring.SqlSessionTemplate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(locations="file:src/main/webapp/WEB-INF/spring/root-context.xml")
public class DBConnection {
	private final static Logger logger = LoggerFactory.getLogger(DBConnection.class);
	@Inject
	DataSource dataSource;
	
	@Inject
	SqlSessionTemplate sqlSessionTemplate;
	
	@Inject
	SqlSessionFactory sqlSessionFactory;
	
	@Test
	@DisplayName("DB연결 테스트")
	public void testConnection() {
		assertNotNull(dataSource);
		logger.info("dataSource: "+dataSource);		
		assertNotNull(sqlSessionFactory);
		logger.info("sqlSessionFactory: "+sqlSessionFactory);		
		assertNotNull(sqlSessionTemplate);
		logger.info("sqlSessionTemplate: "+sqlSessionTemplate);		
		try {
			Connection conn = dataSource.getConnection();
			assertNotNull(conn);
			logger.info("dataSource.getConnection(): "+conn);		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
