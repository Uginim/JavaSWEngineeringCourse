package com.kh.portfolio.member.dao;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.Calendar;
import java.util.List;

import javax.inject.Inject;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.kh.portfolio.member.vo.MemberVO;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(locations="file:src/main/webapp/WEB-INF/spring/root-context.xml")
public class MemberDAOTest {
	private static final Logger logger = LoggerFactory.getLogger(MemberDAOTest.class);
	@Inject
	@Qualifier("memberDAOImplXML")
	MemberDAO memberDAO;
	
	@Test
	@DisplayName("회원등록")
	@Disabled
	public void testInsert() {
		MemberVO memberVO = new MemberVO();
		memberVO.setId("test@test.test");
		memberVO.setPw("1234test");
		memberVO.setNickname("admin");
		Calendar cal = Calendar.getInstance();
		cal .set(1990, 9, 05);
		memberVO.setBirth( new java.sql.Date(cal.getTime().getTime()));
		memberVO.setTel("010-1111-2222");
		memberVO.setRegion("스울");
		memberVO.setGender("남");
		int cnt = memberDAO.joinMember(memberVO);
		assertEquals(1, cnt);
		
	
		memberVO = new MemberVO();
		memberVO.setId("test2@test.test");
		memberVO.setPw("1234test");
		memberVO.setNickname("admin");
		cal = Calendar.getInstance();
		cal .set(1990, 9, 05);
		memberVO.setBirth( new java.sql.Date(cal.getTime().getTime()));
		memberVO.setTel("010-1111-2222");
		memberVO.setRegion("스울");
		memberVO.setGender("남");
		cnt = memberDAO.joinMember(memberVO);
		assertEquals(1, cnt);
//		
		
		memberVO = new MemberVO();
		memberVO.setId("test3@test.test");
		memberVO.setPw("1234test");
		memberVO.setNickname("admin");
		cal = Calendar.getInstance();
		cal .set(1990, 9, 05);
		memberVO.setBirth( new java.sql.Date(cal.getTime().getTime()));
		memberVO.setTel("010-1111-2222");
		memberVO.setRegion("스울");
		memberVO.setGender("남");
		cnt = memberDAO.joinMember(memberVO);
		assertEquals(1, cnt);
		
		memberVO = new MemberVO();
		memberVO.setId("test4@test.test");
		memberVO.setPw("1234test");
		memberVO.setNickname("admin");
		cal = Calendar.getInstance();
		cal .set(1990, 9, 05);
		memberVO.setBirth( new java.sql.Date(cal.getTime().getTime()));
		memberVO.setTel("010-1111-2222");
		memberVO.setRegion("스울");
		memberVO.setGender("남");
		cnt = memberDAO.joinMember(memberVO);
		assertEquals(1, cnt);
		
		memberVO = new MemberVO();
		memberVO.setId("test5@test.test");
		memberVO.setPw("1234test");
		memberVO.setNickname("admin");
		cal = Calendar.getInstance();
		cal .set(1990, 9, 05);
		memberVO.setBirth( new java.sql.Date(cal.getTime().getTime()));
		memberVO.setTel("010-1111-2222");
		memberVO.setRegion("스울");
		memberVO.setGender("남");
		cnt = memberDAO.joinMember(memberVO);
		assertEquals(1, cnt);

	}
	
	@Test
	@DisplayName("회원 수정")
	@Disabled
	public void modifyMember() {
		MemberVO memberVO = new MemberVO();
		memberVO.setId("test5@test.test");
		memberVO.setNickname("notadmin");
		memberVO.setRegion("부산");
		Calendar cal = Calendar.getInstance();
		cal .set(1990, 9, 05);
		memberVO.setBirth( new java.sql.Date(cal.getTime().getTime()));
		memberVO.setTel("010-1111-2222");
		memberVO.setGender("여");		
		int cnt = memberDAO.modifyMember(memberVO);
		assertEquals(1, cnt);
	}
	
	@Test
	@DisplayName("회원 탈퇴")
	@Disabled
	public void deleteMember() {
		int cnt = memberDAO.outMember("test4@test.test", "1234test");
		assertEquals(1,cnt);
	}
	@Test
	@DisplayName("회원 개별조회")
	public void selectOne() {
		MemberVO memberVO = memberDAO.selectMember("test@test.test");
		assertNotNull(memberVO);
		logger.info("select a memberVO: "+memberVO);
	}
	@Test
	@DisplayName("회원 전체 조회")
	public void selectAll() {
		List<MemberVO> list = memberDAO.selectAllMember();
		assertNotNull(list);
		for(MemberVO memberVO: list) {
			logger.info(memberVO.toString());
		}
	}
}
