package com.kh.portfolio.member.dao;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.Calendar;
import java.util.List;

import javax.inject.Inject;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.kh.portfolio.member.vo.MemberVO;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(locations="file:src/main/webapp/WEB-INF/spring/root-context.xml")
public class MemberDAOImplTest {
	private final static Logger logger = LoggerFactory.getLogger(MemberDAOImplTest.class);

	@Inject
	@Qualifier("memberDAOImplXML")
	MemberDAO memberDAO;
	
	
	@Test
	@DisplayName("회원 등록")
	@Disabled
	public void join5Members() {
		String[] usernames = {"홍길동","홍길순","홍길서","홍길남","홍길북"}; 
		String[] emails = {"test1.test.test","test2.test.test","test3.test.test","test4.test.test","test5.test.test"};
		String[] pws = {"password1","password2","password3","password4","password5"};
		String[] regions = {"서울","대전","대구","부산","광주"};
		String[] tels = {"010-1111-1111", "010-2222-2222", "010-3333-3333", "010-4444-4444", "010-5555-5555"};
		String[] genders = {"남", "여", "여", "남", "남"};
		Calendar cal = Calendar.getInstance();
		java.util.Date[] dates = {cal.getTime(),cal.getTime(),cal.getTime(),cal.getTime(),cal.getTime()};
		MemberVO memberVO= new MemberVO();
		int cnt =0;
		for(int i=0;i<5;i++) {
			memberVO.setId(emails[i]);
			memberVO.setPw(pws[i]);
			memberVO.setNickname(usernames[i]);
			memberVO.setRegion(regions[i]);
			memberVO.setTel(tels[i]);
			memberVO.setGender(genders[i]);
			memberVO.setBirth(new java.sql.Date(dates[i].getTime()));
			cnt = memberDAO.joinMember(memberVO);
			assertEquals(1, cnt);
		}
	}
	
	@Test
	@DisplayName("회원 수정")
//	@Disabled
	public void modifyMember() {
		MemberVO memberVO= new MemberVO();
		memberVO.setId("test2.test.test");
		memberVO.setPw("잘못된 패스워드");
		memberVO.setNickname("김정은");
		memberVO.setRegion("평양");
		memberVO.setTel("010-4569-1011");		
		memberVO.setGender("남");
		Calendar cal = Calendar.getInstance();
		cal.set(1980, 2, 2);
		java.util.Date date = cal.getTime();
		memberVO.setBirth(new java.sql.Date(date .getTime()));
		int cnt = memberDAO.modifyMember(memberVO);
		assertEquals(0, cnt);		
		memberVO.setPw("password2");
		cnt = memberDAO.modifyMember(memberVO);
		assertEquals(1, cnt);
	}
	@Test
	@DisplayName("회원 탈퇴")
//	@Disabled
	public void outMember() {
		String id = "test3.test.test";
		String pw = "다른 패스워드";
		//다른 패스워드
		int cnt = memberDAO.outMember(id, pw);
		assertEquals(0, cnt);
		
		// 올바른 패스워드
		pw = "password3";
		cnt = memberDAO.outMember(id, pw);
		assertEquals(1, cnt);
	}
	
	@Test
	@DisplayName("회원 개별 조회")
	public void selectOneMember() {
		String id = "test1.test.test";
		MemberVO memberVO = memberDAO.selectMember(id);
		assertNotNull(memberVO);
		logger.info("회원 개별 조회: "+memberVO);		
	}
	
	@Test
	@DisplayName("회원 전체 조회")
	public void selectAllMember() {
		List<MemberVO> list = memberDAO.selectAllMember();
		assertNotNull(list);
		for(MemberVO vo : list) {
			logger.info("전체조회:"+vo);
		}
	}
}
