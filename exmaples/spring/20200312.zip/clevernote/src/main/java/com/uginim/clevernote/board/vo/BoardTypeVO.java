package com.uginim.clevernote.board.vo;

import lombok.Data;

@Data
public class BoardTypeVO {
	private long typeNum; // 타입 번호
	private String name; // 타입 이름
}
