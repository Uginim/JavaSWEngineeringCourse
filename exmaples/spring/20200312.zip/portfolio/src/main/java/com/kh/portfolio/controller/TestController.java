package com.kh.portfolio.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

//@Controller
@RequestMapping("/test")
public class TestController {
//	/*
//	@RequestMapping
//	@RequestMapping({"","/1","/2","/3"})
//	@RequestMapping(value={"","/1","/2","/3"},method=RequestMethod.GET)
	@RequestMapping(value={"","/1","/2","/3"},
	method={RequestMethod.GET,RequestMethod.POST})
	public String t1() {
		return "test";
	}
//	*/
	
	/*
//	하나의 메소드에서 HTTP요청 방식 중복 선언 불가	
	@GetMapping(value= {"","/1","/2","/3"})
	@PostMapping(value= {"","/1","/2","/3"})
	public String t1() {
		return "test";
	}
//	*/
	
	/*
//	이와같이 분리해서 처리함	
	@GetMapping(value= {"","/1","/2","/3"})
	public String t2_1() {
		return "test";
	}
	@PostMapping(value= {"","/1","/2","/3"})
	public String t2_2() {
		return "test";
	}
//	*/
	
	
//	@RequestMapping("/") // 이렇게 설정할 경우 '/'까지 넣어줘야 요청 가능
//	@RequestMapping
	@RequestMapping("/abc") 
	public String temp() {
		// 1) 상대경로 : 현재 요청 URL이 기준이 됨
//		return "redirect:../test"; 
//		return "redirect:.";  
//		return "redirect:./";
		
		// 2) 절대 경로: 컨텍스트 루트가 기준이 됨
//		return "redirect:/test"; // 절대경로
		
		// 3) 외부 링크 
		return "redirect:http://www.naver.com";
	}
	@RequestMapping("/abc2") 
	public String temp2() {
//		return "forward:../test"; //(X)
//		return "forward:."; //(X) 상대 경로 문자 그대로 매핑해버림
//		return "redirect:http://www.naver.com";//(X) 외부링크 안됨
		
		return "forward:/test"; //(O)
//		return "forward:"; //(O)
	}
}
