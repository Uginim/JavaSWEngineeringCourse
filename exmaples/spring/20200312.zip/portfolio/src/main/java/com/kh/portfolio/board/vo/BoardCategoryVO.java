package com.kh.portfolio.board.vo;

import javax.persistence.Entity;
import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.Digits;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Positive;
import javax.validation.constraints.Size;

import lombok.Data;

@Entity
@Data
public class BoardCategoryVO {	
//	@Pattern(regexp="^[^0]+$", message="선택하세요!")
//	@Size(min = 0, message = "분류를 선택하쇼")
//	@NotNull(message="분류를 선택하세요")
//	@Min(value = 1, message="분류를 선택하세요")
	@Positive(message="분류를 선택하세요!")
	private long cid;	// 분류코드
	private String cname; // 분류명
}
