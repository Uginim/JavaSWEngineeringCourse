package com.kh.portfolio.board.controller;

import java.io.UnsupportedEncodingException;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;
import javax.servlet.http.HttpSession;
import javax.transaction.Transactional;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.kh.portfolio.board.svc.BoardSVC;
import com.kh.portfolio.board.vo.BoardCategoryVO;
import com.kh.portfolio.board.vo.BoardFileVO;
import com.kh.portfolio.board.vo.BoardVO;
import com.kh.portfolio.member.vo.MemberVO;

@Controller
@RequestMapping("/board")
public class BoardController {
	private static final Logger logger = LoggerFactory.getLogger(BoardController.class);
	
	@Inject
	BoardSVC boardSVC;
	
	@ModelAttribute
	public void getBoardCategory(Model model) {
		List<BoardCategoryVO> boardCategoryVOList;
		boardCategoryVOList = boardSVC.getCategory();
//		if(boardCategoryVOList!=null)
//			logger.info("categoryList:"+boardCategoryVOList.toString());
//		else 
//			logger.info("categoryList: null");
		model.addAttribute("categoryList",boardCategoryVOList);
	}
	
	// 게시글 작성 양식
	@GetMapping("/writeForm")
	public String writeForm(Model model) {
//		return "/board/writeForm";
		// 여기서 작성자 넣어줘도 됨
		
		model.addAttribute("board",new BoardVO());		
		
		// case2)
//		BoardVO boardVO = new BoardVO();
//		MemberVO memberVO = (MemberVO)request.getSession().getAttribute("member");
//		boardVO.setBid(memberVO.getId());
//		boardVO.setBnickname(memberVO.getNickname());
//		model.addAttribute("board",new BoardVO());
		
		return "board/writeForm";
	}
	
	// 게시글 작성
	@PostMapping("/write")
	public String write( 
//			@ModelAttribute("board") BoardVO boardVO,
			@ModelAttribute("board") @Valid BoardVO boardVO,
			BindingResult result,// 오류의 결과
//HttpServletRequest request,			
			HttpSession session) {
		if(result.hasErrors()) {
			return "board/writeForm";
		}
//		logger.info(result.getAllErrors().toString());
		MemberVO member =(MemberVO) session.getAttribute("member");
		boardVO.setBnickname(member.getNickname());
		boardVO.setBid(member.getId());
//		logger.info("member: "+member);
		logger.info("write(BoardVO boardVO) : boardVO"+boardVO);
		boardSVC.write(boardVO);		
		return "redirect:/board";
	}
	
	// 목록보기
	@GetMapping
	public String listAll(HttpSession session, Model model) {
		MemberVO memberVO = (MemberVO)session.getAttribute("member");
		if(memberVO != null) {
			logger.info("세션있음");
		}else {
			logger.info("세션 없음");
		}
		model.addAttribute("list",boardSVC.list());
		
		return "/board/list";
	}
	
	// 게시글보기
	@GetMapping("/view/{bnum}")
	public String view(
			@PathVariable("bnum") String bnum,
			Model model) {
		Map<String,Object> map = boardSVC.view(bnum);
		BoardVO boardVO = (BoardVO)map.get("board");
		logger.info("bvo"+boardVO);
		List<BoardFileVO> files =null;
		if(map.get("files") !=null) {
			files = (List<BoardFileVO>)map.get("files");
		}
		
		model.addAttribute("bvo",boardVO);
		model.addAttribute("files", files);
		if(files!=null)
			logger.info(files.toString());
		return "/board/readForm";
	}
	
	// 첨부파일 다운로드
	@GetMapping("/file/{fid}")
	public ResponseEntity<byte[]> getFile(@PathVariable String fid) {
		BoardFileVO boardFileVO = boardSVC.fileView(fid);
		logger.info("getFile " + boardFileVO.toString());
		
		final HttpHeaders headers = new HttpHeaders();
		String[] mtypes = boardFileVO.getFtype().split("/");
		headers.setContentType(new MediaType(mtypes[0], mtypes[1]));
		headers.setContentLength(boardFileVO.getFsize());
		// 첨부파일명 한글 깨짐 방지
		String filename = null;
		try {
			filename = new String(boardFileVO.getFname().getBytes("euc-kr"),"ISO-8859-1");
		}catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		headers.setContentDispositionFormData("attachment", filename);
		return new ResponseEntity<byte[]>(boardFileVO.getFdata(),headers, HttpStatus.OK);
	}
	
	// 게시글 삭제
	@GetMapping("/delete/{bnum}")
	public String delete(@PathVariable String bnum, Model model) {
		
		// 1) 게시글 및 첨부파일 삭제		
		boardSVC.delete(bnum);
		
		// 2) 게시글 목록 가져오기
		model.addAttribute("list", boardSVC.list());
		logger.info("delete: "+bnum);
		return "/board/list";
	}
	
	// 첨부파일 1건 삭제
	@DeleteMapping("/file/{fid}")
	@ResponseBody
	public ResponseEntity<String> fileDelete(
			@PathVariable String fid){		
		ResponseEntity<String> responseEntity = null;
		int cnt = boardSVC.fileDelete(fid);
		if(cnt==1) {
			responseEntity = new ResponseEntity<String>("ok:"+fid,HttpStatus.OK);			
		}else {
			responseEntity = new ResponseEntity<String>("failed",HttpStatus.NOT_FOUND);
		}
		
		return responseEntity;		
	}
	
	// 게시글 수정
	@Transactional
	@PostMapping("/modify")
	public String modify(
			@Valid @ModelAttribute("bvo") BoardVO boardVO,
//			BindingResult result
			BindingResult result,
			Model model
			) {		
		if(result.hasErrors()) {
//			model.addAttribute("bvo", boardVO);
//			model.addAttribute("boardVO", boardVO);
			logger.info("hasErros:"+result.getFieldErrors());
			return "/board/readForm";
//			return "/board/readForm/"+boardVO.getBnum();
		}
		
		boardSVC.modify(boardVO);
		logger.info("modify:"+boardVO);
		return "redirect:/board/view/"+boardVO.getBnum();
	}
	
}
