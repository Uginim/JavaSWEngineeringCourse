package com.kh.portfolio.board.vo;


import java.sql.Timestamp;
import java.util.List;

import javax.persistence.Entity;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.springframework.web.multipart.MultipartFile; // Spring Framework에서 제공됨

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.Data;

@Entity
@Data
public class BoardVO {
	private long bnum; //게시글번호
//	private long bcategory; // 분류카데고리
//	@NotNull
	@Valid // *계층형 유효성 검사 시 추가함
	private BoardCategoryVO boardCategoryVO;
	@NotNull
	@Size(min=4, max=50, message="제목은 4~50자 까지 입력")
	private String btitle; // 제목
	private String bid; // 작성자(이메일)
	@NotNull
	private String bnickname; // 별칭
	@JsonFormat(pattern = "yyyy-mm-dd")
	private Timestamp bcdate; // 	작성일
	private Timestamp cdate; // 수정일
	private int bhit; // 조회수
	
	@NotNull(message="내용을 입력바랍니다")
	@Size(min=4, message="내용은 최소 4자 이상 입력 바랍니다!")
	private String bcontent; // 본문내용
	private char hasPicture;
	private int bgroup; //답글그룹
	private int bstep; //	답변글의 단계
	private int bindent; // 답변글의 들여쓰기	
	// 
	List<MultipartFile> files;
}
