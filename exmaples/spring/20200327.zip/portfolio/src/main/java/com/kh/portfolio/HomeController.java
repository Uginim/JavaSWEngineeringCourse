package com.kh.portfolio;

import java.text.DateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 * Handles requests for the application home page.
 */
@Controller
public class HomeController {

	private static final Logger logger = LoggerFactory.getLogger(HomeController.class);

	/**
	 * Simply selects the home view to render by returning its name.
	 */
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home(Locale locale, Model model) {
		logger.info("Welcome home! The client locale is {}.", locale);

		Date date = new Date();
		DateFormat dateFormat = DateFormat.getDateTimeInstance(DateFormat.LONG, DateFormat.LONG, locale);

		String formattedDate = dateFormat.format(date);

		model.addAttribute("serverTime", formattedDate);

//		return "home";
		return "index";
	}

	@RequestMapping("/bs/bstest")
	public String bstest() {
		return "/bs/bstest";
	}

	@GetMapping(path="/sse/stockServer",produces = "text/event-stream;charset=UTF-8")
	public ResponseEntity<String> stockServer() {
		String[] symbols = new String[] { "Samsung", "LG", "SK" };
		StringBuilder sb = new StringBuilder();
		sb.append("retry: 2000 ");
		for (String symbol : symbols) {
			int delta = (int) (Math.random() * 10);

			if (delta < 7) {
				if (System.currentTimeMillis() % 2 == 0)
					delta = -delta;
				sb.append("\n\ndata: "+symbol);
				sb.append("\ndata: "+delta);
			}
		}
		sb.append("\n");
		String result = "\n" + 
				"retry: 2000\n" + 
				"\n" + 
				"data: LG\n" + 
				"data: -2\n" + 
				"\n" + 
				"\n" + 
				"data: SK\n" + 
				"data: -6\n" + 
				"\n" + 
				"";
		ResponseEntity<String> res = null;
		res = new ResponseEntity<String>(sb.toString(), HttpStatus.OK);
//		res = new ResponseEntity<String>(result, HttpStatus.OK);
//		return new ResponseEntity<String>(sb.toString(), HttpStatus.OK);
		return res;
//		return "/sse/stock-server";
	}
}
