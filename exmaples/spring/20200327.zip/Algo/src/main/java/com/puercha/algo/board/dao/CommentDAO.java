package com.puercha.algo.board.dao;
/**
 * 댓글 기능 정의 
 * @author Hyeonuk
 *
 */
public interface CommentDAO {

}
