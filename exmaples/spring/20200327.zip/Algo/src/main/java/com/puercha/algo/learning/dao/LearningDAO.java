package com.puercha.algo.learning.dao;
/**
 * 이론학습 데이터 DAO 정의
 * @author Hyeonuk
 *
 */
public interface LearningDAO {

}
