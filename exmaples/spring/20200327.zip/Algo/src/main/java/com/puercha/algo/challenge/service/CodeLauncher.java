package com.puercha.algo.challenge.service;
/**
 * 코드 실행기능 정의
 * @author Hyeonuk
 *
 */
public interface CodeLauncher {

}
