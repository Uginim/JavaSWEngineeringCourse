package com.puercha.algo.challenge.service;
/**
 * 도전과제 기능 정의
 * @author Hyeonuk
 *
 */
public interface ChallengeService {

}
