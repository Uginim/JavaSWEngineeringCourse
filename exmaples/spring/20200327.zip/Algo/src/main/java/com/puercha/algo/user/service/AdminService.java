package com.puercha.algo.user.service;
/**
 * 관리자 기능 정의
 * @author Hyeonuk
 *
 */
public interface AdminService {

}
