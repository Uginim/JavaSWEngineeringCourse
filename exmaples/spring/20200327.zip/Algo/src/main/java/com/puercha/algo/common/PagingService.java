package com.puercha.algo.common;
/**
 * 페이징 기능 정의
 * @author Hyeonuk
 *
 */
public interface PagingService {

}
