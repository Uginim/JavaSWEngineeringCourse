package com.puercha.algo.challenge.dao;
/**
 * 도전과제 DAO 기능 정의
 * @author Hyeonuk
 *
 */

public interface ChallengeDAO {

}
