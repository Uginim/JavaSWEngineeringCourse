package com.puercha.algo.user.service;
/**
 * 사용자 기능 정의
 * @author Hyeonuk
 *
 */
public interface UserService {

}
