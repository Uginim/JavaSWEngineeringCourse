package com.puercha.algo.content.service;
/**
 * 컨텐츠 관리 기능 정의
 * @author Hyeonuk
 *
 */
public interface ContentManagingService {

}
