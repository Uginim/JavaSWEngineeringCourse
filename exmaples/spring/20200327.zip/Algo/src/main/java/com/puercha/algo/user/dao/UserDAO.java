package com.puercha.algo.user.dao;
/**
 * 사용자 데이터 DAO 정의
 * @author Hyeonuk
 *
 */
public interface UserDAO {

}
