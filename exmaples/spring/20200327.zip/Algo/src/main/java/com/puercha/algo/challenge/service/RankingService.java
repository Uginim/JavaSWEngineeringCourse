package com.puercha.algo.challenge.service;
/**
 * 랭킹 서비스 기능 정의 
 * @author Hyeonuk
 *
 */
public class RankingService {

}
