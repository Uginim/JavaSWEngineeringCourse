package com.puercha.algo.board.service;
/**
 * 댓글 기능 정의
 * @author Hyeonuk
 *
 */
public interface CommentService {

}
