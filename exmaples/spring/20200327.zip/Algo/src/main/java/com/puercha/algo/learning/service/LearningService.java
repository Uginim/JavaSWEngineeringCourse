package com.puercha.algo.learning.service;
/**
 * 이론학습 기능 정의 
 * @author Hyeonuk
 *
 */
public interface LearningService {

}
