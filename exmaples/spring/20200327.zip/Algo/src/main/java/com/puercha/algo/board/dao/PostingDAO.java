package com.puercha.algo.board.dao;
/**
 * 게시글 DAO 정의
 * @author Hyeonuk
 *
 */
public interface PostingDAO {

}
