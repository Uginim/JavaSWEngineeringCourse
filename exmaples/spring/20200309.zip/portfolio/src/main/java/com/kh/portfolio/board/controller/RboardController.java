package com.kh.portfolio.board.controller;

import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.kh.portfolio.board.svc.RboardSVC;
import com.kh.portfolio.board.vo.RboardVO;

@RestController
@RequestMapping("/rboard")
public class RboardController {
	private static final Logger logger = LoggerFactory.getLogger(RboardController.class);

	@Inject
	RboardSVC rboardSVC;

	// 댓글 작성
	@PostMapping(value = "", produces = "application/json")
	public ResponseEntity<String> write(@RequestBody(required = true) RboardVO rboardVO) {
		ResponseEntity<String> res = null;
		logger.info("write() 호출됨!");
		logger.info("rboardVO : " + rboardVO.toString());
		// 유효성 체크
		if (rboardVO.getBnum() > 0 && rboardVO.getRid() != null && rboardVO.getRnickname() != null
				&& rboardVO.getRcontent() != null) {
			// 댓글 작성
			rboardSVC.write(rboardVO);

			// 성공
			res = new ResponseEntity<String>("success", HttpStatus.OK);

		} else {
			// 실패
			res = new ResponseEntity<String>("fail", HttpStatus.BAD_REQUEST);

		}

		return res;
	}

	// 댓글 수정
	@PutMapping(value = "", produces = "application/json")
	public ResponseEntity<String> modify(@RequestBody(required = true) RboardVO rboardVO) {
		ResponseEntity<String> res = null;
		logger.info("write() 호출됨!");
		logger.info("rboardVO : " + rboardVO.toString());
		// 유효성 체크
		if (rboardVO.getRnum() > 0 &&
//			rboardVO.getBnum() > 0 &&
//			rboardVO.getRid() != null &&
//			rboardVO.getRnickname() != null &&
				rboardVO.getRcontent() != null) {
			// 댓글 작성
			rboardSVC.modify(rboardVO);

			// 성공
			res = new ResponseEntity<String>("success", HttpStatus.OK);

		} else {
			// 실패
			res = new ResponseEntity<String>("fail", HttpStatus.BAD_REQUEST);

		}

		return res;
	}

	// 댓글 삭제
	@DeleteMapping(value = "/{rnum}", produces = "application/json")
	public ResponseEntity<String> delete(@PathVariable(required = true) String rnum) {

		ResponseEntity<String> res = null;
		int cnt = rboardSVC.delete(rnum);
		if (cnt == 1) {
			res = new ResponseEntity<String>("success", HttpStatus.OK);
		} else {
			// 실패
			res = new ResponseEntity<String>("fail", HttpStatus.BAD_REQUEST);
		}
		return res;
	}
	
	//대댓글 작성
	@PostMapping(value = "reply", produces = "application/json")
	public ResponseEntity<String> writeReply(@RequestBody(required = true) RboardVO rboardVO) {
		ResponseEntity<String> res = null;
		logger.info("write() 호출됨!");
		logger.info("rboardVO : " + rboardVO.toString());
		// 유효성 체크
		if (rboardVO.getBnum() > 0 &&
				rboardVO.getPrnum() > 0 &&
				rboardVO.getRid() != null && 
				rboardVO.getRnickname() != null	&& 
				rboardVO.getRcontent() != null) {
			// 댓글 작성
			rboardSVC.reply(rboardVO);

			// 성공
			res = new ResponseEntity<String>("success", HttpStatus.OK);

		} else {
			// 실패
			res = new ResponseEntity<String>("fail", HttpStatus.BAD_REQUEST);

		}

		return res;
	}

}
