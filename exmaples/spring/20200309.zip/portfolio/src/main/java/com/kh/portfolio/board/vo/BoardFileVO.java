package com.kh.portfolio.board.vo;

import java.sql.Timestamp;
import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import lombok.Data;

@Data
public class BoardFileVO {
	// 첨부파일
	private List<MultipartFile> file;	
	private long fid;  // 파일아이디
	private long bnum; // 게시글
	private String fname; // 파일명(한글 50자 제한)
	private long fsize; // 파일 크기
	private String ftype; // 파일 유형
	private byte[] fdata; // 첨부파일
	private Timestamp cdate; // 작성일
	private Timestamp udate; // 수정일
}
