package com.kh.portfolio.controller;

import javax.inject.Inject;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.kh.portfolio.exception.BizException;
import com.kh.portfolio.member.svc.MemberSVC;
import com.kh.portfolio.member.vo.MemberVO;

@Controller
//@RequestMapping("/member")
public class LoginController {
	private static final Logger logger = LoggerFactory.getLogger(LoginController.class);
	
	@Inject
	MemberSVC memberSVC;
	// 로그인 양식
//	@RequestMapping("/login")
	@GetMapping("/loginForm")
	public String loginForm() {
		return "/member/signinForm";
	}
	
	// 로그인 처리
	@PostMapping("/login")
	public String login(@RequestParam("id") String id,
			@RequestParam("pw") String pw,
			HttpSession session,
			Model model) {
		
		logger.info("id="+id);
		logger.info("pw="+pw);
		
		MemberVO memberVO = memberSVC.selectMember(id);
		// 1) 회원이 없는 경우
		if(memberVO == null) {
			model.addAttribute("svr_msg","가입된 회원 정보가 없습니다.");
//			throw new BizException("가입된 회원 정보가 없습니다.");
		} else {	// 2) 회원이 있는 경우			
			
			// 2-1) 아이디는 일치하나 비밀번호가 다른 경우
			if(pw.equals(memberVO.getPw())) {
				session.setAttribute("member", memberVO);
				return "redirect:/";
			}else {
				// 2-2) 아이디와 비밀번호가 일치하는 경우
				model.addAttribute("svr_msg","비밀번호가 일치하지 않습니다.");				
			}
		}
		session.invalidate(); // 로그인에 실패했을 경우 세션에 남아있는 정보 삭제
		return "/member/loginForm";

	}
	
	// 로그아웃
	@GetMapping("/logout")
	public String logout(HttpSession session) {
		
		session.invalidate();
		return "redirect:/";
	}
	

}
