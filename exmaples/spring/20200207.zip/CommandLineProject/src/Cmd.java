import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;

import javax.tools.JavaCompiler;
import javax.tools.ToolProvider;

public class Cmd {
	
	private StringBuffer buffer;
	private Process process;
	private BufferedReader bufferedReader;
	private StringBuffer readBuffer;
	
	public String inputCommand(String cmd) {
		
		buffer = new StringBuffer();
		
		buffer.append("cmd.exe ");	
		buffer.append("/c ");
		buffer.append(cmd);

		return buffer.toString();
	}
	
	public String execCommand(String cmd) {
		try {
//			process = Runtime.getRuntime().exec(cmd);
//			process = Runtime.getRuntime().exec("cmd.exe /c echo \"hello\"");
			process = Runtime.getRuntime().exec("cmd.exe /c echo \"hello\"");
			
			JavaCompiler jc = ToolProvider.getSystemJavaCompiler();
			OutputStreamWriter osw = new OutputStreamWriter(process.getOutputStream());
			BufferedWriter bw = new BufferedWriter(osw);
			
			osw.append("echo \"hi\" ");
			osw.write(0);
			
			InputStreamReader isr = new InputStreamReader(process.getInputStream());
			System.out.println(isr.getEncoding());
			bufferedReader = new BufferedReader(isr);
			
			String line = null;
			readBuffer = new StringBuffer();
			
			while((line = bufferedReader.readLine()) != null) {
				readBuffer.append(line);
				readBuffer.append("\n");
			}
			
//			bw.flush();
			return readBuffer.toString();
		}catch (Exception e) {
			e.printStackTrace();
			System.exit(1);
		}
		
		return null;
	}
}
