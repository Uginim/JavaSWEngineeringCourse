package quiz3;

public class Rectangle extends Shape {
	private double width;
	private double depth;
	public Rectangle(double width, double depth) {
		this.depth = width;
		this.width = depth;
	}
	@Override
	public double figureOutArea() {
		
		return depth*width;
	}

	@Override
	public double figureOutCircumference() {
		// TODO Auto-generated method stub
		return depth*2+width*2;
	}
	public double getWidth() {
		return width;
	}
	public double getDepth() {
		return depth;
	}

}
