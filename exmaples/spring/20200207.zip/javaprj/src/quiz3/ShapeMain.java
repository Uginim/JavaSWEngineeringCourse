package quiz3;

import java.util.Vector;

public class ShapeMain {
	public static void main(String[] args) {
		Vector <Shape> shapes = new Vector<Shape>(); 
		shapes.add(new Circle(10));
		shapes.add(new Rectangle(10,20));
		shapes.add(new Square(10,10,10));
		shapes.add(new Square(3,4,5));		
		shapes.add(new Rectangle(44.22,45.04));
		shapes.add(new Circle(10));
		// 부피 구하기 figureOutVolume();
		System.out.println("부피는 "+new Square(3,4,5).figureOutVolume());
		for(int i=0;i< shapes.size();i++) {
			Shape s = shapes.get(i);
			System.out.printf("[%d]번 %s의 넓이는 %.2f이고 둘레의 길이는 %.2f이다.%n",i+1,s,s.figureOutArea(),s.figureOutCircumference());
		}
		
	}
}
