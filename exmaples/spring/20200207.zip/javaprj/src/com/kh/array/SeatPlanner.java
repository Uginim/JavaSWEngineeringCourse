package com.kh.array;
/**
 * 2019.10.29 Java SW Engineering Course
 * 좌석 예약 시스템
 * @author Hyeonuk
 */
import java.util.Scanner;

public class SeatPlanner {
	/**
	 * 좌석현황
	 */
	static boolean[][] reservedSeats = new boolean[6][10];
	/**
	 * 좌석현황 출력하기
	 */
	static void printStateOfAllSeats () {
		System.out.println("---------------좌석 현황----------------");
		System.out.println("|| [ X] : 이미 예약된좌석             ||");
		System.out.println("|| [수] : 좌석의 번호                 ||");
		System.out.println("----------------------------------------");

		for(int row=0; row < reservedSeats.length ; row++) {
			for(int col=0; col < reservedSeats[row].length ; col++) {
				if(reservedSeats[row][col])
					System.out.printf("[%2s]","X");
				else 
					System.out.printf("[%2d]",row*reservedSeats[row].length+col+1);
			}
			System.out.println();
		}
	}
	/**
	 * seatNum로 부터 row를 구한다.
	 * @param seatNum "실제 좌석 번호" - 1
	 * @return 구해진 row (0부터 시작)
	 */
	static int getRow(int seatNum) {
		return seatNum/reservedSeats[0].length;
	}
	/**
	 * seatNum로 부터 col를 구한다.
	 * @param seatNum "실제 좌석 번호" - 1
	 * @return 구해진 col (0부터 시작)
	 */
	static int getCol(int seatNum) {
		return seatNum%reservedSeats[0].length;
	}
	/**
	 * 좌석을 예약합니다.
	 * @param row (0부터 시작)
	 * @param col (0부터 시작)
	 */
	static void reserveSeat(int row, int col) {
		reservedSeats[row][col] = true;
	}
	/**
	 * 좌석의 예약여부확인
	 * @param row (0부터 시작)
	 * @param col (0부터 시작)
	 * @return 이미예약되었으면 true
	 */
	static boolean isReservedSeat(int row, int col) {
		return reservedSeats[row][col];
	}
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		
		while(true) {			
			printStateOfAllSeats();
			System.out.println("종료하시려면(X)");
			System.out.print("예매하실 좌석을 선택하세요 (1~60) >>");			
			String tmp = scan.nextLine();
			if(tmp.equalsIgnoreCase("X"))
				break;
			tmp = tmp.trim();
			int seatNum = Integer.parseInt(tmp)-1;
			int row = getRow(seatNum);
			int col = getCol(seatNum);
			if(isReservedSeat(row, col)) {
				System.out.println("\n이미 예약된 좌석입니다.\n다른 좌석을 선택해 주세요.\n");
			} else {
				reserveSeat(row,col);
				System.out.printf("%d번 좌석(%d행 %d열)이 성공적으로 예약되었습니다. %n좌석표를 확인해주시길바랍니다.%n",seatNum+1,row+1,col+1);
			}
			
		}
		System.out.println("종료되었습니다.");
		System.exit(0);
	}

}
