package com.kh.array;

public class Array2Exam1 {

	public static void main(String[] args) {
		int[][] arr = new int[2][5]; // 2차원 배열 선언 및 생성

		
		// 2차원 배열 초기값 대입하기
		int num = 0;
		for (int i = 0; i < arr.length; i++) {
			for (int j = 0; j < arr[i].length; j++) {
//				num = (int) (Math.random() * 10) + 1; // 1~10의 수 랜덤
//				arr[i][j] = num;
				arr[i][j] = ++num;
			}
		}
		System.out.println("arr=" + arr);
		System.out.println("arr.length=" + arr.length);
		System.out.println("-----------------------");

		System.out.println("arr[0]=" + arr[0]);
		System.out.println("arr[1]=" + arr[1]);
		System.out.println("-----------------------");

		System.out.println("arr[0].length=" + arr[0].length);
		System.out.println("arr[1].length=" + arr[1].length);
		System.out.println("-----------------------");

		// arr[0]가 참조하는 배열의 값 출력
		for (int i = 0; i < arr[0].length; i++) {
			System.out.println("arr[0][" + i + "]=" + arr[0][i]);
		}
		System.out.println("-----------------------");
		// arr[1]가 참조하는 배열의 값 출력
		for (int i = 0; i < arr[0].length; i++) {
			System.out.println("arr[1][" + i + "]=" + arr[1][i]);
		}

		System.out.println("-----------------------");
		for (int i = 0; i < arr.length; i++) {
			for (int j = 0; j < arr[i].length; j++) {
				System.out.println("arr[" + i + "][" + j + "]=" + arr[i][j]);
			}
		}
	}

}
