package com.kh.array;

import java.util.Scanner;

/**
 * 2차원 배열을 사용해서 구구단을 출력하기
 * 1. 사용자로부터 단수 입력받기
 * 2. 향상된 중첨 for문 사용
 * 향상된 for문 사용
 * @author Hyeonuk
 */
public class MyArray2For2 {

	public static void main(String[] args) {
		final int MAX_ROW = 9;
		final int MAX_COL = 5;
		final int COL_OP1 = 0;
		final int COL_MULTI_SIGN = 1;
		final int COL_OP2 = 2;
		final int COL_EQUAL_SIGN = 3;
		final int COL_RESULT= 4;
		String input;
		Scanner scan = new Scanner(System.in);
		String[][] results = new String[MAX_ROW][MAX_COL];
		System.out.print("몇 단을 출력할까요>>");
		input = scan.nextLine();
		int dan = Integer.parseInt(input);
		int i=0,j=0;
		for(String[] row : results) {
			for(String col : row) { // col 안씀
				switch(j) {
				case COL_OP1:
					results[i][j]=dan+"";
					break;
				case COL_MULTI_SIGN:
					results[i][j]=" * ";
					break;
				case COL_OP2:
					results[i][j]=(i+1)+"";
					break;
				case COL_EQUAL_SIGN:
					results[i][j]=" = ";
					break;
				case COL_RESULT:
					results[i][j]=(dan*(i+1))+"";
					break;
				}
				j++;
			}
			i++;j=0;
		}
		System.out.printf("%d단출력%n",dan);
		for(String[] row : results) {
			for(String str : row) {
				System.out.print(str);
			}
			System.out.println();
		}		
	}

}
