package com.kh.array;

public class ArrayExam1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub		
		
		int kor = 90;
		int math = 80;
		int eng = 70;
		
		int sum = 0; 
		double ave = 0.0;
		
		sum = kor + math + eng;
		ave = sum / (3*1.0);
		System.out.printf("합계 = %5d", sum);
		System.out.printf("평균 = %8.2f", ave);
		
		System.out.println("==============================");
		int[] score = new int[3]; //배열 선언 및 초기화
		
		int[] score2; // 배열 선언
//		int[] score2 = null; // 배열 선언
		score2 = new int[3]; // 배열 초기화
		
//		int[] score3 = new int[] {90,80,70}; // 배열선언, 초기화, 초기값설정
		int[] score3; // 배열선언
		score3 = new int[] {90,80,70}; // 배열선언, 초기화, 초기값설정
		
		
		int[] score4 = {90,80,70}; // 배열선언, 초기화, 초기값설정
//		int[] score4;
//		iscore4 = {90,80,70}; // 불가
		
		//배열의 값 읽어오기
		System.out.println("배열의 크기="+ score.length);
		System.out.println("score[0] = " + score[0]);
		System.out.println("score[1] = " + score[1]);
		System.out.println("score[2] = " + score[2]);
		System.out.println("==============================");
		for(int i=0; i<score.length ;i++) {
			System.out.println("score["+i+"] = " + score[i]);
		}
		System.out.println("==============================");
		
		// 배열의 값 저잦ㅇ하기
		score[0]= 90;
		score[1]= 80;
		score[2]= 70;
		System.out.println("score[0] = " + score[0]);
		System.out.println("score[1] = " + score[1]);
		System.out.println("score[2] = " + score[2]);
	}

}
