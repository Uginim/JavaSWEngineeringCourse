package com.kh.array;

public class MainStringArrayParam_dummy {
	public static void main(String[] args) {
		double result = 0.0;
		
		// 1) 실행 매개값 갯수 체크
		if(args.length != 3) {
			System.out.println("매개값 3개가 필요합니다.");
			System.exit(0);
		}
		// 2) 연산자 유효성 체크
		// 1개의 문제인지 체크 && +,-,x,/에 해당하는 문자인지 체크
		if(args[1].length() == 1) {
			
			switch(args[1]) {
			case "+" :
			case "-" :
			case "x" :
			case "X" :
			case "/" :
				break;
				default :
					System.out.println("4칙연산자 아닙니다.");
					System.out.println("프로그램 종료!");
					System.exit(0);
					
			}
		}
		
		// 3) 피연산자 정수유무 체크
		boolean isOperand1 = false;
		for(char ch : args[0].toCharArray()) {
			if(ch >= '0' && ch <'9') {
				isOperand1 = true;
			}else {
				isOperand1 = false;
				break;
			}
		}
		boolean isOperand2 = false;
		for(char ch : args[2].toCharArray()) {
			if(ch >= '0' && ch <'9') {
				isOperand2 = true;
			}else {
				isOperand2 = false;
				break;
			}
		}
		if(isOperand2 == false || isOperand2 == false) {
			System.out.println("피연산자를 제대로넣으세요.");
			System.out.println("프로그램 종료!");
			System.exit(0);
		}
		
		System.out.println("유효성 체크 통과!!");
		
		// 4) 연산 수행
		int num1 = Integer.parseInt(args[0]);
		int num2 = Integer.parseInt(args[2]);
		switch(args[1]) {
			// 덧셈
		case "+" : 
			System.out.println(num1 + " + " + num2 + " = " + (num1+num2));
			break;
		// 뺄셈		
		case "-" : 
			System.out.println(num1 + " - " + num2 + " = " + (num1-num2));
			break;
		// 곱셈		
		case "x" :case "X": 
			System.out.println(num1 + " X " + num2 + " = " + (num1*num2));
		break;
		// 나눗셈
		case "/" : 
			System.out.println(num1 + " / " + num2 + " = " + (float)(num1/num2));
			break;
		default:
			System.out.println("4칙연산자 아닙니다.");
			System.out.println("프로그램 종료!");
			System.exit(0);
		}
	}
}
