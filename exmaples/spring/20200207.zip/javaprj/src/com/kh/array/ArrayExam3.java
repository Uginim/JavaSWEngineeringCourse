package com.kh.array;

import java.util.Arrays;

/**
 * 2019.10.29 Java SW Engineering Course
 * 
 * @author Hyeonuk
 *
 */
public class ArrayExam3 {
	public static void main(String[] args) {
		// 40byte가 heap메모리에 생성되고 그 주소값을 arr1 변수가 가지고 있음.
		int [] arr1 = new int[10];
		
		System.out.println("arr1="+arr1);
		System.out.println("arr1.length="+arr1.length);
		
		System.out.println("-------------------------------------");
		char[] chArr = new char[] {'a','b','c'};
		System.out.println("chArr="+chArr);		
		System.out.println(chArr); // 이것도 되지롱! 대신 println만 되는 것
		System.out.println("chArr[2]="+chArr[2]);
		System.out.println("chArr.length="+chArr.length);
		
		System.out.println("default-value------------------------");
//		char[] arr2 = new char[10];
//		boolean [] arr2 = new boolean[10];
//		long [] arr2 = new long[10];
//		float [] arr2 = new float[10];
		String [] arr2 = new String[10];
//		for(char num : arr2) { // 공백하나표시 하지만 \u0000은 공백이 아니다
//		for(boolean num : arr2) { // false
//		for(long num : arr2) { // 0
		for(String num : arr2) { // null
			System.out.println("num="+num);
		}
		
		System.out.println("-------------------------------------");
		for(int i =0 ;i<arr1.length;i++) {
			arr1[i] = (int)(Math.random()*10)+1;
		}
		for(int i=0;i<arr1.length;i++) {
			if(i==arr1.length-1){
				System.out.println(arr1[i]);
			}else {
				System.out.print(arr1[i]+","); // 나중에 람다 가면 더 쉽게 할 수 있음
			}			
		}

		System.out.println("-------------------------------------");
	// Arrays클래스는 배열을 쉽게 조작하기위해 만들어놓은 표준 클래스
		System.out.println(Arrays.toString(arr1)); 
		System.out.println(Arrays.toString(chArr));
		System.out.println((int)' ');
		System.out.println((int)'\u0000');
		System.out.println(""+null);
		
	}
}
