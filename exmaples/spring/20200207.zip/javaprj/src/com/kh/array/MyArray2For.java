package com.kh.array;

import java.util.Scanner;

/**
 * 2차원 배열을 사용해서 구구단을 출력하기 
 * @author Hyeonuk
 */
public class MyArray2For {

	public static void main(String[] args) {
		final int MAX_ROW = 9;
		final int MAX_COL = 5;
		final int COL_OP1 = 0;
		final int COL_MULTI_SIGN = 1;
		final int COL_OP2 = 2;
		final int COL_EQUAL_SIGN = 3;
		final int COL_RESULT= 4;
		String input;
		Scanner scan = new Scanner(System.in);
		String[][] results = new String[MAX_ROW][MAX_COL];
		System.out.print("몇 단을 출력할까요>>");
		input = scan.nextLine();
		int dan = Integer.parseInt(input);
		for(int i= 0;i< results.length;i++) {
			for(int j=0;j< results[1].length;j++) {
				switch(j) {
				case COL_OP1:
					results[i][j]=dan+"";
					break;
				case COL_MULTI_SIGN:
					results[i][j]=" * ";
					break;
				case COL_OP2:
					results[i][j]=(i+1)+"";
					break;
				case COL_EQUAL_SIGN:
					results[i][j]=" = ";
					break;
				case COL_RESULT:
					results[i][j]=(dan*(i+1))+"";
					break;
				}
			}
		}
		System.out.printf("%d단출력%n",dan);
		for(int i =0;i<results.length;i++) {
			for(int j=0;j<results[i].length;j++) {
				System.out.print(results[i][j]);
			}
			System.out.println();
		}		
	}

}
