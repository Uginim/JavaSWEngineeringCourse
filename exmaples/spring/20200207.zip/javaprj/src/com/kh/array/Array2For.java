package com.kh.array;

import java.util.Scanner;

/**
 * 2차원 배열을 사용해서 구구단을 출력하기
 * 
 * @author Hyeonuk
 */
public class Array2For {

	public static void main(String[] args) {
		final int ROW = 9; // 행
		final int COL = 5; // 열
		String[][] array = new String[ROW][COL];
		Scanner scanner = new Scanner(System.in);
		while (true) {
			
			System.out.print("출력할 단수를 입력하세요(종료 00) >>");
			String tmp = scanner.nextLine(); // 엔터 키 입력 전까지
			if(tmp.equals("00")) {
				System.out.println("프로그램 종료!!");
				System.exit(0);
			}
			
			for (int i = 0; i < array.length; i++) {
				for (int j = 0; j < array[i].length; j++) {
					switch (j) {
					case 0:
						array[i][j] = tmp;
						break;
					case 1:
						array[i][j] = "*";
						break;
					case 2:
						array[i][j] = "" + (i + 1);
						break;
					case 3:
						array[i][j] = "=";
						break;
					case 4:
						array[i][j] = "" + (Integer.parseInt(array[i][0]) * Integer.parseInt(array[i][2]));
						break;
					default:
						System.out.println("오류!!");
						break;
					}
				}
			}
			for (int i = 0; i < array.length; i++) {
				for (int j = 0; j < array[i].length; j++) {
					System.out.print(array[i][j]);
				}
				System.out.println();
			}
		}
	}
}
