package com.kh.bit;

public class BitExam2 {

	public static void main(String[] args) {
		int num1 = 5;
		int num2 = -5;
		
		System.out.println("num1("+num1+") : "+BitExam.toBinaryString(num1));
		System.out.println("num2("+num2+") : "+BitExam.toBinaryString(num1));
	}

}
