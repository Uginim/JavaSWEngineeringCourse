package com.kh.generic.exam5;

public class Student extends Person {
	public Student(String name) {
		super(name);
	}
}
