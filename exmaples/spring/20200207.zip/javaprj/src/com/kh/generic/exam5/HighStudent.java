package com.kh.generic.exam5;

public class HighStudent extends Student{

	public HighStudent(String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}
	
}
