package com.kh.generic.exam4;

public class BoxingMethodMain {
	public static void main(String[] args) {
//		Box<Integer> box1 = Util.<Integer>boxing(100);
		Box<Integer> box1 = Util.boxing(100); // <Integer>생략 가능// 컴파일러가 타입을보고 자동적으로 해줌
//		Integer intValue = box1.getT(); // 본래는 이렇게 받아야함
		int intValue = box1.getT(); // 자동unboxing으로 기본타입으로 자동형변환 됨
		
		Box<String> box2 = Util.<String>boxing("홍길동");
		String strValue = box2.getT();
	}
}
