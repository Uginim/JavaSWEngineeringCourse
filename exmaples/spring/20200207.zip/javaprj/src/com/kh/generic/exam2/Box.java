package com.kh.generic.exam2;

// <> 다이아몬드 연산자
public class Box <T> {
	private T object;
	
	public T getObject() {
		return object;
	}
	
	public void setObject(T object) {
		this.object = object;
	}
}
