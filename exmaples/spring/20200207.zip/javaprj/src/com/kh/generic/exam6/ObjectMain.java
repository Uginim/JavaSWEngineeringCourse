package com.kh.generic.exam6;

import java.util.HashSet;
import java.util.Set;

public class ObjectMain {

	public static void main(String[] args) {
		String name = "홍길동";
		String name2 = "홍길동";
		String name3 = new String("홍길동");
		String name4 = new String("홍길동");
		
		System.out.println(name.hashCode());
		System.out.println(name2.hashCode());
		System.out.println(name3.hashCode());
		System.out.println(name4.hashCode());

		System.out.println("==============");
		Person p1 = new Person("홍길동",30);
		Person p2 = new Person("홍길동",30);
//		System.out.println(p1.hashCode());
//		System.out.println(p2.hashCode());
		
		Set<Person> set = new HashSet<>();
		set.add(p1); set.add(p2);
		System.out.println(set.size());
		System.out.println("==============");
		// 순수한 hashcode값 리턴
		System.out.println(System.identityHashCode(p1));
		System.out.println(System.identityHashCode(p2));
	}

}
