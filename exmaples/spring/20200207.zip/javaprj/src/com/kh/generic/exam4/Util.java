package com.kh.generic.exam4;

public class Util {
	// 메소드 제너릭
	// 리턴 타입 앞에 제너릭 선언
	public static <T > Box<T> boxing(T t) {
		Box<T> box = new Box<T>();
		box.setT(t);
		return box;
	}
	
//	public static Box<Integer> boxing(Integer t){
//		Box<Integer> box = new Box<Integer>();
//		box.setT(t);
//		return box;
//	}
}

