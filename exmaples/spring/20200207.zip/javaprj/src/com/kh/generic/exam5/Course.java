package com.kh.generic.exam5;

public class Course<T> {
	private String name;
	private T[] students;
	@SuppressWarnings("unchecked")
	private T test = (T) new Object();
	private T test2 = (T) new String();
	@SuppressWarnings("unchecked")
	public Course(String name, int capacity) {
		this.name = name;
//		students = new T[capacity];
		students = (T[]) new Object[capacity];
	}
	public String getName() {return name;}
	@SuppressWarnings("unchecked")
	public T[] getStudents() {
		return students;
//		return null;
	}
	
	public void add(T t) {
		for(int i= 0; i< students.length;i++) {
			if(students[i] == null) {
				students[i] = t;
				break;
			}
		}
	}
}
