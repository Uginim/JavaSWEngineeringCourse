package com.kh.generic.exam5;

public class Worker extends Person{
	public Worker(String name) {
		super(name);
	}

}
