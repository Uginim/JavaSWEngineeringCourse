package com.kh.generic.exam3;

public class Product<T, M> { // Product 멀티 제너릭 타입
	private T kind;
	private M model;
	
	public T getKind() {return this.kind;}
	public M getModel() {return this.model;}
	
	public void setKind(T kind) {this.kind=kind;}
	public void setModel(M model) {this.model=model;}
}
