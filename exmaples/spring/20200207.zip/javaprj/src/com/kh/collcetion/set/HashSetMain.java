package com.kh.collcetion.set;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

public class HashSetMain {
	public static void main(String[] args) {
		Set<String> set = new HashSet<>();
		set.add("java");
		set.add("html");
		set.add("css");
		set.add("javascript");
		set.add("java"); // 5개 째 (동일한 것 추가됨) // 중복 허용 안됨
		
		int size = set.size();
		System.out.println("객체 총 갯수:"+size);
		
		// 향상된 for문 (for-each문)
		for(String str: set) {
			System.out.println(str);
		}
		System.out.println("=================");
		
		// iterator사용
		Iterator<String> iterator = set.iterator();
		while(iterator.hasNext()) {
			String element = iterator.next();
			System.out.println(element);
		}
		
		// 요소 삭제
		set.remove("html");
		size = set.size();
		System.out.println("객체 총 갯수:"+size);
		
		// 요소 전체 삭제
		set.clear();
		size = set.size();
		System.out.println("객체 총 갯수:"+size);
		
		
		if(set.isEmpty()) {
			System.out.println("요소가 없음!!");
		}
		System.out.println("=================");
		
		Set<Person> set2 = new HashSet<>();
		set2.add(new Person("홍길동", 30));
		set2.add(new Person("홍길순", 20));
		set2.add(new Person("홍길동", 30));
		
		System.out.println("총 객체 수 : "+set2.size());
		
	}
}
