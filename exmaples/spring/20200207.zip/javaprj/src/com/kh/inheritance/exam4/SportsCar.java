package com.kh.inheritance.exam4;

public class SportsCar extends Car {
	@Override
	public void speedUp() {
		speed +=10;
		System.out.println("현재 속도 :"+speed);
	}
}
