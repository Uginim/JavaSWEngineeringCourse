	package com.kh.inheritance.exam3;

public class SupersonicAirplane extends Airplane {
	public static final int NOMAL = 1; // 일반 비행
	public static final int SUPERSONIC = 2; // 초음속비행
	
	public int flyMode = NOMAL;

	public SupersonicAirplane() {
		super();
	}
	@Override 
	public void fly() {
		if(flyMode== SUPERSONIC) {
			System.out.println("초음속비행합니다.");
		}else {
			super.fly();	
		}
		
	}
}
