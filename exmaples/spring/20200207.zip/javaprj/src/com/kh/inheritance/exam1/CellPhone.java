package com.kh.inheritance.exam1;
/**
 * 2019.11.13 Java SW Engineering Course
 * @author Hyeonuk
 */
public class CellPhone {
	// 멤버 필드
	String model;
	String color;
	
	// 생성자
	public CellPhone() {
		System.out.println("CellPhone 생성자 호출!");
	}
	
	// 멤버메소드
	void powerOn() {
		System.out.println("전원을 켭니다.");
	}
	
	void powerOff() {
		System.out.println("전원을 끕니다.");
	}
	
	void bell() {
		System.out.println("벨이 울립니다.");
	}
	
	void sendVoice(String message) {
		System.out.println("나 : " + message);
	}
	
	void receiveVoid(String message) {
		System.out.println("상대 : "+ message);
	}
	
	void hangUp() {
		System.out.println("전화를 끊습니다.");
	}


	// 재정의(overriding) : 부모메소드의 몸체(구현부, 바디)를 새롭게 정의해서 사용하는 방식
	// 전제조건 : 1. 상속관계 2. 부모메소드의 선언부가 동일해야한다.
//	@Override 
//	public String toString() {
//		return null;
//	}
	@Override
	public String toString() {
		return "CellPhone [model=" + model + ", color=" + color + "]";
	}
	
}
