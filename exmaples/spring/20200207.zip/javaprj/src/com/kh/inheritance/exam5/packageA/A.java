package com.kh.inheritance.exam5.packageA;

public class A {
	protected String field;
	
	protected A(){}
	
	protected void method() {}
	
}
