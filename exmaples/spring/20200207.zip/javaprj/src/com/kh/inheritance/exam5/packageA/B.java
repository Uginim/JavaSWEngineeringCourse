package com.kh.inheritance.exam5.packageA;

public class B extends A{
	public B() {
		this.field = "홍길동";
		this.method();
	}
	public void method() {
		
		A a = new A();
		
		a.field = "홍길동";
		
		a.method();
		
	}
}
