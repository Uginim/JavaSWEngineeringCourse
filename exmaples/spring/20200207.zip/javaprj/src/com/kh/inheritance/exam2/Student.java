package com.kh.inheritance.exam2;

public class Student extends People {
	public int studentNo;			// 학번
	public Student(String name, String ssn, int studentNo) {
		super(name,ssn);
		this.studentNo = studentNo;
	}
}
