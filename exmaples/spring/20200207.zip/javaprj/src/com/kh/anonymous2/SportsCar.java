package com.kh.anonymous2;

public class SportsCar implements Vehicle {

	@Override
	public void run() {
		System.out.println("스폽카, 가고싶은데로 간다!");
	}

}
