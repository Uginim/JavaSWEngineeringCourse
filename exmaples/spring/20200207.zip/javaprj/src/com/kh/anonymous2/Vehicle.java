package com.kh.anonymous2;

public interface Vehicle {
	void run();
}
