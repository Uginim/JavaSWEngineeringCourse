package com.kh.anonymous2;

public class Bycle implements Vehicle {

	@Override
	public void run() {
		System.out.println("자전거, 가고싶은데로 간다!");
	}

}
