/**
 * 2019.10.21 Java SW Engineering Course
 * Conditional Expression Example  
 * @author Hyeonuk
 *
 */
package com.kh.control;

public class IfExam2 {

	public static void main(String[] args) {
		int number = 3; // Declare integer variable and initialize
		
		// java's arithmetic operator 
		// +,-,*,/,%(modulo) ...
		
		int dividend = 7;
		int divisor = 3;
		
		int remainder = dividend % divisor; // modulo
		System.out.println("remainder"+dividend+"/"+divisor+"="+remainder);
		//
		
		if(number % 2 == 0) {
			System.out.println("짝수");
		} else {
			System.out.println("홀수");
		}
		boolean isEven = number % 2 == 0;
		System.out.println(isEven);
	}

}
