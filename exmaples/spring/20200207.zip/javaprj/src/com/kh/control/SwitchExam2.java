package com.kh.control;
/**
 * 2019.10.21 Java SW Engineering Course
 * Switch statement Example 2
 * @author Hyeonuk
 */
public class SwitchExam2 {
	public static void main(String[] args) {
		char grade = ' ';
		
		switch(grade) {
		case 'A':
		case 'a':
			System.out.println("우수회원");
			break;
			
		case 'B':
		case 'b':
			System.out.println("일반회원");
			break;
			
		default:
			System.out.println("손님");
		}
	}
}
