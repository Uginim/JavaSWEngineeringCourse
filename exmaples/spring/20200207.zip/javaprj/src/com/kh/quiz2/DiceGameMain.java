package com.kh.quiz2;

/**
 * 2019.11.14 Java SW Engineering Course
 * @author Hyeonuk
 */
import java.util.Scanner;

public class DiceGameMain {
	class PlayerResult {

	}

	public static void main(String[] args) {
		PairDice pairDice = new PairDice();
		System.out.println("주사위게임(2인용)");
		String playerNames[] = new String[2];
		int results[] = new int[2];
		Scanner scan = new Scanner(System.in);
		// 플레이어 이름 입력
		System.out.println("첫번째 플레이어 이름을 입력하세요:>>");
		playerNames[0] = scan.nextLine();
		System.out.println("두번째 플레이어 이름을 입력하세요:>>");
		playerNames[1] = scan.nextLine();

		int round = 0; // 대결 회차
		while (true) {
			System.out.printf("=====%d회차 대결=====%n", ++round);

			for (int i = 0; i < playerNames.length; i++) {
				pairDice.castTwoDices();
				System.out.printf("%s님이 주사위를 굴립니다:%n%s%n", playerNames[i], pairDice);
				results[i] = pairDice.getSum();
			} 
			
			// 둘 다 동시에 10 넘어감
			if (results[0] > 10 && results[1] > 10) {
				System.out.println("모두 패배. 재대결!");
			}
			
			// 둘 다 10 안넘어감
			else if (results[0] > 10) {
				System.out.println(playerNames[1] + "님의 승리입니다.");
				break;
			} else if (results[1] > 10) {
				System.out.println(playerNames[0] + "님의 승리입니다.");
				break;
			}

			// 둘이 다른 숫자
			else if (results[0] > results[1]) {
				System.out.println(playerNames[0] + "님의 승리입니다.");
				break;
			} else if (results[1] > results[0]) {
				System.out.println(playerNames[1] + "님의 승리입니다.");
				break;
			}
			else {
				System.out.println("무승부 재대결");
			}
		}
	}
}
