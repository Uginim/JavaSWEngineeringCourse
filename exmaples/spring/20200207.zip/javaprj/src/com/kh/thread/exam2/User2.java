package com.kh.thread.exam2;

public class User2 extends Thread{
	private  Calculator calculator;

	public void setCalculator(Calculator calculator) {
		this.setName("User2"); // 스레드 이름 변경
		this.calculator = calculator;
	}
	
	@Override
	public void run() {
		this.calculator.setMemory(50);
	}
}
