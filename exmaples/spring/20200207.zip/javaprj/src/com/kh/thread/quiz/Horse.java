package com.kh.thread.quiz;

public class Horse extends Thread {
	int number;		// 말 번호
	Rank rank;		// 순위
	static int cnt;
	final int METER = 100;  // 거리
	
	public Horse(int number, Rank rank) {
		this.number=number;
		this.rank=rank;
	}

	@Override
	public void run() {
		int remaining_distence = METER; // 남은 거리
		while (true) {
			try {
				Thread.sleep((int)(Math.random()*2000)+1);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			remaining_distence -=  10;
			if(remaining_distence == 0) {
				this.rank.finishLine(this.number);
				break;
			}
		}
	}

}
