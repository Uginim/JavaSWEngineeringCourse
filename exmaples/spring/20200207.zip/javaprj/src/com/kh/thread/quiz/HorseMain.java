package com.kh.thread.quiz;

public class HorseMain {
	public static void main(String[] args) {
		Thread horse = null;
		final int HORSE_COUNT = 10;
		
		for(int i=0; i<HORSE_COUNT ;i++) {
			horse = new Horse(i+1, new Rank());
			horse.start();
		}
	}
}
