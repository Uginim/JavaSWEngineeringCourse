package com.kh.thread.exam1;

// 1) Runnable 인터페이스를 구현
// 1-1) 이름있는 클래스
public class Task1 implements Runnable {

	@Override
	public void run() {
		for(int i=5;i<10;i++) {
			System.out.println(Thread.currentThread().getName() + " : "+i);
			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		System.out.println(Thread.currentThread().getName()+" 종료");
	}
}
