package com.kh.thread.exam2;

public class Calculator {
	private int memory;

	public int getMemory() {
		
		return memory;
	}
// 1) 메소드에 snchronized 사용
//	synchronized public void setMemory(int memory) {
	public void setMemory(int memory) {
// 2) snchronized 블록 사용
//		synchronized(this) {
			this.memory = memory;
			try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {
			
			}
			System.out.println(Thread.currentThread().getName() + ":"+this.memory);
//		}
	}
	
}
