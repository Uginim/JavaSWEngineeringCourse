package com.kh.operator;
/**
 * 2019.10.25 Java SW Engineering Course
 * 단일부호 연산자( +, - )
 * @author Hyeonuk
 */
public class TypeAutoExchangeExam {
	public static void main(String[] args) {
		byte num1 = 3;
		byte num2 = 5;
//		byte result = num1 + num2;
		int result = num1 + num2;		
		System.out.println("result = " + result);
		
		byte result2 = (byte)(num1 + num2);
		System.out.println("result2 = " + result2);
	}
}
