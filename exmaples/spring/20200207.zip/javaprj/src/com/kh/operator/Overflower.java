package com.kh.operator;
/**
 * 2019.10.25 Java SW Engineering Course
 * Overflow 연습
 * @author Hyeonuk
 */
public class Overflower {
	/** 
	 * @param num distinguished if it will overflowed 
	 * @return if num is 127 or -128 return true
	 */
	public static boolean isOverflow(byte num) {
		boolean result = false;
		if(num >= Byte.MAX_VALUE || num <= Byte.MIN_VALUE) {
			System.out.println("오버플로 발생 경고!");
			result = true;
		}
		return result;
	}
	public static void main(String[] args) {
		
		byte num = 125; // -128 ~ 127
		
		// 오버플로우 발생
		for(int i = 0 ; i < 5 ; i++) {			
			System.out.println("num = " + ++num);
		}		
		System.out.println("=-------------=");
		num = -125;
		for(int i = 0 ; i < 5 ; i++) {
			System.out.println("num = " + --num);
		}		
		System.out.println("=-------------=");
		num = 124;
		for(int i = 0 ; i < 5 ; i++) {			
			System.out.println("num = " + ++num);			
			if(isOverflow(num)) {				
				break;
			} 
		}
	}
}
