package com.kh.operator;
/**
 * 2019.10.25 Java SW Engineering Course
 * 단일부호 연산자( +, - )
 * @author Hyeonuk
 * @version 1.0
 * 
 */
public class SignOperatorExam {
	public static void main(String[] args) {
		int x = -100;
		int result1 = +x;
		int result2 = -x;
		System.out.println("result1 = " + result1);
		System.out.println("result2 = " + result2);
		
		short s = 100; // 2byte, 1byte == 8bit
//		short result3 = -s; // => Type Mismatch Error 
		/* 단일 부호 연산을 수행했음	
		 * int 보다 작은 타입의 연산의 결과는 int로 바뀜
		 * 아래와 같이 형변환을 해주어야함 
		 */
		short result3 = (short)-s;
	}
}
