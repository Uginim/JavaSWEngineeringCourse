package com.kh;

public class Hello {
	public static int sum(int n , int m) {
		return n + m;
	}
	// main() 메소드에서 실행 시작
	public static void main(String[] args) {
		int i = 20;
		int s;
		char a;
		
		s = sum(i,10);
		a = '?';
		System.out.println(a); // sum() 메소드 호출
		System.out.println("Hello"); // 문자 '?'화면출력 
		System.out.println(s); // 정수 s 값 화면 출력
	}
}
