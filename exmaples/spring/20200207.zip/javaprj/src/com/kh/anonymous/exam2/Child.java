package com.kh.anonymous.exam2;

public class Child extends Parent{
	public void method1() {
		System.out.println("이름 있는 클래스:method1()호출됨");
	}
}
