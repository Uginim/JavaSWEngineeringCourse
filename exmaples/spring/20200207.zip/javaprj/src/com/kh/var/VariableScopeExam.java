package com.kh.var;
/**
 * 변수의 생명 주기
 * 변수가 선언된 블럭{ } 내에서 생명주기를 갖는다.
 * @author Hyeonuk
 *
 */
public class VariableScopeExam {

	public static void main(String[] args) {
		int var1;
		
		if(true) {
			int var2;
			
			var1 = 10;
			var2 = 20;
		}
		
		var1 = 20;
//		var2 = 30; // Error: var2 cannot be resolved to a variable
		for( int i=0 ; i < 1 ; i++ ) {
			int var3;
			
			var1 = 10;
//			var2 = 15; // Error: i cannot be resolved to a variable
			var3 = 20;
		}
//		i = 10;// Error: i cannot be resolved to a variable
		var1 = 40;
		//var3 = 50;
		
//		for(int i=0; i<1; i++) {
//			for(int j=0; j<1; j++) {
//				
//			}
//		}
			int i, j;
			for(i=0;i<1;i++) {
				for(j=0;j<1;j++) {
					
				}
			}
		System.out.println("i="+i);
//		System.out.println("i="+j);
		
	}

}
