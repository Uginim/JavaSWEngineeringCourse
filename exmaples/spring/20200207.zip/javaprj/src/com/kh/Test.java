package com.kh;

import java.util.Arrays;

public class Test {
	int member;
	public void Test(int i) {
		this.member = i;
	}
	public static void main(String[] args) {
		long ten = 10;
		int minusNine = -9;
//		byte[] testArr = new byte[ten];
//		byte[] testArr = new byte[minusNine];
		
//		System.out.println("testArr.length" + testArr.length);
		for(int i=1;i<=1000;i++) { 
			System.out.print("i="+i+" ");
	    int tmp = i;			
	    boolean notThree = true;
	    do {
	        if(tmp%10%3==0 && tmp%10!=0) { // tmp%10이 3의 배수인지 확인(0 제외)
	            System.out.print("짝");
	            notThree = false;
	        }
	    } while((tmp/=10)!=0);  // tmp /= 10은 tmp = tmp / 10과 동일
	    if(notThree) {
	        System.out.printf("%d ", i);
	    }
	    System.out.println("!");
		}
		double constantE = 2.7182818;
//    double roundedE = (int)(constantE * 10000 + 0.5) / 10000.0;
    double roundedE = Math.round(constantE * 10000) / 10000.0;
		System.out.println(constantE+" " + roundedE);
		
		char upperCase = 'B';
		char lowerCase = (char) (upperCase-('A'-'a'));
		System.out.println(lowerCase);
		int[] myArr = { 1, 2, 3, 4, 5};
		System.out.println(myArr);
		System.out.println(Arrays.toString(myArr));
//		Test test = new Test(12);
	}
}
