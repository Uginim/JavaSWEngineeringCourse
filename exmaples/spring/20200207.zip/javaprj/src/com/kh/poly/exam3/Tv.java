package com.kh.poly.exam3;

public class Tv extends Product{
	

}
