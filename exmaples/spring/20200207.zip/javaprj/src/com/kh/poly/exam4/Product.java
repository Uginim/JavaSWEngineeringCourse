package com.kh.poly.exam4;

public class Product {
	int price; // 제품가격
	int bonusPoint; // 보너스점수
	public Product(int price) {
		this.price = price;
		this.bonusPoint = (int)(price/10.0);
	}
}
