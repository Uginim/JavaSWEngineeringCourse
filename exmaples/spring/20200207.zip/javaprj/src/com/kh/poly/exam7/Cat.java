package com.kh.poly.exam7;

public class Cat extends Animal {

	@Override
	void cry() {
		System.out.println("야옹!");
	}
	
}
