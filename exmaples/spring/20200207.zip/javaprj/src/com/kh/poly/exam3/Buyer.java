package com.kh.poly.exam3;

public class Buyer {

	int money = 1000;
	int bonusPoint = 0;
	Tv[] tv = new Tv[10];
	
	//오버로딩
	void buy(Tv tv) {
		System.out.println("tv 구매함");
		for(int i=0; i<this.tv.length; i++) {
			if(this.tv[i] !=null) {
				this.tv[i] = tv;
			}
		}
	}
	void buy(Computer computer) {
		System.out.println("computer 구매함");
		}
	void buy(Audio audio) {
		System.out.println("TV 구매함");
	}
	}
	

