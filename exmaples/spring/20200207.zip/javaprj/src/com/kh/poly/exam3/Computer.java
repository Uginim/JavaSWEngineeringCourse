package com.kh.poly.exam3;

public class Computer extends Product{

}
