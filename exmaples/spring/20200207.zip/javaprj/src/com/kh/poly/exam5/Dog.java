package com.kh.poly.exam5;

public class Dog extends Animal {
	@Override
	void cry() {
		System.out.println("멍멍!");
	}
}
