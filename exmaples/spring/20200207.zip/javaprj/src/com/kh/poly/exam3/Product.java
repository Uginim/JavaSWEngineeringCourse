package com.kh.poly.exam3;

public class Product {
int price; // 제품가격
int bonusPoint; //보너스점수
}
