package com.kh.poly.exam4;

public class Computer extends Product{

	public Computer() {
		super(100);
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Computer";
	}
	
}
