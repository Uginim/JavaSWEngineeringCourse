package com.kh.poly.exam7;

public class Pig extends Animal {
	@Override
	void cry() {
		System.out.println("꿀꿀!");
	}
}
