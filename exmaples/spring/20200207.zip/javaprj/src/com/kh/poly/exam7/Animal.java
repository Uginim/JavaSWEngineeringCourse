package com.kh.poly.exam7;

abstract public class Animal {
	int age;					// 나이
	String color;			// 색상
	
	abstract void cry();
}
