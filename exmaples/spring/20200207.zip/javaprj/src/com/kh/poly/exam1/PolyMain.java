package com.kh.poly.exam1;

public class PolyMain {
	public static void main(String[] args) {
		B b = new B();
		C c = new C();
		D d = new D();
		E e = new E();
		
		// 자동 형변환 : 부모타입 = 자식타입; (대입)
		// 전제조건 : 상속관계일 때만 성립 
		A a1 = b;
		A a2 = d;
		A a3 = c;
		A a4 = e;
		
		D b2 =d;
		C c2 = e;
		
		// 상속관계 아님
		// B b2 = e; // Type miss match
		
		// 강제 형변환 : 자식타입 = (자식타입)부모타입
		b = (B) a1;
		
	}
}
