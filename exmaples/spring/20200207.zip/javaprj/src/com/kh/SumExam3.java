package com.kh;
/**
 * 문제 2)  SumExam3
 * 1~100까지의 수를 읽어 	홀수면 홀수 출력
 * 짝수면 짝수 출력(if문 사용하기)
	1) for문
	2) while문
	3) do~while문	
 * @author Hyeonuk
 */

public class SumExam3 {
	public static void main(String[] args) {		
		System.out.println("for문 ");
		for(int i=1;i<=100;i++) {
			if(i%2==1)
				System.out.println(i+"=홀수");
			else 
				System.out.println(i+"=짝수");				
		}
		System.out.println("=================");
		System.out.println("while문 ");
		int i=1;
		while(i<=100) {
			if(i%2==1)
				System.out.println(i+"=홀수");
			else 
				System.out.println(i+"=짝수");
			i++;
		}
		System.out.println("=================");
		System.out.println("do while문 ");
		i=1;
		do {
			if(i%2==1)
				System.out.println(i+"=홀수");
			else 
				System.out.println(i+"=짝수");
			i++;
		} while(i<=100);
		System.out.println("=================");
	}
}
