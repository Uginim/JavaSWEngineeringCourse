package com.kh;

import java.util.Scanner;

/**
 * 2019.10.22 Java SW Engineering Course
 * 국어 영어 수학 점수 입력받아서 합계 평균 구하기  
 * @author Hyeonuk
 *
 */
public class Report {
	public static void main(String[] args) {
		int sum;
		Scanner scan = new Scanner(System.in);
//		String[] subjects = {"국어","영어","수학"};
//		for(int i=0 ; i<subjects.length ; i++) {
		while(true) {
			String input = scan.nextLine();
//			if()
		}
	}
}
