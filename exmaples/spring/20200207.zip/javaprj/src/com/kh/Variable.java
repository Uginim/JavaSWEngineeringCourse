package com.kh;
/**
 * 2019.10.21 Java SW Engineering Course
 * Variable example  
 * @author Hyeonuk
 *
 */
public class Variable {

	public static void main(String[] args) {
		char charCharacter = 'A';
		char charDecimal = 65; // "'A' character value" is equal to "65 Decimal value";
		char charUnicode = '\u0041';
		
		System.out.println(charCharacter);
		System.out.println(charDecimal);
		System.out.println(charUnicode);
		
		char charHangulJaum = 'ㄱ';
		char charUnicodeHangul = '\u1100';
		
		System.out.println(charHangulJaum);
		System.out.println(charUnicodeHangul);
		
		byte byteDecimal = 127;
		System.out.println(byteDecimal);
//		byte byteDecimal2 = 128; // Type mismatch Error: cannot convert from int to byte
		
	}

}
