package com.kh;
/**
 * 2019.10.21 Java code example
 * @author Hyeonuk 
 * @version 0.0.1
 * 
 */
public class HelloDoc {
	/**
	 * Sum two input numbers
	 * @param i First integer argument for summing two integer numbers 
	 * @param j Second integer argument for summing two integer numbers
	 * @return Sum of the inputed two number 
	 */
	public static int sum(int i, int j) { // Define a method
		return i + j;
	}
	public static void main(String[] args) {
		int i; int j; // Declare integer variables
		
		char a; // Declare a character variable
		String b; // Declare a string variable
		
		final int TEN = 10; // Declare a constant variable and Initialize a value
//		TEN = 20; // ERROR
		
		i = 1; // until semicolon 
		j = sum(i,TEN); // Call a method
		
		a = '?';
		b = "Hello";
		
		System.out.println(a);
		System.out.println(b);
		System.out.println(TEN);
		System.out.println(j);
	}

}
