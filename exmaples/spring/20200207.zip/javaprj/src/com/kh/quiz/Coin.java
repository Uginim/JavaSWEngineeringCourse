package com.kh.quiz;

public class Coin {
	// 멤버 필드
	// 앞면, 뒷면
	final static int FRONT_SIDE=1;
	final static int BACK_SIDE=0;
	
	// 현재 면
	private int currentSide = FRONT_SIDE;
	
	// 동전을 던진다.(랜덤함수이용)
	public void throwCoin() {
		 currentSide = (int) (Math.random() * 2);
	}
	
	// 동전의 현재면 반환
	public int getCurrentSide() {
		return currentSide; 
	}
	
	// 동전의 현재면을 문자열로 반환 
	public String getCurrentSideString() {
		return (currentSide == FRONT_SIDE)? "앞면" : "뒷면";
	}
	// 동전의 현재면을 문자열로 반환 
	public static String changeToString(int curSide) {
		return (curSide == FRONT_SIDE)? "앞면" : "뒷면";
	}
}
