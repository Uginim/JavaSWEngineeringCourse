package com.kh.inter;

public class Computer implements SmartRemoteControl {

	@Override
	public void turnOn() {
		// TODO Auto-generated method stub

	}

	@Override
	public void turnOff() {
		// TODO Auto-generated method stub

	}

	@Override
	public void setVolume(int volume) {
		// TODO Auto-generated method stub

	}

	@Override
	public void search(String url) {
		// TODO Auto-generated method stub

	}

}
