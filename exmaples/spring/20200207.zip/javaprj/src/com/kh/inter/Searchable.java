package com.kh.inter;

public interface Searchable {
	void search(String url);
}
