package com.kh.object.exam2;

public class CarMain {

	public static void main(String[] args) {
		Car car = new Car();
		car.maker = "아우디";
		car.cc ="1960cc";
		car.color ="Red";
		car.run(100);
		car.onRadio();
		car.stop();
		

	}

}
