package com.kh.object.exam8;

public class VarArgsExMain {
	public static void main(String[] args) {
		VarArgsEx var = new VarArgsEx();
		var.printStr("홍길동");
		var.printStr("홍길동","홍길서");
		var.printStr("홍길동","홍길서","홍길남");
		System.out.println("------------------");
		var.printStr2(new String[] {"홍길동"});
		var.printStr2(new String[] {"홍길동","홍길서"});
		var.printStr2(new String[] {"홍길동","홍길서","홍길남"});
	}
}
