package com.kh.object.exam3;

public class Person2 {
	// 맴버 필드
	// 	: 프로그래머가 초기값을 지정해주지 않으면 타입별로 디폴트값으로 초기화됨
	String name; 						// 이름
	private int age;				// 나이
	
	// 디폴트 생성자
	// 생성자 오버로딩 : 동일이름의 생성자를 여러개 선언 가능
  //										단, 매개변수는 달라야한다. 
	public Person2() {
		System.out.println("디폴트생성자 호출됨!");
	}
	
	public Person2(String name) {		
		// this : 자기자신을 가리킨다.
		this.name = name;		
	}
	
	public Person2(String name, int age) {		
//		this.name = name;
		// this() ; 자신의 생성자 호출, 반드 첫문장에 사용해야함 	
		this(name);
		this.setAge(age);
	}
	// 맴버 메소드
	public void smile() {
		System.out.println(this.name+"(이)가 웃다");
	}

	public void setAge(int age) {
		if( age < 1 ||  age > 150) {
			System.out.println("잘못된 입력값입니다.");
			return ; // 메소드 실행을중지하고 제어를 호출한 곳으로 넘긴다.
		} else {
			this.age = age;
		}
		
	}
	
	public int getAge() {
		return this.age;
	}
}
