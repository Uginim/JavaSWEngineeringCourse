package com.kh.object.exam7;

import java.lang.*;

public class Calculator extends Object {
	// 멤버 필드
	static String maker;				// 제조사
	
	int countCalculator;
	private static int countCalculator2;
	
	// 생성자
	public Calculator() {
		super();
		countCalculator++;
		countCalculator2++;
		System.out.println("생성자 호출됨!!");
	}

	// 멤버메소드가 정적멤버를 처리할때는 반드시 정적 메소드로 처리한다
	public static int getCountCalculator2() {		
		return countCalculator2;
	}
}
