package com.kh.object.exam5;

public class CarMain {
	public static void main(String[] args) {
		Car car1 = new Car();
		System.out.println(car1);
		car1.setColor("156");
		car1.setColor("빨간색");
		Car car2 = new Car("아우디","1980cc","흰색");	
		System.out.println(car2);
		car2.run();
		car2.stop();		
	}
}
