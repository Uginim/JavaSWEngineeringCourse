package com.kh.object.exam3;

public class PersonMain2 {
	
	public static void main(String[] args) {
		Person2 p1 = new Person2();
		System.out.println(p1);
		
		p1.name = "홍길동";
		System.out.println(p1.name);
		p1.name = "홍길순";
		System.out.println(p1.name);
		
		System.out.println("-----------------------");
		Person2 p2 = new Person2("홍길남");
		System.out.println(p2.name);
		p2.smile();
		
		System.out.println("-----------------------");
		Person2 p3 = new Person2("홍길북");
		System.out.println(p3.name);
		p3.smile();

		// case1)
		System.out.println("-----------------------");
		Person2 p4 = new Person2();
		p4.name = "홍길서";
		// p4.age = 30; // private 맴버 접근 불가
		p4.smile();
		
		// case2)
		System.out.println("-----------------------");
		Person2 p5 = new Person2("홍길서");
		p5.setAge(30);		
		p5.smile();
		
		// case3)
		System.out.println("-----------------------");
		Person2 p6 = new Person2("홍길서", 30);
		p5.setAge(30);			
		System.out.println(p6.getAge());
		
		int num =0;
		System.out.println(num);
		
	}
}
