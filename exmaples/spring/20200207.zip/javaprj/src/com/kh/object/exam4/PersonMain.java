package com.kh.object.exam4;

public class PersonMain {
	public static void main(String[] args) {
		
		Person p1 = new Person();
		//println() 매개값이 참조변수면 내부적으로 Object.toString() 호출
		System.out.println(p1);
		System.out.println(p1.toString());
		
		System.out.println("----------------");
		Person p2 = new Person("홍길동",30);
		System.out.println(p2);
		System.out.println(p2.toString());
	}
}
