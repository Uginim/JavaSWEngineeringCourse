package com.kh.exception.exam2;

public class MultiCatchEx {

	public static void main(String[] args) {
		try {

			String data1 = args[0];
			String data2 = args[1];

			int value1 = Integer.parseInt(data1);
			int value2 = Integer.parseInt(data2);

			int result = value1 + value2;

			System.out.printf("%s + %s = %d %n", data1, data2, result);
		} catch(ArrayIndexOutOfBoundsException | NumberFormatException e) {
			System.out.println("예외발생_2");
//		} catch (NumberFormatException e) {
//			System.out.println("예외발생_3");
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			System.out.println("예외발생_1");
		}

	}

}
