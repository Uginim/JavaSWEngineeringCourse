package com.kh;
/**
 * 문제 2) SumExam2
	1~100까지의 짝수 합구하기
	1) for문
	2) while문
	3) do~while문	
 * @author Hyeonuk
 */
public class SumExam2 {
	public static void main(String[] args) {
		int sum=0;
		System.out.println("for문 ");
		for(int i=1;i<=100;i++) {
			if(i%2==0)
				sum+=i;
		}
		System.out.println("sum="+sum);
		System.out.println("=================");
		
		
		System.out.println("while문 ");
		int i=1;sum=0;
		while(i<=100) {
			if(i%2==0)
				sum+=i;
			i++;
		}
		System.out.println("sum="+sum);
		System.out.println("=================");
		
		
		System.out.println("do while문 ");
		i=0;sum=0;
		do {
			if(i%2==0)
				sum+=i;
			i++;
		} while(i<=100);
		System.out.println("sum="+sum);
		System.out.println("=================");
	}
}
