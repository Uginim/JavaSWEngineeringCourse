import java.io.BufferedInputStream;
import java.util.HashSet;
import java.util.Map.Entry;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeMap;

class PosterBoundary{
 
	long rightSide = -1; // 오른쪽 경계의 포스터 넘버. 없으면 -1 
	long leftSide = -1; // 왼쪽 경계의 포스터 넘버.
}
public class Main {
	public static void main(String[] args) {
		Scanner sc = new Scanner(new BufferedInputStream(System.in));
		TreeMap<Long,PosterBoundary> boundaries= new TreeMap<Long, PosterBoundary>();
		int numPosters = sc.nextInt();
		// 포스터 붙이기(및 경계선 정리)
		for(int i=0;i<numPosters;i++) {
			long leftOfNewPoster= sc.nextLong();
			long rightOfNewPoster= sc.nextLong();			
			PosterBoundary leftBoundary = boundaries.get(leftOfNewPoster); // 왼쪽 경계
			PosterBoundary rightBoundary = boundaries.get(rightOfNewPoster); // 오른쪽 경계
			// 각 경계에 포스터 번호 남기기
			// 왼쪽 경계
			if(leftBoundary!=null) {		// 경계가 존재할 경우		
				leftBoundary.rightSide=i;
			}else {
				PosterBoundary boundary= new PosterBoundary();
				boundary.rightSide = i;
				// 붙이기 전 왼쪽편에 붙었던 포스터
				boundaries.put(leftOfNewPoster, boundary);
				Entry<Long, PosterBoundary> leftSidePosterOfBoundary = boundaries.floorEntry(leftOfNewPoster-1);
				if(leftSidePosterOfBoundary!=null) {
					boundary.leftSide=	leftSidePosterOfBoundary.getValue().rightSide;
				}
			}
			// 오른쪽 경계
			if(rightBoundary!=null) {
				rightBoundary.leftSide=i;
			}else {
				PosterBoundary boundary= new PosterBoundary();
				boundary.leftSide = i;
				// 붙이기 전 오른쪽편에 붙었던 포스터
				boundaries.put(rightOfNewPoster, boundary);
				Entry<Long, PosterBoundary> rightSidePosterOfBoundary = boundaries.ceilingEntry(rightOfNewPoster+1);
				if(rightSidePosterOfBoundary!=null) {
					boundary.rightSide=	rightSidePosterOfBoundary.getValue().leftSide;
				}
			}	
			// 새로 붙여질 포스터 범위의 경계 삭제
			long nextKey = boundaries.ceilingKey(leftOfNewPoster+1);
			while(nextKey!=rightOfNewPoster) {
				long removeTarget = nextKey;
				nextKey = boundaries.ceilingKey(nextKey+1);
				boundaries.remove(removeTarget);
			}
			
		}
		
		// 포스터 개수 셈하기		
		Set<Long> posterSet = new HashSet<Long>();
		Set<Long> keySet = boundaries.keySet();
		for(Long key : keySet) {
			PosterBoundary pb = boundaries.get(key);
			System.out.println("key:"+key+" leftSide:"+pb.leftSide+" rightSide:"+pb.rightSide);
			posterSet.add(pb.leftSide);
			posterSet.add(pb.rightSide);		
		}
		posterSet.remove(new Long(-1));
		System.out.println(posterSet.size());
	}
}
