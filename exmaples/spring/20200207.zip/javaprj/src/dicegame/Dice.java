package dicegame;

public class Dice {

	int[] dice = new int[2];
	{
	for(int i=0; i<dice.length; i++) {
		dice[i] = (int)(Math.random()*6+1);
	}
	}
}
	
