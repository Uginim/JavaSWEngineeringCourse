package com.kh.portfolio.controller;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;


@Controller
public class TestController2 {

	private static final Logger logger = LoggerFactory.getLogger(TestController2.class);

	@RequestMapping("/test/t1")
	public String t1(HttpServletRequest request) {
		String name = request.getParameter("name");
		String age = request.getParameter("age");
		logger.info("이름: " + name);
		logger.info("나이: " + age);
		return "test";
	}

	// 어노테이션을 쓰면 타입이 자동 변환됨
	@RequestMapping("/test/t2")
	public String t2(@RequestParam String name, @RequestParam int age) {
		logger.info("이름: " + name);
		logger.info("나이: " + age);
		return "test";
	}

	@RequestMapping("/test/t3")
	public String t3(@RequestParam("name") String myName, @RequestParam("age") int myAge) {
		logger.info("이름: " + myName);
		logger.info("나이: " + myAge);
		return "test";
	}

	@RequestMapping("/test/t4")
	public String t4(@RequestParam Map<String, String> map) {
		logger.info("이름: " + map.get("name"));
		logger.info("나이: " + map.get("age"));
		return "test";
	}
	
	@GetMapping("/test/t5")
	public String t5(Person person) {
		logger.info(person.toString());
		return "test";
	}
	
	@GetMapping("/test/t6")
	public String t6(Person person, Model model) {
		logger.info(person.toString());
		Map<String,Object> map = model.asMap();
		for(String key : map.keySet()) {
			logger.info(key + " : " + map.get(key).toString());
		}
		return "test";
	}
	
	@GetMapping("/test/t7")
	public String t7(@ModelAttribute("per") Person person, Model model) {
		logger.info(person.toString());
		Map<String,Object> map = model.asMap();
		for(String key : map.keySet()) {
			logger.info(key + " : " + map.get(key).toString());
		}
		return "test";
	}
	
	
	// 입력 양식(test2) : 이름, 나이
	@GetMapping("/test/t9")
	public String testForm() {
		return "test/testForm";
	}
	// 입력 처리
	@PostMapping("/test/t10")
	public String t10(@ModelAttribute("per") Person person, Model model) {
		logger.info(person.toString());
		Map<String,Object> map = model.asMap();
		for(String key : map.keySet()) {
			logger.info(key + " : " + map.get(key).toString());	
		}
//		model.addAttribute("person",person);
		return "test3";
	}
	
	@PostMapping("/test/t11")
	public String t11(
			@ModelAttribute("per") Person person,// 양식(폼)하고 바인딩 객체를 매핑함
			BindingResult result,
			Model model) {
		logger.info(person.toString());
		if(result.hasErrors()) {return "test4";}
		Map<String,Object> map = model.asMap();
		for(String key :map.keySet()) {
			logger.info(key + " : " + map.get(key).toString());			
		}
//		model.addAttribute("person",person);
		return "test2";
	}
}
