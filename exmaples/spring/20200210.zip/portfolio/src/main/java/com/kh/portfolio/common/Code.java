package com.kh.portfolio.common;

import lombok.Data;

@Data
public class Code {
	private String code; // 코드 값
	private String label; // 라벨 명
	
	public Code(String code, String label) {	
		this.code = code;
		this.label = label;
	}
	
	
}
