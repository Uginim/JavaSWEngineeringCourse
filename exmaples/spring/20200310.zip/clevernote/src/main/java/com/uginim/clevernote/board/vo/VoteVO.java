package com.uginim.clevernote.board.vo;

public class VoteVO {

}
