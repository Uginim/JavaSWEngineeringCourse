package com.kh.portfolio.controller;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.kh.portfolio.common.Code;
import com.kh.portfolio.member.svc.MemberSVC;
import com.kh.portfolio.member.vo.MemberVO;

@Controller
@RequestMapping("/member")
public class MemberController {
	private static final Logger logger = LoggerFactory.getLogger(MemberController.class);
	
	@Inject
	MemberSVC memberSVC;
	
	@ModelAttribute
	public void initData(Model model) {
		// 지역
		List<Code> region = new ArrayList<>();
//		region.add(new Code("","==선택하세요=="));
		region.add(new Code("서울","서울"));
		region.add(new Code("대전","대전"));
		region.add(new Code("대구","대구"));
		region.add(new Code("부산","부산"));
		region.add(new Code("찍고","찍고"));
		region.add(new Code("울산","울산"));
		model.addAttribute("region",region);
		
		
		// 성별
		List<Code> gender = new ArrayList<>();
		gender.add(new Code("남","남자"));
		gender.add(new Code("여","여자"));
		model.addAttribute("gender",gender);
	}
	
	
	// 회원가입양식
	@RequestMapping("/joinForm")
	public String memberJoinForm(Model model) {
		model.addAttribute("mvo",new MemberVO());
		return "member/joinForm";
	}
	
	// 회원등록
	@RequestMapping("/join")
	public String memberJoin(
			@Valid @ModelAttribute("mvo") MemberVO memberVO,
			BindingResult result,
			Model model) {
		logger.info(memberVO.toString());
		logger.info("join");
		
		// 1) 유효성 오류체크 중 오류가 발견되면 회원 가입 페이지로 이동
		if(result.hasErrors()) {
			logger.info(result.getAllErrors().toString());
			return "member/joinForm";
			
		}
		// 2) 회원 중복체크
		if(memberSVC.selectMember(memberVO.getId())!=null) {
			model.addAttribute("svr_msg", "중복된 아이디");
			logger.info("id중복");
			return "member/joinForm";
		}
		// 3) 회원 가입처리				 
		int cnt = memberSVC.joinMember(memberVO); // result 값이 1일경우: 정상적인 결과
		if(cnt==1) {
			return "member/signin";
		}else {			
			return "redirect:/";
		}
	}
	
	@RequestMapping("/test")
	public void test(@RequestParam("name") String name, @RequestParam("age") String age) {
		logger.info("name: "+ name);
		logger.info("age: "+ age);
	}
}
