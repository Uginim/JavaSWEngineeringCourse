package com.kh.portfolio.board;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.List;

import javax.inject.Inject;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.kh.portfolio.board.dao.BoardDAO;
import com.kh.portfolio.board.vo.BoardFileVO;
import com.kh.portfolio.board.vo.BoardVO;
import com.kh.portfolio.common.RecordCriteria;
@ExtendWith(SpringExtension.class)
@ContextConfiguration(locations = "file:src/main/webapp/WEB-INF/spring/root-context.xml")
public class BoardDAOImplXMLTest {
	Logger logger = LoggerFactory.getLogger(BoardDAOImplXMLTest.class);
	
	@Inject
	BoardDAO boardDAO;
	
	@Test
	public void getBoardList() {
		List<BoardVO> list = boardDAO.list();
		logger.info(""+list.size());
		assertNotNull(list);
//		logger.info(list.toString());
		
	}
	void printList(List<BoardVO> list){
		int cnt = 0;
		for(BoardVO board: list) {
			logger.info("listItem("+ ++cnt + "):"+board.toString());
		}
	}
	
	@Test
	public void getBoardListByKeword() {
		int reqPage = 1;
		RecordCriteria recordCriteria = new RecordCriteria(reqPage);
		List<BoardVO> list;
		logger.info("TC");
		list= boardDAO.list(recordCriteria.getStartRec(), recordCriteria.getEndRec(), "12", "TC");
		printList(list);
		logger.info("T");
		list = boardDAO.list(recordCriteria.getStartRec(), recordCriteria.getEndRec(), "12", "T");
		printList(list);
		logger.info("C");
		list = boardDAO.list(recordCriteria.getStartRec(), recordCriteria.getEndRec(), "12", "C");
		printList(list);
		logger.info("N");
		list = boardDAO.list(recordCriteria.getStartRec(), recordCriteria.getEndRec(), "12", "N");
		printList(list);
		logger.info("I");
		list = boardDAO.list(recordCriteria.getStartRec(), recordCriteria.getEndRec(), "12", "I");
		printList(list);
		
	}
	@Test
	public void getFile() {
		
		List<BoardFileVO> list = boardDAO.fileViews("29");
		logger.info(list.toString());
	}
	
	
}
