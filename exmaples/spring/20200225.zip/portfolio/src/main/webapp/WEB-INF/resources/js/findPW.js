window.addEventListener("load", init, false);
var isCheckedAccount = false;
function init() {

	var findAccountBtn = document.getElementById("findAccountBtn");

	findAccountBtn.addEventListener("click", function(e) {
		e.preventDefault();
		if (!isCheckedAccount) {
			var result = checkFindID();
			if (result) {
				accountCheck();
			}
		} else {
			var result = checkPW();
			if(result){
				changePW();
			}
		}

	}, false);
}

function accountCheck() {
	var xhr = new XMLHttpRequest();
	xhr.addEventListener("readystatechange", ajaxCall, false);
	function ajaxCall() {
		if (this.readyState == 4 && this.status == 200) {

			document.getElementById("idMsg").innerHTML = "";
			document.getElementById("telMsg").innerHTML = "";
			document.getElementById("birthMsg").innerHTML = "";

			console.log(this.responseText);
			var jsonObj = JSON.parse(this.responseText);
			if (jsonObj.success === true) {
//			if (this.responseText !== null) {
				document.getElementById("id").setAttribute("readonly",
						"readonly");
				document.getElementById("tel").setAttribute("readonly",
						"readonly");
				document.getElementById("birth").setAttribute("readonly",
						"readonly");
				document.querySelector('.pwSet').classList.remove('hidden');
				document.getElementById("findAccountBtn").value="비밀번호변경";
				isCheckedAccount = true;
			} else {
				console.log(jsonObj);
				document.getElementById("birthMsg").innerHTML = "해당 계정이 엄서영";
			}
		}
	}

	// 3) 서비스 요청
	var sendData = {};
	sendData.tel = document.getElementById("tel").value;
	sendData.birth = document.getElementById("birth").value;
	sendData.id = document.getElementById("id").value;

	// 자바스크립트 obj => json포맷 문자열 반환
	var result = JSON.stringify(sendData);

	// POST 방식
	xhr.open("POST", '/portfolio/member/findPW', true);
//	xhr.open("POST", '/portfolio/member/id/'+sendData.tel+'/'+sendData.birth, true);
//	xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");//
	xhr.setRequestHeader("Content-Type", "application/json;charset=utf-8");
//	xhr.send("result=" + result);
	console.log(result);
	xhr.send(result);	
//	xhr.send();
	

}
function changePW(){
	var xhr = new XMLHttpRequest();
	xhr.addEventListener("readystatechange", afterChangeReq, false);
	var sendData = {};
	sendData.pw= document.getElementById("pw").value;
	sendData.id= document.getElementById("id").value;

	// 자바스크립트 obj => json포맷 문자열 반환
	var result = JSON.stringify(sendData);
	// POST 방식
	xhr.open("POST", '/portfolio/member/changePW', true);
//	xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded")
	xhr.setRequestHeader("Content-Type", "application/json;charset=utf-8");	
//	xhr.send("result=" + result);
	xhr.send(result);
}
function afterChangeReq(e){
	if (this.readyState == 4 && this.status == 200) {
		document.getElementById("idMsg").innerHTML = "";
		document.getElementById("telMsg").innerHTML = "";
		document.getElementById("birthMsg").innerHTML = "";
		document.getElementById("pwMsg").innerHTML = "";
		document.getElementById("pwChkMsg").innerHTML = "";

		console.log(this.responseText);
		var jsonObj = JSON.parse(this.responseText);
//		if (jsonObj.error == null) {
		if(jsonObj.success == true){
			window.location = "/portfolio/loginForm";
			window.location = getContextPath()+"/loginForm";
		} else {			
//			document.getElementById("pwChkMsg").innerHTML = jsonObj.error;
			document.getElementById("pwChkMsg").innerHTML = "변경실패~!";
		}
	}
}
function checkFindID() {
	var telTag = document.getElementById("tel");
	var telValue = telTag.value
	var birthTag = document.getElementById("birth");
	var birthValue = birthTag.value;

	var flag = true;

	// 1) 전화번호 체크
	if (telValue.trim().length == 0) {
		telMsg.innerHTML = "전화번호를 입력하세요!";
		telMsg.classList.add("errmsg");
		telTag.focus();
		flag = false;
	}
	// 2) 생년월일 체크
	if (birthValue.trim().length == 0) {
		telMsg.innerHTML = "";
		birthMsg.innerHTML = "생년월일을 입력하세요!";
		birthMsg.classList.add("errmsg");
		birthTag.focus();
		flag = false;
	}
	return flag;

}
function checkPW() {
	var pwElement = document.getElementById('pw');
	var pwChkElement = document.getElementById('pwChk');
	var pwErrmsg = document.getElementById('pwChkMsg');  
	var flag = true;
	if (!isPassword(pwElement.value)) {
		pwErrmsg.innerHTML = "*비밀번호 형식이 맞지 않습니다.";
		flag = false;
	} else if (pwElement.value !== pwChkElement.value) {
		pwErrmsg.innerHTML = "*입력한 비밀번호가 일치하지 않습니다.";
		flag = false;
	}
	return flag;
}
// 비밀번호 체크
function isPassword(asValue) {
	var regExp = /^(?=.*\d)(?=.*[a-zA-Z])[0-9a-zA-Z]{8,10}$/; // 8 ~ 10자 영문,
																// 숫자 조합
	return regExp.test(asValue); // 형식에 맞는 경우 true 리턴
}