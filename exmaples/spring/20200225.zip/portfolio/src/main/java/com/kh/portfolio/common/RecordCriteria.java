package com.kh.portfolio.common;

import org.springframework.stereotype.Component;

/*
 * 페이징에서 요청페이지를 입력받아 시작레코드와 종료레코드를 구하는 클래스
 */
@Component
public class RecordCriteria {
	private int reqPage; // 요청페이지
	private int numPerPage =10; // 한 페이지에 보여줄 레코드 수
	
	private final int NUM_PER_PAGE = 10; // 한 페이지에서 보여줄 레코드 수
	public RecordCriteria() {
		super();
	}
	
	public int getReqPage() {
		return reqPage;
	}

	public void setReqPage(int reqPage) {
		this.reqPage = reqPage;
	}

	public int getNumPerPage() {
		return numPerPage;
	}

	public void setNumPerPage(int numPerPage) {
		this.numPerPage = numPerPage;
	}

	public RecordCriteria(int reqPage) {
		super();
		this.reqPage = reqPage;
		this.numPerPage = NUM_PER_PAGE ;
	}

	public RecordCriteria(int reqPage, int numPerPage) {
		super();
		this.reqPage = reqPage;
		this.numPerPage = numPerPage;
	}
	
	// 시작 레코드
	// (요청페이지 -1) * 한페이지에보여줄 레코드수 + 1
	public long getStartRec() {
		return (this.reqPage - 1) * this.numPerPage +1;
	}
	
	// 종료레코드
	// 요청페이지 * 한페이지에 보여줄 레코드 수
	public long getEndRec() {
		return this.reqPage * this.numPerPage;
	}

	@Override
	public String toString() {
		return "RecordCriteria [reqPage=" + reqPage + ", numPerPage=" + numPerPage + ", NUM_PER_PAGE=" + NUM_PER_PAGE + "]";
	}	
	
}
