package com.kh.portfolio.board.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.mybatis.spring.SqlSessionTemplate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.kh.portfolio.board.vo.BoardCategoryVO;
import com.kh.portfolio.board.vo.BoardFileVO;
import com.kh.portfolio.board.vo.BoardVO;

@Repository
public class BoardDAOImplXML implements BoardDAO {
	public static final Logger logger = LoggerFactory.getLogger(BoardDAOImplXML.class); 
	@Inject
	SqlSessionTemplate sqlSession;
	
	// 카데고리 읽어오기
	@Override
	public List<BoardCategoryVO> getCategory() {
		return sqlSession.selectList("mappers.BoardDAO-mapper.getCategory");		 
	}

	// 게시글 작성
	@Override
	public int write(BoardVO boardVO) {
		return sqlSession.insert("mappers.BoardDAO-mapper.write",boardVO);		
	}

	@Override
	public int fileWrite(BoardFileVO fileVO) {
		return sqlSession.insert("mappers.BoardDAO-mapper.fileWrite",fileVO);		 
	}

	// 게시글 수정
	@Override
	public int modify(BoardVO boardVO) {
		return sqlSession.update("mappers.BoardDAO-mapper.modify",boardVO);
		
	}

	
	// 게시글 삭제
	@Override
	public int delete(String bnum) {
		return sqlSession.delete("mappers.BoardDAO-mapper.delete",Long.valueOf(bnum));
		
	}

	
	// 첨부파일 1건 삭제
	@Override
	public int fileDelete(String fid) {
		return sqlSession.delete("mappers.BoardDAO-mapper.fileDelete",Long.valueOf(fid));
		
	}
	
	// 게시글 첨부파일 전체 삭제
	@Override
	public int filesDelete(String bnum) {
		return sqlSession.delete("mappers.BoardDAO-mapper.filesDelete",Long.valueOf(bnum));
	}

	// 게시글 보기
	@Override
	public BoardVO view(String bnum) {
		return sqlSession.selectOne("mappers.BoardDAO-mapper.view",Long.valueOf(bnum));
		
	}

	@Override
	public List<BoardFileVO> fileViews(String bnum) {
		return sqlSession.selectList("mappers.BoardDAO-mapper.fileViews",Long.valueOf(bnum));
	}
	@Override
	public int updateHit(String bnum) {		
		return sqlSession.update("mappers.BoardDAO-mapper.updateHit",Long.valueOf(bnum));
	}

	// 게시글 목록
	// 1) 전체
	@Override
	public List<BoardVO> list() {
		return sqlSession.selectList("mappers.BoardDAO-mapper.list");
	}

	
	
	
	// 2) 검색어 없는 게시글 페이징
	@Override
	public List<BoardVO> list(long startRec, long endRec) {
		Map<String,Object> map = new HashMap<>();
		map.put("startRec",startRec);
		map.put("endRec",endRec);
		return sqlSession.selectList("mappers.BoardDAO-mapper.search",map);
		
	}
	
	// 3) 검색어 잇는 게시글 검색(전체,작성자id, 별칭, 제목, 내용)
	@Override
	public List<BoardVO> list(long startRec, long endRec, String searchType, String keyword) {
		Map<String,Object> map = new HashMap<>();
		map.put("startRec",startRec);
		map.put("endRec",endRec);
		map.put("keyword",keyword);
		map.put("searchType",searchType);
		logger.info(map.toString());
//		return sqlSession.selectList("mappers.BoardDAO-mapper.list3_teacher",map);
		return sqlSession.selectList("mappers.BoardDAO-mapper.search",map);
	}

	// 게시글답글 작성
	@Transactional
	@Override
	public int reply(BoardVO boardVO) {
		// 1) 이전답글 STEP업데이트
		updateStep(boardVO.getBgroup(),boardVO.getBstep());
		return sqlSession.insert("mappers.BoardDAO-mapper.reply",boardVO);
	}	
	// 이전 답글 step 업데이트
	private int updateStep(int bgroup, int bstep) {
		Map<String,Object> map = new HashMap();
		map.put("bgroup",bgroup);
		map.put("bstep",bstep);
		return sqlSession.insert("mappers.BoardDAO-mapper.updateStep",map);
	}

	// 첨부파일 조회
	@Override
	public BoardFileVO fileView(String fid) {
		return sqlSession.selectOne("mappers.BoardDAO-mapper.fileView",Long.valueOf(fid));
	}



}
