package com.kh.portfolio.common;
/*
 * 현재 페이지에 보여줄 페이지 계산
 * (시작페이지, 종료페이지, 다음, 이전, 마지막페이지 이동, 처음페이지 이동)
 */
/**
 * @author Administrator
 *
 */
public class PageCriteria {

	private int pageNumPerPage; // 한 페이지에 보여줄 페이지 수
	private int startPage; 	// 한 페이지의 시작페이지
	private int endPage; // 한 페이지의 종료페이지
	
	private int totalRec;
	private int finalEndPage;
	
	private boolean prev;
	private boolean next;
	
	private RecordCriteria rc;
	
	private final int PAGE_NUM_PER_PAGE = 10;
	
	public PageCriteria() {
		this.pageNumPerPage = PAGE_NUM_PER_PAGE; 
	}
	
	protected PageCriteria(int totalRec, RecordCriteria rc) {
		super();
		this.totalRec = totalRec;
		this.rc = rc;
	}

	public PageCriteria(int pageNumPerPage, int totalRec, RecordCriteria rc) {	
		this.pageNumPerPage = pageNumPerPage;
		this.totalRec = totalRec;
		this.rc = rc;
	}
	
	// 요청페이지의 종료페이지 계산: 한페이지의 종료페이지 - 한페이지에 보여줄 페이지 수 + 1
	public int getStartPage() {
		return this.getEndPage() - this.pageNumPerPage + 1;
	}
	// 요청페이지의 종료페이지 계산: 올림(요청페이지/한페이지에 보여줄 페이지수)*한페이지에 보여줄 페이지수
	public int getEndPage() {
		return (int)Math.ceil((this.rc.getReqPage() / this.pageNumPerPage)) * this.pageNumPerPage;
	}
	// 최종페이지 계산 : 올림(전체레코드수/한페이지에 보여줄 페이지수)
	public int getFinalEndPage() {
		return totalRec/this.pageNumPerPage;
	}
	
	// 이전 페이지 보여줄지 판단 : 시작페이지가 1이 아닌경우
	public boolean isPrev() {
		return this.getStartPage() == 1 ? false : true;
	}
	
	// 다음 페이지 보여줄지 판단 : 전체 레코드수가 요청페이지의 종료페이지보다 큰 경우 보여줌.
	public boolean isNext() {
		return this.totalRec > this.getEndPage() * this.pageNumPerPage ? true : false;
	}
	
	@Override
	public String toString() {
		return "PageCriteria [pageNumPerPage=" + pageNumPerPage + ", startPage=" + startPage + ", endPage=" + endPage
				+ ", totalRec=" + totalRec + ", finalEndPage=" + finalEndPage + ", prev=" + prev + ", next=" + next + ", rc="
				+ rc + ", PAGE_NUM_PER_PAGE=" + PAGE_NUM_PER_PAGE + "]";
	}
	
	
}
