package com.kh.portfolio.member.controller;

import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.kh.portfolio.common.Code;
import com.kh.portfolio.member.svc.MemberSVC;
import com.kh.portfolio.member.vo.MemberVO;

@Controller
@RequestMapping("/member")
public class MemberController {
	private static final Logger logger = LoggerFactory.getLogger(MemberController.class);

	@Inject
	MemberSVC memberSVC;

	@ModelAttribute
	public void initData(Model model) {
		// 지역
		List<Code> region = new ArrayList<>();
//		region.add(new Code("","==선택하세요=="));
		region.add(new Code("서울", "서울"));
		region.add(new Code("대전", "대전"));
		region.add(new Code("대구", "대구"));
		region.add(new Code("부산", "부산"));
		region.add(new Code("찍고", "찍고"));
		region.add(new Code("울산", "울산"));
		model.addAttribute("region", region);

		// 성별
		List<Code> gender = new ArrayList<>();
		gender.add(new Code("남", "남자"));
		gender.add(new Code("여", "여자"));
		model.addAttribute("gender", gender);
	}

	// 회원가입양식
	@RequestMapping("/joinForm")
	public String memberJoinForm(Model model) {
		logger.info("joinform");
		model.addAttribute("mvo", new MemberVO());
		return "member/joinForm";
	}

	// 회원등록
	@RequestMapping("/join")
	public String memberJoin(@Valid @ModelAttribute("mvo") MemberVO memberVO, BindingResult result, Model model) {
		logger.info(memberVO.toString());
		logger.info("join");

		// 1) 유효성 오류체크 중 오류가 발견되면 회원 가입 페이지로 이동
		if (result.hasErrors()) {
			logger.info(result.getAllErrors().toString());
			return "member/joinForm";

		}
		// 2) 회원 중복체크
		if (memberSVC.selectMember(memberVO.getId()) != null) {
			model.addAttribute("svr_msg", "중복된 아이디");
			logger.info("id중복");
			return "member/joinForm";
		}
		// 3) 회원 가입처리
		int cnt = memberSVC.joinMember(memberVO); // result 값이 1일경우: 정상적인 결과
		if (cnt == 1) {
			return "member/signin";
		} else {
			return "redirect:/";
		}
	}

	// 회원 수정 양식
	@GetMapping("/modifyForm/{id:.+}") // colon은 정규표현식
	public String modifyForm(@PathVariable String id, Model model) {

		// 1) 현재 로긴한 회원 정보 읽어오기
		MemberVO memberVO = memberSVC.selectMember(id);
		memberVO.setPw(null);
		logger.info("memberVO:" + memberVO);
		model.addAttribute("memberVO", memberVO);

		return "member/modifyForm";
	}

	// 회원 수정 처리
	@PostMapping("/modify")
	public String modify(
			@Valid @ModelAttribute("mvo") MemberVO memberVO, 
			BindingResult result, 
			HttpSession session,
			Model model) {
		// 유효성 체크
//		model.addAttribute("memberVO", memberVO);
		logger.info("memberVO in request :"+memberVO);
		if (result.hasErrors()) {
			logger.info("유효성 통과 못함");
			return "member/modifyForm";
		}
		// 회원정보 수정
		int cnt = memberSVC.modifyMember(memberVO);
		logger.info("수정처리결과:" + cnt);
		// 세션정보수정
		memberVO = memberSVC.selectMember(memberVO.getId());
		memberVO.setPw(null);

		logger.info(memberVO.toString());
		session.removeAttribute("member");
		session.setAttribute("member", memberVO);
		model.addAttribute("memberVO", memberVO);
		return "member/modifyForm";
	}

	// 회원 탈퇴 양식
	@GetMapping("/outForm")
	public String outForm() {
		return "member/withdrawal";
	}

	// 회원 탈퇴 처리
	@PostMapping("/out")
	public String out(@RequestParam("id") String id, @RequestParam("pw") String pw, HttpSession session, Model model) {
		int cnt = memberSVC.outMember(id, pw);
		if (cnt == 1) {
			session.invalidate();
			return "redirect:/";
		}
		model.addAttribute("svr_msg", "비밀번호가 잘못되었습니다.");
		return "member/outForm";
	}

	// 비밀번호 변경 화면
	@GetMapping("/findPWForm")
	public String findPWForm() {
		return "member/findPWForm";
	}
	// 비밀번호 변경 대상 찾기
	@PostMapping(value="/findPW", produces="application/json")
	@ResponseBody
	public ResponseEntity<Map> findPW(
			@RequestBody MemberVO memberVO) {
		ResponseEntity<Map> res = null;		
		logger.info("비밀번호 변경 대상찾기 요청:"+memberVO);		

//		memberVO.setBirth(java.sql.Date.valueOf("2020-12-31"));
		logger.info("비밀번호 찾기 대상: "+ memberVO.getBirth());
		
		
		// 2) 비밀번호 변경 대상 찾기
//		int cnt = memberSVC.changePW(memberVO.getId(), memberVO.getPw());
		memberVO.setBirth(java.sql.Date.valueOf(memberVO.getBirth().toString()));
		int cnt = memberSVC.findPW(memberVO);
		logger.info("비밀번호 변경 대상찾기 요청:"+cnt);		
		Map<String,	Boolean> map = new HashMap<>();
		if(cnt == 1) {
				map.put("success", true);//			
			res = new ResponseEntity<Map>(map,HttpStatus.OK);
		}else {
			map.put("success", false);//			
			res = new ResponseEntity<Map>(map,HttpStatus.OK);			
		}
		return res;
	}
	
	
	// 비밀번호 변경
	@PostMapping(value="/changePW", produces="application/json")
	@ResponseBody
	public ResponseEntity<Map> changePW(
			@RequestBody MemberVO memberVO) {
		ResponseEntity<Map> res = null;
		
		logger.info("비밀번호 변경 요청:"+memberVO);		
		int cnt = memberSVC.changePW(memberVO.getId(), memberVO.getPw());
		Map<String,	Boolean> map = new HashMap<>();
		if(cnt == 1) {
			map.put("success", true);//
			res = new ResponseEntity<Map>(map,HttpStatus.OK);
		}else {
			map.put("success", false);//
			res = new ResponseEntity<Map>(map,HttpStatus.UNAUTHORIZED);
		}
		return res;
	}
	

	// 아이디 찾기 양식
	@GetMapping("/findIDForm")
	public String findIDForm() {
		return "member/findIDForm";
	}
// 아이디 찾기  get 방식
//	@GetMapping("/id/{tel}/{birth}")
//	@ResponseBody
//	public ResponseEntity<String> findId(@PathVariable("tel") String tel, @PathVariable("birth") String birth) {
//
//		ResponseEntity<String> res = null;
//		String findId = null;
//		SimpleDateFormat transFormat = new SimpleDateFormat("yyyy-MM-dd");
//
//		findId = memberSVC.findID(tel, java.sql.Date.valueOf(birth));
//		if (findId != null) {
//			res = new ResponseEntity<String>(findId, HttpStatus.OK);
//		} else {
//			res = new ResponseEntity<String>("찾고자하는 계정이 없어요~", HttpStatus.NOT_FOUND);
//		}
//
//		return res;
//	}
	@PostMapping(value="/id", produces = "application/json")
	@ResponseBody
	public ResponseEntity<Map> findId(
			@RequestBody MemberVO memberVO
			) {
		ResponseEntity<Map> res = null;
		String findId = null;
		logger.info("tel:"+memberVO.getTel());
		logger.info("birth:"+memberVO.getBirth());

		memberVO.setBirth(java.sql.Date.valueOf(memberVO.getBirth().toString()));
		findId = memberSVC.findID(memberVO.getTel(), memberVO.getBirth());
		Map<String,Object> map = new HashMap();
		if (findId != null) {
			map.put("success", true);
			map.put("id", findId);
			res = new ResponseEntity<Map>(map, HttpStatus.OK);
		} else {
			map.put("success", false);
			map.put("id", findId);
			map.put("msg", "찾고자하는 아이디가 없습니다.");
			res = new ResponseEntity<Map>(map, HttpStatus.NOT_FOUND);
		}

		return res;
	}
	@RequestMapping("/test")
	public void test(@RequestParam("name") String name, @RequestParam("age") String age) {
		logger.info("name: " + name);
		logger.info("age: " + age);
	}
}
