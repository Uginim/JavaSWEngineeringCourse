package com.kh.portfolio.controller;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class TestController2 {
	
	private static final Logger logger
		=LoggerFactory.getLogger(TestController2.class);
	
	@GetMapping("/test/t1")
	public String t1(HttpServletRequest request) {
		String name = request.getParameter("name");
		String age = request.getParameter("age");
		logger.info("이름: " + name);
		logger.info("나이: " + age);
		return "test";
	}
	@GetMapping("/test/t2")
	public String t2(
			@RequestParam String name,
			@RequestParam int age) {

		logger.info("이름: " + name);
		logger.info("나이: " + age);
		return "test";
	}
	@GetMapping("/test/t3")
	public String t3(
			@RequestParam("name") String rename,
			@RequestParam("age") int reage) {
		
		logger.info("이름: " + rename);
		logger.info("나이: " + reage);
		return "test";
	}
	@GetMapping("/test/t4")
	public String t4(
			@RequestParam Map<String, String> map) {
		
		logger.info("이름: " + map.get("name"));
		logger.info("나이: " + map.get("age"));
		return "test";
	}
}









