package com.kh.portfolio.common;

import lombok.Data;

@Data
public class FindCriteria extends RecordCriteria{

	private String searchType;			//검색유형
	private String keyword;					//검색어
	
	public FindCriteria() {
		super();
	}
	
	public FindCriteria(int reqPage, int numPerPage) {
		super(reqPage,numPerPage);
	}

	public FindCriteria(int reqPage, int numPerPage, String searchType, String keyword) {
		this(reqPage,numPerPage);
		this.searchType = searchType;
		this.keyword = keyword;
	}
}
