package com.kh.portfolio.board.vo;

import lombok.Data;

@Data
public class BoardCategoryVO {
	private long cid;					//CID   NOT NULL NUMBER(10)   
	private String cname;			//CNAME          VARCHAR2(60) 
}
