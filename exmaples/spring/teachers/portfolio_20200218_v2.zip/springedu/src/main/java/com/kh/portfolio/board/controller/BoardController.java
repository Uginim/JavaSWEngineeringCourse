package com.kh.portfolio.board.controller;

import java.util.List;
import java.util.Map;

import javax.inject.Inject;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.kh.portfolio.board.svc.BoardSVC;
import com.kh.portfolio.board.vo.BoardCategoryVO;
import com.kh.portfolio.board.vo.BoardFileVO;
import com.kh.portfolio.board.vo.BoardVO;
import com.kh.portfolio.member.vo.MemberVO;

@Controller
@RequestMapping("/board")
public class BoardController {

	private static final Logger logger
		= LoggerFactory.getLogger(BoardController.class);
	
	@Inject
	BoardSVC boardSVC;
	
	@ModelAttribute
	public void getBoardCategory(Model model) {
		List<BoardCategoryVO> boardCategoryVO = boardSVC.getCategory();
		model.addAttribute("boardCategoryVO", boardCategoryVO);
	}
	
	//게시글 작성양식
	@GetMapping("/writeForm")
	public String writeForm(Model model) {
		model.addAttribute("boardVO", new BoardVO());
		return "/board/writeForm";
	}
	
	//게시글 작성
	@PostMapping("/write")
	public String write(BoardVO boardVO) {
		logger.info("게시글작성: " + boardVO.toString());
		boardSVC.write(boardVO);
		
		return "/board/list";
	}
		
	//목록보기
	@GetMapping
	public String listAll(HttpSession session, Model model) {

		MemberVO memberVO = (MemberVO)session.getAttribute("member");
//		if(memberVO != null ) {
//			logger.info("세션있음"+memberVO.toString());
//		}else {
//			logger.info("세션없음");
//		}
		model.addAttribute("list", boardSVC.list());
			
		return "/board/list";
	}
	
	//게시글보기
	@GetMapping("/{bnum}")
	public String view(
			@PathVariable("bnum") String bnum,
			Model model) {
		
		Map<String,Object> map = boardSVC.view(bnum);
		BoardVO boardVO = (BoardVO)map.get("board");
		List<BoardFileVO> files = null;
		if(map.get("files") != null) {
			files = (List<BoardFileVO>)map.get("files");
		}
		
		model.addAttribute("boardVO", boardVO);
		model.addAttribute("files", files);
		
		return "/board/readForm";
	}
}








