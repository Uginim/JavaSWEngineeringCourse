package com.kh.portfolio.board.dao;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Repository;

import com.kh.portfolio.board.vo.BoardCategoryVO;
import com.kh.portfolio.board.vo.BoardFileVO;
import com.kh.portfolio.board.vo.BoardVO;

@Repository
public class BoardDAOImplXML implements BoardDAO {
	
	@Inject
	SqlSessionTemplate sqlSession;
	
	//카테고리 읽어오기
	@Override
	public List<BoardCategoryVO> getCategory() {
		
		return sqlSession.selectList("mappers.BoardDAO-mapper.getCategory");
	}
	//게시글작성
	@Override
	public int write(BoardVO boardVO) {
		return sqlSession.insert("mappers.BoardDAO-mapper.write", boardVO);
	}
  //첨부파일 저장
	@Override
	public int fileWrite(BoardFileVO boardFileVO) {
		return sqlSession.insert("mappers.BoardDAO-mapper.fileWrite", boardFileVO);
	}
	//게시글수정
	@Override
	public int modify(BoardVO boardVO) {
		return sqlSession.update("mappers.BoardDAO-mapper.modify", boardVO);
	}

	//게시글삭제
	@Override
	public int delete(String bnum) {

		return sqlSession.delete("mappers.BoardDAO-mapper.delete", Long.valueOf(bnum));
	}
	//첨부파일 1건 삭제
	@Override
	public int fileDelete(String fid) {
		return sqlSession.delete("mappers.BoardDAO-mapper.fileDelete", Long.valueOf(fid));
	}
	//게시글 첨부파일 전체 삭제
	@Override
	public int filesDelete(String bnum) {
		return sqlSession.delete("mappers.BoardDAO-mapper.filesDelete", Long.valueOf(bnum));
	}
	
	//게시글보기
	@Override
	public BoardVO view(String bnum) {
		return sqlSession.selectOne("mappers.BoardDAO-mapper.view", Long.valueOf(bnum));
	}

	@Override
	public List<BoardFileVO> fileViews(String bnum) {
		return sqlSession.selectList("mappers.BoardDAO-mapper.fileViews", Long.valueOf(bnum));
	}
	
	@Override
	public int updateHit(String bnum) {
		return sqlSession.update("mappers.BoardDAO-mapper.updateHit", Long.valueOf(bnum));
	}	
	//게시글목록
	//1)전체
	@Override
	public List<BoardVO> list() {
		return sqlSession.selectList("mappers.BoardDAO-mapper.list");
	}
	//2)검색어 없는 게시글페이징
	@Override
	public List<BoardVO> list(int startRec, int endRec) {
		Map<String,Object> map = new HashMap<>();
		map.put("startRec", startRec);
		map.put("endRec", endRec);
		return sqlSession.selectList("mappers.BoardDAO-mapper.list2", map);
	}
	//3)검색어 있는 게시글검색(전체,제목,내용,작성자ID,별칭)
	@Override
	public List<BoardVO> list(int startRec, int endRec, String searchType, String keyword) {
		Map<String,Object> map = new HashMap<>();
		map.put("startRec", startRec);
		map.put("endRec", endRec);
		map.put("searchType",searchType);
		map.put("keyword",keyword);
		return sqlSession.selectList("mappers.BoardDAO-mapper.list3", map);
	}
	//게시글답글작성
	@Override
	public int reply(BoardVO boardVO) {
		return sqlSession.insert("mappers.BoardDAO-mapper.reply", boardVO);
	}
	//첨부파일조회
	@Override
	public BoardFileVO fileView(String fid) {

		return sqlSession.selectOne("mappers.BoardDAO-mapper.fileView", Long.valueOf(fid));
	}


}



