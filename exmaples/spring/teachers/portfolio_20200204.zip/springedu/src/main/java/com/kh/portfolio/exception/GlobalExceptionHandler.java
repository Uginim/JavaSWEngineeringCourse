package com.kh.portfolio.exception;

import org.springframework.dao.DuplicateKeyException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.ModelAndView;

@ControllerAdvice
public class GlobalExceptionHandler {

	@ExceptionHandler(DuplicateKeyException.class)
	public ModelAndView handleSQLException(Exception ex) {
		ModelAndView mav = new ModelAndView("exception/exception");
		mav.addObject("name",ex.getClass().getSimpleName());
		mav.addObject("message",ex.getMessage());
		return mav;
	}
}
