package com.uginim.clevernote.note.vo;

import lombok.Data;

@Data
public class TaggingVO {
	TagVO tag; // 태그 
//	long userNum;
//	long noteNum;
	NoteVO note; // 노트
}
