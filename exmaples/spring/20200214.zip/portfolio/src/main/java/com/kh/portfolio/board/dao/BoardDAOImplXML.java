package com.kh.portfolio.board.dao;

import java.util.List;

import javax.inject.Inject;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.stereotype.Repository;

import com.kh.portfolio.board.vo.BoardCategoryVO;
import com.kh.portfolio.board.vo.BoardFileVO;
import com.kh.portfolio.board.vo.BoardVO;

@Repository
public class BoardDAOImplXML implements BoardDAO {

	@Inject
	SqlSessionTemplate sqlSession;
	
	// 카데고리 읽어오기
	@Override
	public List<BoardCategoryVO> read() {
		sqlSession.selectList("mappers.BoardDAO-mapper.read");
		return null;
	}

	// 게시글 작성
	@Override
	public int write(BoardVO boardVO) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int fileWrite(BoardFileVO file) {
		// TODO Auto-generated method stub
		return 0;
	}

	// 게시글 수정
	@Override
	public int modify(BoardVO boardVO) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int fileModify(BoardFileVO file) {
		// TODO Auto-generated method stub
		return 0;
	}
	
	// 게시글 삭제
	@Override
	public int delete(String bnum) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int fileDelete(String fid) {
		// TODO Auto-generated method stub
		return 0;
	}

	// 게시글 보기
	@Override
	public BoardVO view(String bnum) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<BoardFileVO> fileView(String fid) {
		// TODO Auto-generated method stub
		return null;
	}

	// 게시글 목록
	// 1) 전체
	@Override
	public List<BoardVO> list() {
		// TODO Auto-generated method stub
		return null;
	}
	
	// 2) 검색어 없는 게시글 페이징
	@Override
	public List<BoardVO> list(int startRec, int endRec, String SearchType) {
		// TODO Auto-generated method stub
		return null;
	}
	
	// 3) 검색어 잇는 게시글 검색(전체,작성자id, 별칭, 제목, 내용)
	@Override
	public List<BoardVO> list(int startRec, int endRec, String keyword, String SearchType) {
		// TODO Auto-generated method stub
		return null;
	}

	// 게시글답글 작성
	@Override
	public int reply(BoardVO boardVO) {
		// TODO Auto-generated method stub
		return 0;
	}

}
