package com.kh.portfolio.board.vo;

import lombok.Data;

@Data
public class BoardCategoryVO {
	private long cid;	// 분류코드
	private String cname; // 분류명
}
