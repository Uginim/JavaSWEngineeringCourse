package com.kh.portfolio.board.vo;


import java.sql.Timestamp;

import lombok.Data;

@Data
public class BoardVO {
	private long bnum; //게시글번호
	private long bcategroy; // 분류카데고리
	private String btitle; // 제목
	private String bid; // 작성자(이메일)
	private String bnickname; // 별칭
	private Timestamp bcdate; // 	작성일
	private Timestamp cdate; // 수정일
	private int bhit; // 조회수
	private String bcontent; // 본문내용
	private int bgroup; //답글그룹
	private int bstep; //	답변글의 단계
	private int bindent; // 답변글의 들여쓰기
	
	// 
	
}
