window.addEventListener("load", init, false);
function init() {

	var findIDBtn = document.getElementById("findIDBtn");
	
	findIDBtn.addEventListener("click", function(e) {
		e.preventDefault();
		var result = checkFindID();		
		if (result) {
//			document.forms['findIDForm'].submit();
			// AJAX 사용
			// 1) XMLHttpRequest객체 생성
			var xhr = new XMLHttpRequest();
			
			// 2) 서버응답처리
			// Holds the Status of the XMLHttpRequest.
			// 0: 초기화되지 않은 상태(open()가 호출되지 않은 상태) request not initialized
			// 1: open()가 실행된 상태 server connection extablished
			// 2: 서버가 클라이언트의 요청을 받았음. send()가 실행된 상태 request received
			// 3: 서버가 클라이언트의 요청 처리중. 응답헤더는 수신했으나 바디가 수신 중인 상태 processing request
			// 4: 서버가 클라이언트의 요청을 완료했고 서버도 응답이 완료된 상태 request finished and response
			xhr.addEventListener("readystatechange",ajaxCall,false);
			function ajaxCall() {
				if(this.readyState == 4 && this.status == 200){
					document.getElementById("telMsg").innerHTML ="";
					document.getElementById("birthMsg").innerHTML ="";						
					document.getElementById("id").value = "";
					console.log(this.responseText);
					try{
						var jsonObj = JSON.parse(this.responseText);						
						if(jsonObj.error == null){
							document.getElementById("id").value = jsonObj.id;	
						}else {						
							console.log(jsonObj);
							document.getElementById("birthMsg").innerHTML ="계정이 엄서영"; 
						}
					}catch(e){
						console.dir(e);
						document.getElementById("id").value = this.responseText; 
					}
				}
			}
			
			// 3) 서비스 요청
			var sendData = {};
			sendData.tel = document.getElementById("tel").value;
			sendData.birth = document.getElementById("birth").value;
//			var tel = document.getElementById("tel").value;
//			var birth = document.getElementById("birth").value;
			
			// 자바스크립트 obj => json포맷 문자열 반환
			var result = JSON.stringify(sendData);
			/*
			// POST 방식
//			xhr.open("POST",'<c:url value="/member/findID"/>',true);	
			xhr.open("POST",'/myweb/member/findID',true);	
			xhr.setRequestHeader("Content-Type","application/x-www-form-urlencoded")
//			xhr.send("tel="+tel+"&birth="+birth);
			xhr.send("result="+result);
//			var formData = new FormData();
//			formData.append("tel",sendData.tel);
//			formData.append("birth",sendData.birth);
//			xhr.send(formData);
			*/
			
			// GET 방식
			xhr.open("GET","http://localhost:9080/portfolio/member/id/"+sendData.tel+"/"+sendData.birth,true);
			xhr.send();
		}

	}, false);
}
function checkFindID() {
	var telTag = document.getElementById("tel");
	var telValue = telTag.value
	var birthTag = document.getElementById("birth");
	var birthValue = birthTag.value;
	
	var flag = true;

	// 1) 전화번호 체크
	if (telValue.trim().length == 0) {
		telMsg.innerHTML = "전화번호를 입력하세요!";
		telMsg.classList.add("errmsg");
		telTag.focus();
		flag = false;
	}
	// 2) 생년월일 체크
	if (birthValue.trim().length == 0) {
		telMsg.innerHTML = "";
		birthMsg.innerHTML = "생년월일을 입력하세요!";
		birthMsg.classList.add("errmsg");
		birthTag.focus();
		flag = false;
	}
	return flag;

}