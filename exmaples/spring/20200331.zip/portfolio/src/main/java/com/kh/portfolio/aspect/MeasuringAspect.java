package com.kh.portfolio.aspect;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.Signature;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Component  // 컨테이너에 빈으로 등록하고자 하는 클래스에 사용
@Aspect		// 부가기능을 정의한 클래스에 사용
public class MeasuringAspect {
	private static final Logger logger = LoggerFactory.getLogger(MeasuringAspect.class);
	
//	@Around("execution(* com.kh.portfolio.board.svc.BoardSVCImpl.*(..))")
	@Around("execution(* com.kh.portfolio.board.svc.BoardSVCImpl.*(..))") // 접근제한자 추가
	public Object measuringMethodRoundingTime(ProceedingJoinPoint jointPoint) {
		Object result = null;
		Signature signature = jointPoint.getSignature();
		String methodName = signature.getName();
		long startTime = System.nanoTime();
		logger.info("[Log: Around]Before: " + methodName  + " time check start");
		try {
			// 핵심 기능 수행
			jointPoint.proceed();			
		} catch(Throwable e) {
			logger.info("[Log: Around]Exception occured: "+methodName);
			e.printStackTrace();
		}
		
		long endTime = System.nanoTime();
		logger.info("[Log: Around]After: " + methodName  + " time check start");		
		logger.info("[Log: Around]: " + methodName  + " Processing time is "+(startTime-endTime) + "ns");		
		
		return result;
		
	}
}
