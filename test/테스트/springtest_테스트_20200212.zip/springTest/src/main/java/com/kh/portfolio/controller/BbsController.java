package com.kh.portfolio.controller;

import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.kh.portfolio.member.vo.MemberVO;

@Controller
@RequestMapping("/bbs")
public class BbsController {

	private static final Logger logger
		= LoggerFactory.getLogger(BbsController.class);
		
	//목록보기
	@GetMapping
	public String listAll(HttpSession session) {

		MemberVO memberVO = (MemberVO)session.getAttribute("member");
		if(memberVO != null ) {
			logger.info("세션있음"+memberVO.toString());
		}else {
			logger.info("세션없음");
		}

		return "bbs/bbsList";
	}
		
}
