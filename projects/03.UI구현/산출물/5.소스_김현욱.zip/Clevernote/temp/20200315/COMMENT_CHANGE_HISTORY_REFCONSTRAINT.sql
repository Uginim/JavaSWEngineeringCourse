--------------------------------------------------------
--  Ref Constraints for Table COMMENT_CHANGE_HISTORY
--------------------------------------------------------

  ALTER TABLE "CLEVERNOTEADMIN"."COMMENT_CHANGE_HISTORY" ADD CONSTRAINT "COMMENT_CHANGE_HISTORY_FK1" FOREIGN KEY ("POST_NUM")
	  REFERENCES "CLEVERNOTEADMIN"."BOARD_POST" ("POST_NUM") ON DELETE CASCADE ENABLE;
