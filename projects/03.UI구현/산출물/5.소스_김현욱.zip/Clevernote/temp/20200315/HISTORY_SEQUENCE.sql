--------------------------------------------------------
--  DDL for Sequence HISTORY_SEQUENCE
--------------------------------------------------------

   CREATE SEQUENCE  "CLEVERNOTEADMIN"."HISTORY_SEQUENCE"  MINVALUE 1 MAXVALUE 9999999999 INCREMENT BY 1 START WITH 181 CACHE 20 NOORDER  NOCYCLE ;
