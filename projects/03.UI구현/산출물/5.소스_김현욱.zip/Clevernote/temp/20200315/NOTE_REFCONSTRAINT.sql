--------------------------------------------------------
--  Ref Constraints for Table NOTE
--------------------------------------------------------

  ALTER TABLE "CLEVERNOTEADMIN"."NOTE" ADD CONSTRAINT "NOTE_FK2" FOREIGN KEY ("CATEGORY_NUM")
	  REFERENCES "CLEVERNOTEADMIN"."CATEGORY" ("CATEGORY_NUM") ON DELETE SET NULL ENABLE;
