--------------------------------------------------------
--  DDL for Sequence NOTE_SEQUENCE
--------------------------------------------------------

   CREATE SEQUENCE  "CLEVERNOTEADMIN"."NOTE_SEQUENCE"  MINVALUE 1 MAXVALUE 9999999999999 INCREMENT BY 1 START WITH 1041 CACHE 20 NOORDER  NOCYCLE ;
