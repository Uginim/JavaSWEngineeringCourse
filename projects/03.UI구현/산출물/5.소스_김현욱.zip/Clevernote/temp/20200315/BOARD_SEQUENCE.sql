--------------------------------------------------------
--  DDL for Sequence BOARD_SEQUENCE
--------------------------------------------------------

   CREATE SEQUENCE  "CLEVERNOTEADMIN"."BOARD_SEQUENCE"  MINVALUE 1 MAXVALUE 9999999999 INCREMENT BY 1 START WITH 1101 CACHE 20 NOORDER  NOCYCLE ;
