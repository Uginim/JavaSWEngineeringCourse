--------------------------------------------------------
--  Ref Constraints for Table ATTACHMENT_FILE
--------------------------------------------------------

  ALTER TABLE "CLEVERNOTEADMIN"."ATTACHMENT_FILE" ADD CONSTRAINT "ATTACHMENT_FILE_FK1" FOREIGN KEY ("POST_NUM")
	  REFERENCES "CLEVERNOTEADMIN"."BOARD_POST" ("POST_NUM") ON DELETE SET NULL ENABLE;
