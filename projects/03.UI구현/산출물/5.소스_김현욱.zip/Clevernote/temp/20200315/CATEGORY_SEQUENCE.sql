--------------------------------------------------------
--  DDL for Sequence CATEGORY_SEQUENCE
--------------------------------------------------------

   CREATE SEQUENCE  "CLEVERNOTEADMIN"."CATEGORY_SEQUENCE"  MINVALUE 1 MAXVALUE 9999999999999 INCREMENT BY 1 START WITH 521 CACHE 20 NOORDER  NOCYCLE ;
