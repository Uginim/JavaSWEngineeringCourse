--------------------------------------------------------
--  DDL for Procedure BOARD_SAMPLE_DATA_PROC
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "CLEVERNOTEADMIN"."BOARD_SAMPLE_DATA_PROC" 
(
  RECORDCNT IN NUMBER DEFAULT 959
) AS 
BEGIN
   FOR i in 1..RECORDCNT LOOP  
    INSERT INTO board_post(
      post_num,
      title,
      type_num,
      user_num,
      content,
      username,
      post_group
    ) VALUES (
      BOARD_SEQUENCE.nextval,      
      '제목-' || i,
      1,
      399,      
      '반갑습니다-' || i,
      '관리자',
      BOARD_SEQUENCE.currval
    );
  END LOOP;
  COMMIT;
END BOARD_SAMPLE_DATA_PROC;

/
