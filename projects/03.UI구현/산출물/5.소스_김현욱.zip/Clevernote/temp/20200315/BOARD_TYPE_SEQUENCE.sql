--------------------------------------------------------
--  DDL for Sequence BOARD_TYPE_SEQUENCE
--------------------------------------------------------

   CREATE SEQUENCE  "CLEVERNOTEADMIN"."BOARD_TYPE_SEQUENCE"  MINVALUE 1 MAXVALUE 9999999999 INCREMENT BY 1 START WITH 41 CACHE 20 NOORDER  NOCYCLE ;
