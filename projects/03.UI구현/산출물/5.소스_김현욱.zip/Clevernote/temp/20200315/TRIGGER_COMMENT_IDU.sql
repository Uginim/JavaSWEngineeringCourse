--------------------------------------------------------
--  DDL for Trigger TRIGGER_COMMENT_IDU
--------------------------------------------------------

  CREATE OR REPLACE TRIGGER "CLEVERNOTEADMIN"."TRIGGER_COMMENT_IDU" 
AFTER DELETE OR INSERT OR UPDATE OF COMMENT_NUM,POST_NUM ON BOARD_COMMENT FOR EACH ROW
BEGIN
    IF INSERTING THEN        
        IF :new.parent_num IS NULL THEN 
            INSERT INTO comment_change_history (post_num, comment_num, created_at, type, history_num)
            VALUES (:new.post_num, :new.comment_num, systimestamp, 'I', HISTORY_SEQUENCE.nextval);
--        ELSIF :new.parent_num IS NOT NULL THEN
        ELSE
            INSERT INTO comment_change_history (post_num, comment_num, created_at, type, history_num)
            VALUES (:new.post_num, :new.parent_num, systimestamp, 'CI', HISTORY_SEQUENCE.nextval);
        END IF;
    ELSIF UPDATING THEN
        INSERT INTO comment_change_history (post_num, comment_num, created_at, type, history_num)
        VALUES (:old.post_num, :old.comment_num, systimestamp, 'U', HISTORY_SEQUENCE.nextval);
    ELSIF DELETING THEN
        IF :old.parent_num IS NULL THEN
            INSERT INTO comment_change_history (post_num, comment_num, created_at, type, history_num)
            VALUES (:old.post_num, :old.comment_num, systimestamp, 'D', HISTORY_SEQUENCE.nextval);
        ELSE
            INSERT INTO comment_change_history (post_num, comment_num, created_at, type, history_num)
            VALUES (:old.post_num, :old.comment_num, systimestamp, 'CD', HISTORY_SEQUENCE.nextval);
        END IF;
    END IF;
END;
/
ALTER TRIGGER "CLEVERNOTEADMIN"."TRIGGER_COMMENT_IDU" ENABLE;
