--------------------------------------------------------
--  Ref Constraints for Table CATEGORY
--------------------------------------------------------

  ALTER TABLE "CLEVERNOTEADMIN"."CATEGORY" ADD CONSTRAINT "CATEGORY_FK1" FOREIGN KEY ("OWNER_NUM")
	  REFERENCES "CLEVERNOTEADMIN"."APP_USER" ("USER_NUM") ON DELETE CASCADE ENABLE;
