--------------------------------------------------------
--  DDL for Sequence TAG_SEQUENCE
--------------------------------------------------------

   CREATE SEQUENCE  "CLEVERNOTEADMIN"."TAG_SEQUENCE"  MINVALUE 1 MAXVALUE 999999999 INCREMENT BY 1 START WITH 401 CACHE 20 NOORDER  NOCYCLE ;
