--------------------------------------------------------
--  DDL for Trigger TRIGGER_FOR_DEFAULT_CATEGORY
--------------------------------------------------------

  CREATE OR REPLACE TRIGGER "CLEVERNOTEADMIN"."TRIGGER_FOR_DEFAULT_CATEGORY" 
AFTER INSERT ON APP_USER FOR EACH ROW
BEGIN
    INSERT INTO Category (owner_num,category_num,title) 
    values ( :NEW.user_num, CATEGORY_SEQUENCE.nextval, 'None title');
END;


/
ALTER TRIGGER "CLEVERNOTEADMIN"."TRIGGER_FOR_DEFAULT_CATEGORY" ENABLE;
