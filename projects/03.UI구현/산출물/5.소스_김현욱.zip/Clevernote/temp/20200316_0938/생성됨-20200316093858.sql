--------------------------------------------------------
--  ������ ������ - ������-3��-16-2020   
--------------------------------------------------------
@D:\dev\Projects\JAVASTUDY\spring\Clevernote\temp\20200316_0938\DATA_TABLE\APP_USER.sql
@D:\dev\Projects\JAVASTUDY\spring\Clevernote\temp\20200316_0938\DATA_TABLE\ATTACHMENT_FILE.sql
@D:\dev\Projects\JAVASTUDY\spring\Clevernote\temp\20200316_0938\DATA_TABLE\BOARD_COMMENT.sql
@D:\dev\Projects\JAVASTUDY\spring\Clevernote\temp\20200316_0938\DATA_TABLE\BOARD_POST.sql
@D:\dev\Projects\JAVASTUDY\spring\Clevernote\temp\20200316_0938\DATA_TABLE\BOARD_TYPE.sql
@D:\dev\Projects\JAVASTUDY\spring\Clevernote\temp\20200316_0938\DATA_TABLE\CATEGORY.sql
@D:\dev\Projects\JAVASTUDY\spring\Clevernote\temp\20200316_0938\DATA_TABLE\COMMENT_CHANGE_HISTORY.sql
@D:\dev\Projects\JAVASTUDY\spring\Clevernote\temp\20200316_0938\DATA_TABLE\COMMENT_VOTE.sql
@D:\dev\Projects\JAVASTUDY\spring\Clevernote\temp\20200316_0938\DATA_TABLE\NOTE.sql
@D:\dev\Projects\JAVASTUDY\spring\Clevernote\temp\20200316_0938\DATA_TABLE\TAG.sql
@D:\dev\Projects\JAVASTUDY\spring\Clevernote\temp\20200316_0938\DATA_TABLE\TAGGING.sql
