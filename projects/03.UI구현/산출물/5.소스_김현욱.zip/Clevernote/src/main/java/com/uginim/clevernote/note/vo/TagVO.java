package com.uginim.clevernote.note.vo;

import lombok.Data;

@Data
public class TagVO {
	String word; //태그 단어
	long tagNum; // 태그 번호
}
